# ai-sdlc-platform-docs

Documentación de la plataforma de agentes y skills de MyInvestor. Los paquetes se escriben una vez, de forma agnóstica, y APM los despliega en dos runtimes: **Claude Code** y **Antigravity**.

Las carpetas están numeradas en el orden en que conviene leerlas.

| Carpeta | Contenido | Empieza por |
|---|---|---|
| [1-blueprint/](1-blueprint/) | Referencia sobre primitivos, APM y los dos runtimes: conceptos, primitivos, modelo operativo, buenas prácticas, decisiones (ADR) y manual de creación de un paquete agnóstico | [1-blueprint/README.md](1-blueprint/README.md). Si no vienes de crear agentes, [1-conceptos/](1-blueprint/1-conceptos/README.md) primero |
| [2-architecture/](2-architecture/) | Documentos de arquitectura de nuestros paquetes: guía para no técnicos, skills vs subagentes, puntos de entrada, flujo de revisión de PRs, escenarios de skills y mejoras pendientes y cerradas | [2-architecture/README.md](2-architecture/README.md) |

## Estructura de carpetas

```
ai-sdlc-platform-docs/
├── README.md                      índice general
├── 1-blueprint/
│   ├── 1-conceptos/               README + 5 subcarpetas (27 fichas)
│   ├── 2-primitivos/              primitivas agnósticas + fichas runtime-claude-code y runtime-antigravity
│   ├── 3-modelo-operativo/        modelo de ejecución y distribución: agnóstico + un archivo por runtime
│   ├── 4-buenas-practicas/        README + 3 subcarpetas (20)
│   ├── 5-decisiones/              README + 4 subcarpetas (23 ADR, conservan su NNNN)
│   └── 6-manual-creacion-plugin/  manual de creación de un paquete agnóstico
└── 2-architecture/                incluye puntos-de-entrada.md, pr-review-java-flow.md, sarif-remediation-java-flow.md, escenarios-de-skills-implementacion.md, mejoras-pendientes.md y mejoras-cerradas.md
```
