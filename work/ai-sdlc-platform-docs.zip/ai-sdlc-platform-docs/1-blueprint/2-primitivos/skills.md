# Skills

> **Para quién:** quien diseña un paquete agnóstico y tiene que decidir si algo es una skill.
> **Qué responde:** qué es una skill, qué campos leen los dos runtimes, dónde se escribe y dónde se despliega, y cuándo usarla.

## En resumen

- Una skill es la primitiva principal de un paquete agnóstico. Junto con los [subagentes](subagents.md), es lo único que se usa para construir comportamiento ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).
- **Todo punto de entrada `/nombre` es una skill**, la "skill de entrada". Commands y prompts están prohibidos ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).
- Solo cuatro cosas se comportan igual en Claude Code y en Antigravity: `name`, `description`, `$ARGUMENTS` y el cuerpo.
- Lo específico de cada runtime está en dos fichas: [runtime-claude-code.md](runtime-claude-code.md) y [runtime-antigravity.md](runtime-antigravity.md).

## Qué es

Una skill empaqueta conocimiento o un procedimiento reusable: un checklist, un manual de criterios, una guía paso a paso.

- Por defecto corre **inline**, en el contexto de quien la llama.
- El modelo la activa solo cuando su `description` encaja con la petición, o alguien la invoca con `/nombre`.
- No gestiona aislamiento de herramientas ni límite de turnos: eso es de los [subagentes](subagents.md).

## Dónde se escribe y dónde se despliega

Se escribe **una vez** en el paquete y APM la despliega en cada runtime declarado en `targets`:

```
.apm/skills/<name>/SKILL.md                      # fuente (paquete APM)
.apm/skills/<name>/<archivo-de-soporte>.md       # opcional, se lee bajo demanda

.claude/skills/<name>/SKILL.md                   # despliegue en Claude Code
.agents/skills/<name>/SKILL.md                   # despliegue en Antigravity
```

El nombre del directorio coincide con el campo `name`.

## Por qué así

- **Activación por `description`.** El modelo ve solo el nombre y la `description` de cada skill. El cuerpo no se carga hasta que la skill se activa. Así se pueden instalar decenas de skills sin pagar su coste de tokens por adelantado.
- **Progressive disclosure.** Los archivos de soporte junto a `SKILL.md` se leen bajo demanda. Una skill puede referenciar documentación extensa sin inflar el contexto.
- **Funciona en los dos runtimes.** En Claude Code y en Antigravity una skill ya es invocable con `/nombre` y recibe el texto que sigue en `$ARGUMENTS`. Por eso sustituye a commands y prompts.

## Cuándo usar

- Conocimiento de dominio o checklist que aplica quien llama, y cuyo resultado intermedio conviene que quede en su contexto.
- Hacen falta archivos de soporte (plantillas, catálogos, sub-documentos) referenciados por ruta.
- La activación debe ser automática por `description`.
- Algo que una persona teclea como `/nombre`: es una **skill de entrada** ([puntos-de-entrada-como-skills.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md)).

## Cuándo NO usar

- El trabajo necesita aislamiento fuerte de herramientas o un límite de contexto propio → [subagente](subagents.md). Si además se teclea con `/`, una skill de entrada que delega en ese subagente.
- El contenido es referencia pasiva que solo lee otro componente por ruta → sigue siendo una skill, pero su `description` dice que no se active sola. En Claude, además, `disable-model-invocation: true` ([runtime-claude-code.md](runtime-claude-code.md#control-de-invocación)).

## Tipos de skill

La taxonomía de roles (orquestadora, especialista, conocimiento pasivo) está en [tipos-de-skill.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md).

## Campos que leen los dos runtimes

| Campo / mecanismo | Claude Code | Antigravity | Uso en un paquete agnóstico |
|---|---|---|---|
| `name` | sí | sí (opcional; por defecto, la carpeta) | Siempre, igual al directorio |
| `description` | sí | sí (obligatorio) | Siempre. Dice **cuándo** usarla y cuándo no |
| `argument-hint` | sí | no documentado | Recomendado en las skills de entrada |
| `$ARGUMENTS` en el cuerpo | sí | sí (comprobado en `agy` 1.4.8) | Con un valor por defecto si llega vacío |
| Cuerpo en Markdown | sí | sí | Las instrucciones, incluida la delegación |
| Resto del frontmatter | ver [ficha de Claude](runtime-claude-code.md#frontmatter-de-una-skill) | se ignora ([ficha de Antigravity](runtime-antigravity.md#skills)) | Se puede poner, pero el comportamiento no puede depender de él |

### Skill de entrada que delega en un agente

Si la skill de entrada tiene que ejecutarse dentro de un agente concreto, lleva:

1. `context: fork` + `agent: <agente>`: en Claude ejecutan la skill dentro del agente.
2. `disable-model-invocation: true`: en Claude impide que el modelo la active sola.
3. Una `description` "úsalo solo cuando el usuario lo pida": el único freno en Antigravity.
4. La delegación **pedida en el texto**, con dos ramas ("si no eres el agente, delega"; "si lo eres, ejecuta") y una salida "si no puedes delegar, detente y dilo" ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).

El caso real es `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md`. Plantilla en [puntos-de-entrada-como-skills.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md).

### Combinación `context: fork` + `agent:` + `background:`

**Es un mecanismo solo de Claude Code.** Antigravity ignora los tres campos.

- En Claude convierte la skill en una puerta que se ejecuta dentro de un subagente, con aislamiento de contexto real.
- Para Claude sigue valiendo la regla: **`context: fork` y `disable-model-invocation: true` van juntos**.
- En un paquete agnóstico no basta: la delegación también se pide en el texto (sección anterior).

El detalle de cada campo y por qué van juntos está en [runtime-claude-code.md](runtime-claude-code.md#context-fork-agent-y-background).

### Frontmatter y APM

APM valida solo dos campos de una skill y pasa el resto intacto a cada runtime:

| Campo | Comportamiento de APM |
|---|---|
| `name` | Valida: igual al directorio; kebab-case, 1-64 caracteres, sin guiones consecutivos |
| `description` | Valida la longitud (≤1024 caracteres); no interpreta el contenido |
| Todo el resto (`allowed-tools`, `model`, `effort`, `paths`, `context`, `agent`, `background`, `disable-model-invocation`, `user-invocable`, `argument-hint`, `arguments`) | Sin validar: pasa tal cual a `.claude/skills/` y a `.agents/skills/` |

Consecuencia: APM instala igual una skill con `context: fork`. Qué hace con ese campo lo decide cada runtime al leer el archivo desplegado.

## Fuente oficial

- [Skills reference — code.claude.com](https://code.claude.com/docs/en/skills.md)
- [Skills — antigravity.google](https://antigravity.google/docs/skills)
- [APM — Targets matrix](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity)
