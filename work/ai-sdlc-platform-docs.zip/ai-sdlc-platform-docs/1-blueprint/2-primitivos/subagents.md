# Subagents

> **Para quién:** quien diseña un paquete agnóstico y tiene que decidir si algo es un agente.
> **Qué responde:** qué es un subagente, qué campos funcionan en los dos runtimes, dónde se escribe y dónde se despliega, y cuándo usarlo.

## En resumen

- Un subagente ejecuta una tarea en un contexto propio y aislado y devuelve solo el resultado final.
- Existe en los dos runtimes: en Claude Code con la herramienta `Agent`/`Task`, en Antigravity con `invoke_subagent`.
- Se escribe **una vez** en `.apm/agents/<name>.agent.md`. APM lo despliega en Claude; en Antigravity lo genera un aprovisionador ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).
- Lo específico de cada runtime está en [runtime-claude-code.md](runtime-claude-code.md) y [runtime-antigravity.md](runtime-antigravity.md).

## Dónde se escribe y dónde se despliega

```
.apm/agents/<name>.agent.md      # fuente (paquete APM)

.claude/agents/<name>.md         # Claude Code: lo despliega APM
.agents/agents/<name>.md         # Antigravity: lo genera provision_agents_antigravity.py
```

En Antigravity, APM no despliega agentes. El aprovisionador corre en el `lifecycle post-install` de quien instala y traduce el frontmatter ([distribucion.md](../3-modelo-operativo/distribucion.md)).

## Qué es

Un subagente resuelve una tarea y desaparece:

- no comparte su razonamiento con quien lo llama;
- no conserva estado entre invocaciones (salvo `memory:` en Claude);
- no puede pedir confirmación humana a mitad de tarea; solo devuelve texto al final.

Si la tarea necesita un checkpoint humano intermedio, lo pone quien lo llama o un flag de invocación explícito, nunca el subagente.

## Por qué así

- **Aislamiento de contexto (token firewall).** El subagente arranca limpio: no hereda el historial de quien lo llama. Puede leer decenas de archivos sin que ese ruido llegue a la conversación principal. Esto vale en los dos runtimes.
- **`tools:` es una allowlist.** Declarar `tools` deja al agente solo con esas herramientas. Así se hace imposible, por estructura, que un agente de revisión escriba código: basta con no incluir `Write`/`Edit`.
- **Solo pasa texto.** No hay callbacks, file handles ni estado compartido. Un contrato que necesite pasar una función se rediseña como texto (por ejemplo, un comando parametrizado que el propio subagente ejecuta).

## Cuándo usar

- El trabajo intermedio (archivos leídos, hipótesis descartadas) no debe quedar en el contexto de quien llama.
- Hay que restringir herramientas por estructura, no solo por instrucción.
- La tarea se reusa desde varios llamantes con el mismo contrato de entrada y salida.
- Se necesita paralelismo: varios subagentes sobre partes independientes.
- El proceso solo funciona dentro de un agente concreto (por ejemplo, porque solo él conoce la tabla rol → skill). Si una persona lo teclea, la entrada es una skill que delega en él ([skills.md](skills.md#skill-de-entrada-que-delega-en-un-agente)).

## Cuándo NO usar

- El resultado intermedio es justo lo que quien llama necesita ver → skill inline.
- La tarea necesita confirmación humana a mitad de proceso → un subagente no puede pedirla. El punto de decisión va en un flag explícito (por ejemplo, `publish=false` por defecto) o en quien llama.
- Un solo llamante, sin reuso previsible ni necesidad de aislamiento → una skill simple cuesta menos que mantener un contrato.

## Campos que funcionan en los dos runtimes

| Campo en `.agent.md` | Claude Code | Antigravity (tras el aprovisionador) |
|---|---|---|
| `name`, `description` | sí | sí (obligatorios) |
| Cuerpo | system prompt del agente | system prompt del agente |
| `tools` | allowlist con nombres de Claude | se traducen; **solo nombres traducibles** (tabla abajo) |
| `model` | id de modelo o `inherit` | solo `inherit` (o ausente); otro valor da error |
| `skills` | precarga esas skills | rutas `../skills/<n>`; precarga, pero **no limita** |
| `antigravity:` | se ignora | `mainAgent`, `subagent`, `commandExecutionPolicy` |
| Resto (`memory`, `isolation`, `maxTurns`, `hooks`, `color`, `effort`…) | ver [ficha de Claude](runtime-claude-code.md#frontmatter-de-un-subagente) | **no usar en un agente agnóstico**: el aprovisionador falla |

Reglas del aprovisionador para que el agente llegue a Antigravity:
- **Solo estos campos:** `name`, `description`, `tools`, `model`, `skills` y `antigravity`. Con cualquier otro campo, el aprovisionador falla en lugar de descartarlo.
- **Solo estos nombres de `tools`:** `Read`, `Grep`, `Glob`, `LS`, `Bash`, `Write`, `Edit`, `WebFetch`, `WebSearch` y `Task`/`Agent`. Con cualquier otro, falla.
- **`skills:`** solo puede nombrar skills que estén desplegadas en `.agents/skills/`; si falta alguna, falla.
- **`model`** solo admite `inherit` o ningún valor. La tabla de equivalencias está en [runtime-antigravity.md](runtime-antigravity.md#subagentes).

### Delegar desde un agente: `Agent` y `Skill`

El frontmatter no valida el cuerpo. Si el prompt de un agente dice "delega en el agente X" o "usa la skill Y", `tools:` tiene que permitirlo. Ningún runtime comprueba que cuerpo y frontmatter coincidan.

| Lo que hace el agente | Qué declarar | En Claude Code | En Antigravity |
|---|---|---|---|
| Delegar en otro agente | `Agent` (o `Task`) en `tools` | herramienta `Agent` | se traduce a `invoke_subagent` |
| Usar skills concretas | `skills: [...]` | precarga | precarga, sin limitar |
| Cargar skills por su cuenta | `Skill` en `tools` | herramienta `Skill` | **sin traducción**: el aprovisionador falla |

Por eso, en un paquete agnóstico **no se pone `Skill` en `tools`**. Las skills que el agente necesita van en `skills:`. Es lo que hace `backend-java-ci`: `tools: Read, Grep, Glob, Bash` y siete skills precargadas.

Un agente **sin `tools`** recibe todas las herramientas en los dos runtimes, delegación incluida. Es el caso de `backend-java`.

### Frontmatter y APM

APM procesa más campos en agentes que en skills:

| Campo | Comportamiento de APM |
|---|---|
| `name` | Lee y valida que no colisione (avisa si es `default` o `start`); por defecto, el nombre del archivo |
| `description` | Obligatorio; se usa en los índices de contexto compilados |
| `model` | Lee y pasa sin validar |
| `tools` | Lee; la validación contra capacidades solo afecta al target Kiro. Para Claude pasa intacto |
| `color` | Valida el formato hex (`#rrggbb`) o un nombre de tema |
| `handoffs` | Campo propio de APM, sin equivalente documentado en Claude Code |
| Todo el resto (`skills`, `memory`, `isolation`, `maxTurns`, `permissionMode`, `mcpServers`, `disallowedTools`, `initialPrompt`, `hooks`, `effort`, `omitClaudeMd`, `background`, `antigravity`) | Sin validar: pasa intacto a `.claude/agents/` |

Consecuencias:
- Si una skill de `skills:` no existe tras el install, APM no avisa. En Claude el error aparece al ejecutar; en Antigravity, el aprovisionador comprueba que las rutas existen.
- Para Antigravity, APM no despliega el agente: lo que llega a `.agents/agents/` es lo que escribe el aprovisionador.

## Fuente oficial

- [Subagents reference — code.claude.com](https://code.claude.com/docs/en/sub-agents.md)
- [Subagents — antigravity.google](https://antigravity.google/docs/subagents)
