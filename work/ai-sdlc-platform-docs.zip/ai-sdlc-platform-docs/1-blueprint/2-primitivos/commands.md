# Slash Commands


**Prohibido en cualquier paquete.** Todo punto de entrada `/nombre` es una skill ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md), que reemplaza a [0012](../5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md)).

Los commands solo existen en Claude Code y los prompts de APM no se despliegan en ningún target. El formato antiguo y su tabla de migración a skills están en [runtime-claude-code.md](runtime-claude-code.md#commands--formato-histórico-prohibido-en-paquetes-nuevos).

## Organización

```
.claude/commands/<name>.md
```

Un archivo plano por comando. Sin directorio propio, sin archivos hermanos.

## Objetivo

Definir una acción invocable con `/<name>` cuando toda la lógica cabe en un único archivo, sin necesidad de recursos adicionales.

## Responsabilidad

Un command es un formato de invocación explícita — no decide nada sobre aislamiento de contexto ni sobre herramientas más allá de lo que declare en su propio frontmatter (idéntico al de [Skills](skills.md), salvo dos campos).

No gestiona archivos de soporte ni progressive disclosure: eso es exclusivo de las skills.

## Por qué así

Formato heredado de antes de que existieran las skills como directorio; se mantiene como alternativa liviana para casos de un solo archivo. **No está deprecado**: los archivos existentes en `.claude/commands/` siguen funcionando y ambos formatos coexisten como features de primera clase.

## Cuándo usar

- Un comando simple, un solo archivo, sin necesidad de plantillas/catálogos adicionales ni de restringir activación por `paths`.
- Se quiere invocación explícita únicamente (los commands no tienen activación automática por descripción del mismo modo "silencioso" que una skill con `disable-model-invocation: false` — ambos formatos comparten frontmatter, la diferencia real es de bundling, no de mecanismo de invocación).

## Cuándo NO usar

- Si necesitas archivos de soporte junto al comando (plantillas, catálogos, sub-documentos referenciados por ruta) → usa [Skill](skills.md), los commands no permiten bundling de directorio.
- Si necesitas restringir por `paths` o definir `arguments` con nombre — esos dos campos no existen en commands, solo en skills.
- Si estás creando contenido nuevo y no hay una razón específica para el formato plano → la convención recomendada en proyectos nuevos es usar siempre `skills/<name>/SKILL.md`, reservando commands para mantenimiento de lo ya existente.

## Antipatrón: mismo nombre en `commands/` y `skills/`

Nunca definir el mismo nombre invocable en ambos formatos a la vez — un nombre invocable, un archivo. Si `.claude/commands/revisar.md` y `.claude/skills/revisar/SKILL.md` coexisten, cuál gana la invocación `/revisar` es ambiguo y no está definido por contrato.

Visto en la práctica: un plugin instalado en este mismo entorno (`caveman`) define comandos y skills con nombres que se pisan entre sí.

## Regla de composición: un Command no tiene por qué ser 1:1 con las skills

Un Command se crea para lo que una persona escribe explícitamente — no hace falta que exista un Command por cada skill instalada, ni que cada Command cite exactamente una skill. Dos casos válidos y comunes:
- Una skill sin ningún Command: se activa solo por `description` o se precarga en un subagente (ver [../3-modelo-operativo/modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md) Entradas C/D).
- Un Command orquestador que no cita ninguna skill directamente: delega todo a un agente que resuelve internamente cuáles skills usar (ver Entrada A). El Command es la puerta de entrada tecleable; el agente es quien conoce el catálogo.

## Frontmatter

Mismo set que [Skills](skills.md) **excepto** `name` y `paths`, que no existen en commands (la identidad la da el nombre de archivo, y no hay restricción por rutas de proyecto).

| Campo | Notas |
|---|---|
| `description` | Igual que en skills |
| `allowed-tools` / `disallowed-tools` | Igual que en skills |
| `model` | Igual que en skills |
| `effort` | Igual que en skills |
| `arguments` / `argument-hint` | Igual que en skills |
| `disable-model-invocation` | Igual que en skills |
| `user-invocable` | Igual que en skills |

### Frontmatter y APM

APM no documenta un primitivo "command" separado en su guía de autoría — su modelo de skills/agents cubre `SKILL.md` y `*.agent.md`.

Un archivo en `.claude/commands/` fuera de esa convención pasa por APM sin validación específica, como cualquier archivo de proyecto no reconocido por sus autoría primitives.

## Fuente oficial

- [Commands reference — code.claude.com](https://code.claude.com/docs/en/commands.md)
- [Skills reference — code.claude.com](https://code.claude.com/docs/en/skills.md) (comparación explícita commands vs. skills)
