# Ficha de runtime: Antigravity

> **Para quién:** quien ejecuta, depura o revisa un paquete en Antigravity CLI (`agy`).
> **Qué responde:** qué despliega APM en `.agents/`, qué campos lee e ignora `agy`, cómo se traducen los subagentes, cómo funcionan permisos y hooks, qué pasa con los plugins y qué limitaciones están comprobadas.

## En resumen

- APM despliega en `.agents/` con `--target antigravity` o `targets: [..., antigravity]` en **cada** paquete (APM ≥ 0.33.0).
- APM **no despliega agentes**. Los genera `provision_agents_antigravity.py` en el `lifecycle post-install` de quien instala ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).
- `agy` lee de una skill solo `name`, `description` y el cuerpo con `$ARGUMENTS`. Ignora `context: fork`, `agent:` y el control de invocación: la delegación se pide en el texto ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).
- Permisos solo globales, sin `env` de proyecto, y otro contrato de hooks.
- Comprobado con `agy` 1.4.8 en la demo `out-git/demo-pr-review-agy/`.

Las primitivas agnósticas están en [skills.md](skills.md) y [subagents.md](subagents.md).

Cómo corre cada tipo de entrada en `agy` está en [modelo-ejecucion-antigravity.md](../3-modelo-operativo/modelo-ejecucion-antigravity.md); la instalación, en [distribucion-antigravity.md](../3-modelo-operativo/distribucion-antigravity.md).

## Layout en `.agents/`

```
.agents/
├── skills/<name>/SKILL.md      # APM: skills, incluidas las skills de entrada
├── agents/<name>.md            # el aprovisionador, desde .apm/agents/<name>.agent.md
├── rules/<name>.md             # APM: instructions (applyTo → trigger: glob + globs)
├── hooks.json                  # APM (contenedor "apm"), con rutas corregidas por el aprovisionador
└── mcp_config.json             # APM: servidores MCP
AGENTS.md                       # compilado por APM; omite las instructions ya desplegadas como reglas
```

- A nivel de usuario, la ruta es `~/.gemini/`.
- El target `antigravity` no se autodetecta y queda fuera de `--target all`.
- Los `.agents/workflows/*.md` antiguos están obsoletos en `agy`; se migran a skills.

## Skills

Antigravity documenta solo `name` (opcional; por defecto, la carpeta) y `description` (obligatorio). Toda skill es invocable con `/<name>`.

| Campo / mecanismo | En Antigravity |
|---|---|
| `/<name> [texto]` | Sí: toda skill es un comando |
| `$ARGUMENTS` | Sí: recibe el texto que sigue al nombre (comprobado) |
| Activación automática por `description` | Sí. **No hay forma de impedirla**: la `description` es el único freno |
| `context: fork`, `agent:` | Se ignoran: la skill corre en el agente principal |
| `user-invocable`, `disable-model-invocation` | Se ignoran. Las skills internas aparecen en `/` |
| `disable-slash-command: true` | No documentado (lo usa una skill integrada); no impidió invocar con `/` en modo headless |
| `model`, `allowed-tools` | Se ignoran (en Antigravity solo existen en los subagentes) |

Consecuencias para una skill de entrada:
- la `description` dice "úsalo solo cuando el usuario lo pida";
- el texto pide la delegación en el agente y se detiene si no puede ([skills.md](skills.md#skill-de-entrada-que-delega-en-un-agente)).

## Subagentes

Antigravity tiene subagentes propios en `.agents/agents/<name>.md` (o `<name>/agent.md`):
- el cuerpo es el system prompt;
- el agente principal delega con la herramienta **`invoke_subagent`** (rol + prompt inicial);
- el subagente arranca con el contexto vacío y corre en paralelo; se supervisa en el panel `/agents`.

### Traducción del aprovisionador

`provision_agents_antigravity.py` lee `apm_modules/**/.apm/agents/*.agent.md` y escribe `.agents/agents/<name>.md`:

| Campo en `.agent.md` | En Antigravity | Traducción |
|---|---|---|
| `name`, `description` | `name`, `description` (obligatorios) | Se copian |
| `tools: Read` | `view_file` | Traducción verificada |
| `tools: Grep` | `grep_search` | Traducción verificada |
| `tools: Glob` | `find_by_name` | Traducción verificada |
| `tools: LS` | `list_dir` | Traducción verificada |
| `tools: Bash` | `run_command` | Traducción verificada |
| `tools: Write` | `write_to_file` | Traducción verificada |
| `tools: Edit` | `replace_file_content` | Traducción verificada |
| `tools: WebFetch` | `read_url_content` | Traducción verificada |
| `tools: WebSearch` | `search_web` | Traducción verificada |
| `tools: Task` / `Agent` | `invoke_subagent` | Traducción verificada |
| Cualquier otro nombre (`Skill`, …) | — | **Error**: el script falla en lugar de generar un agente que se cuelga |
| Sin `tools` | todas las herramientas | El aprovisionador las emite todas, delegación incluida |
| `model` | `model`: `inherit`, `flash`, `pro` | Solo `inherit` (o ausente); otro valor da error |
| `skills` | `skills` (rutas) | `../skills/<n>`. Precarga, pero **no limita**: el subagente puede usar cualquier skill del proyecto |
| `antigravity:` | `mainAgent`, `subagent`, `commandExecutionPolicy` | Se copia tal cual. Por defecto `true`, `true`, `sandbox`. Claude lo ignora |

Campos admitidos en el `.agent.md` fuente: solo `name`, `description`, `tools`, `model`, `skills` y `antigravity` (`KNOWN_KEYS` en `ai-sdlc-platform/ci/provision_agents_antigravity.py`).

Con cualquier otro campo (`color`, `effort`, `memory`…), el aprovisionador falla en lugar de descartarlo. También falla si una skill de `skills:` no está desplegada en `.agents/skills/`.

Ejemplo: `backend-java-ci` lleva `antigravity: { mainAgent: false }`. `backend-java` no declara `tools` y recibe todas, `invoke_subagent` incluida.

El script lleva un manifiesto, no pisa archivos ajenos, elimina los agentes de paquetes desinstalados y tiene `--dry-run`, `--check` y `--clean`.

### Seleccionar un agente

- `agy --agent <name>` hace que toda la sesión corra como ese agente (requiere `mainAgent: true`, el valor por defecto).
- `agy agents` **no lista** los agentes de proyecto en 1.4.8, aunque `--agent` sí los usa.
- Las @-menciones de `agy` adjuntan contexto; no eligen agente.

## Permisos y variables de entorno

| Necesidad | Claude Code | Antigravity |
|---|---|---|
| Permisos de comandos del proyecto | `.claude/settings.json` | **No existen.** `agy` no lee un `.agents/settings.json`. Solo `~/.gemini/antigravity-cli/settings.json`, global para toda la máquina |
| Variables de entorno del proyecto | `env` en `settings.json` | **No hay equivalente.** Se exportan en la shell antes de abrir `agy` |
| Directorio fuera del proyecto | `additionalDirectories` | `agy --add-dir <ruta>` |

Consecuencias:
- En modo interactivo, `agy` pide confirmación para cada comando no permitido.
- En modo headless (`agy -p`), lo no permitido se deniega. Para ejecutar `gh_pr.py` hace falta la regla global `{"permissions": {"allow": ["command(python3)"]}}`, que afecta a toda la máquina.
- La barrera "solo lectura" de la demo se monta con un hook propio (`demo-permissions`) que responde `allow` o `ask`.

Para la remediación de SARIF ([sarif-remediation-java-flow.md](../../2-architecture/sarif-remediation-java-flow.md#barreras)):
- Las mismas reglas por subcomando de `deliver_change.py` que en Claude (libres: `preflight|prepare|status|commit|revert|verify|cleanup`; `push` y `pr-create` piden confirmación; denegar `git push*`, `gh pr*`, `claude *`, `agy *`) se montan con `commandExecutionPolicy` del agente y un hook propio, porque no hay permisos de proyecto.
- La caché privada con los worktrees (raíz en `AI_SDLC_CACHE_DIR` o un directorio temporal por usuario) se declara con `agy --add-dir <ruta>`.
- Variables como `GIT_CHANGE_PUBLISH` se exportan en la shell antes de abrir `agy`: no lee `env` de proyecto.
- En headless (`agy -p`) hace falta la regla global `command(python3)`.
- **El modelo no se puede fijar**: no hay campo portable. Sale de la sesión `agy` ([mejoras-pendientes.md](../../2-architecture/mejoras-pendientes.md#n10-antigravity-no-puede-fijar-sonnet)).

## Hooks

APM despliega los hooks en `.agents/hooks.json`, contenedor `apm`. Contrato de un hook `PreToolUse` en `agy` 1.4.8:

| | Antigravity |
|---|---|
| Comando en el evento | `toolCall.args.CommandLine` |
| Bloquear | `{"decision":"deny","reason":…}` en stdout, código **0** |
| Código 2 | bloquea, pero se muestra como "hook failed" |
| Pedir confirmación | `{"decision":"ask"}`; en modo headless equivale a denegar |
| Conceder permiso | **no** en modo headless; ni `allow` ni `permissionOverrides` bastan |
| Hook que falla | **bloquea todas las herramientas**, `invoke_subagent` incluida |

Un hook agnóstico detecta el runtime por la forma del evento y responde en el contrato de cada uno ([hooks-portables-entre-runtimes.md](../4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md), [0022](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)).

### Corrección de la ruta de los hooks

- APM (0.33.0) escribe `python3 .agents/hooks/<pkg>/…`, relativo a la raíz del proyecto.
- `agy` ejecuta los hooks desde `.agents/`, así que la ruta queda `.agents/.agents/…`. El hook falla y `agy` bloquea todo.
- El aprovisionador reescribe la ruta como absoluta y elimina la entrada duplicada que APM vuelve a añadir en cada install.
- Por eso `apm audit` informa de *drift* en `.agents/hooks.json`. Es esperado: sale con 0.

## Plugins y marketplace

Antigravity tiene plugins propios, pero **la plataforma no los usa**: en Antigravity los paquetes se instalan con `apm install`.

El marketplace de la plataforma (`ai-sdlc-platform`) es solo de Claude Code ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).

| | Claude Code | Antigravity |
|---|---|---|
| Manifiesto | `.claude-plugin/plugin.json`, en una subcarpeta del plugin | `plugin.json` **en la raíz** del plugin (también acepta `.antigravity-plugin/plugin.json`) |
| Campos del manifiesto | `name`, `version`, `description`, `author`… (los genera `apm pack`) | `name` (obligatorio en la CLI, `^[a-zA-Z0-9-_]+$`), `description`, `$schema` (`additionalProperties: false`). El skill integrado lista además `author`, `homepage` y `repository`: **la documentación discrepa** |
| Contenido | `skills/`, `agents/`, hooks, MCP | `skills/`, `agents/`, `rules/` (se recomienda `AGENTS.md`), `hooks.json` en la raíz, `mcp_config.json`. **Sin `commands/`** |
| Dónde se descubre | lo instala `/plugin install` | `.agents/plugins/<name>/` (proyecto), `~/.gemini/config/plugins/` (global), `~/.gemini/antigravity-cli/plugins/` (staging de la CLI) |
| Instalar | `/plugin marketplace add …` + `/plugin install <p>@<mp>` | `agy plugin install <p>@antigravity-plugins-official` (o sin sufijo), una URL de GitHub o una ruta local |
| Marketplace | de terceros, con `marketplace.json` (el nuestro: `ai-sdlc-platform`) | **Solo el oficial**, `antigravity-plugins-official`; publicar en él requiere un formulario. La CLI 1.4.8 muestra `link <mp> <target>` y `plugin@marketplace`, pero no hay documentación de marketplaces de terceros ni de su catálogo |
| Importar desde Claude | — | `agy plugin import [source]` ("from gemini or claude"). El skill integrado dice que traslada `hooks/hooks.json` de un plugin de Claude. **No está en la documentación web: sin verificar** |

Fuentes: [antigravity.google/docs/plugins](https://antigravity.google/docs/plugins), [antigravity.google/docs/marketplace](https://antigravity.google/docs/marketplace), el skill integrado `agy-customizations` y `agy plugin --help` (1.4.8).

## Limitaciones comprobadas

Comprobado con `agy` 1.4.8 y APM 0.33.0:

| Limitación | Consecuencia / solución |
|---|---|
| APM no despliega agentes | El aprovisionador los genera desde el `lifecycle` del consumidor |
| APM solo ejecuta los `lifecycle` de la máquina, del usuario y del proyecto | Quien instala declara el `lifecycle` y ejecuta `apm lifecycle trust` |
| El `targets:` de cada paquete importa | Sin `antigravity`, APM se salta el paquete aunque se pase `--target` (`Package targets [claude] do not overlap … skipping`) |
| Ruta de hooks relativa a la raíz | El aprovisionador la corrige; si no, `agy` bloquea todas las herramientas |
| Sin freno a la activación automática de skills | Solo la `description` |
| `context: fork` y `agent:` se ignoran | La delegación se pide en el texto de la skill |
| `skills:` de un subagente no limita | Precarga, pero el subagente puede usar cualquier skill del proyecto |
| El tool `Skill` no tiene traducción | Usar `skills:` |
| `agy agents` no lista los agentes de proyecto | Comprobar con `agy -p "hola" --agent <name>` |
| Sin permisos ni `env` de proyecto | Regla global en `~/.gemini/antigravity-cli/settings.json`; variables exportadas en la shell |
| Un hook no concede permisos en headless | Regla global `command(python3)` para `agy -p` |
| Con la política `sandbox` por defecto | El subagente puede ejecutar `gh` con red y con la sesión iniciada |
| Sin marketplace de terceros documentado ni acción de CI | Instalación con `apm install`; CI solo en Claude |

## Fuente oficial

- [Skills — antigravity.google](https://antigravity.google/docs/skills)
- [Subagents — antigravity.google](https://antigravity.google/docs/subagents)
- [CLI reference — antigravity.google](https://antigravity.google/docs/cli/reference)
- [Plugins — antigravity.google](https://antigravity.google/docs/plugins)
- [APM — Targets matrix, Antigravity](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity)
