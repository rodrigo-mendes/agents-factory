# Ficha de runtime: Claude Code

> **Para quién:** quien ejecuta, depura o revisa un paquete en Claude Code.
> **Qué responde:** qué lee Claude Code de cada primitiva, dónde lo despliega APM, cómo se controla la invocación, los permisos y los hooks, y qué queda solo como formato histórico (commands) o solo de Claude (plugin y marketplace).

## En resumen

- APM despliega en `.claude/`. Claude Code lee todo el frontmatter de skills y subagentes.
- Los campos de control (`context: fork`, `agent:`, `disable-model-invocation`, `user-invocable`) **solo funcionan aquí**. Un paquete agnóstico los usa, pero no depende solo de ellos ([skills.md](skills.md#skill-de-entrada-que-delega-en-un-agente)).
- Los commands existen en Claude Code, pero **están prohibidos en cualquier paquete** ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)). Aquí se describen solo como historia.
- El plugin y el marketplace son solo de Claude Code.

Las primitivas agnósticas están en [skills.md](skills.md) y [subagents.md](subagents.md). Cómo corre cada tipo de entrada en Claude está en [modelo-ejecucion-claude-code.md](../3-modelo-operativo/modelo-ejecucion-claude-code.md).

## Layout en `.claude/`

```
.claude/
├── skills/<name>/SKILL.md      # skills, incluidas las skills de entrada
├── agents/<name>.md            # subagentes (desde .apm/agents/<name>.agent.md)
├── rules/<name>.md             # instructions (applyTo)
└── settings.json               # hooks desplegados por APM, permisos y env del proyecto
.mcp.json                       # servidores MCP
```

## Frontmatter de una skill

| Campo | Valores | Uso en Claude Code |
|---|---|---|
| `name` | string = directorio | Identidad y nombre `/name` |
| `description` | string | Activación automática por *description matching* |
| `allowed-tools` | lista | Restringe herramientas al activarse. Es de skills; un subagente usa `tools`. El campo equivocado no da error: se ignora |
| `disallowed-tools` | lista | Excluye herramientas puntuales |
| `model` | id de modelo | Fuerza un modelo distinto |
| `effort` | `low` \| `medium` \| `high` \| `xhigh` \| `max` | Esfuerzo de razonamiento |
| `paths` | lista de globs | Limita la activación a esas rutas |
| `arguments` | lista de nombres | Argumentos con nombre (`$a`, `$b`) además de `$ARGUMENTS` |
| `argument-hint` | string | Pista en el menú `/` |
| `disable-model-invocation` | boolean | Ver [Control de invocación](#control-de-invocación) |
| `user-invocable` | boolean | Ver [Control de invocación](#control-de-invocación) |
| `context` | `fork` | Ejecuta la skill dentro de un subagente aislado |
| `agent` | nombre de agente | Con `context: fork`, qué agente la ejecuta |
| `background` | boolean | Con `context: fork`, si corre en segundo plano por defecto |

### Control de invocación

| Frontmatter | La invoca el usuario | La invoca Claude |
|---|---|---|
| (por defecto) | sí | sí |
| `disable-model-invocation: true` | sí | no: la `description` ni entra en contexto |
| `user-invocable: false` | no (no sale en `/`) | sí |

- `disable-model-invocation: true` tiene coste cero hasta que alguien teclea el nombre.
- Antigravity ignora los dos campos. Por eso la skill de entrada lleva además una `description` "úsalo solo cuando el usuario lo pida" ([runtime-antigravity.md](runtime-antigravity.md#skills)).

### `context: fork`, `agent:` y `background:`

En Claude Code, `context: fork` + `agent: <agente>` ejecutan la skill **dentro** de ese subagente, sin el historial de quien la invoca. Es como corre `/review-pr-java` en Claude: entra directamente por la rama "eres el agente".

**Regla para Claude: `context: fork` y `disable-model-invocation: true` van juntos.** Con solo uno de los dos:

| Configuración | Qué falla |
|---|---|
| `context: fork` sin `disable-model-invocation` | El modelo puede activar sola la skill, y su `description` consume tokens en cada sesión |
| `disable-model-invocation` sin `context: fork` | Solo se invoca por nombre, pero corre en el contexto de quien llama, sin aislamiento |

En un paquete agnóstico, además, la delegación se pide en el texto ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)), porque Antigravity ignora estos campos.

### Tres mecanismos que se confunden

| Mecanismo | Dónde se declara | ¿Hereda historial y herramientas? |
|---|---|---|
| `context: fork` | frontmatter de una skill | **No**: arranca aislado |
| `fork: true` | parámetro de la herramienta `Agent` | **Sí**: hereda contexto, historial y herramientas |
| `isolation: worktree` | frontmatter de un subagente | No aplica: aísla archivos (git worktree), no contexto |

Los dos primeros comparten la palabra "fork" y hacen lo contrario ([fuente](https://code.claude.com/docs/en/sub-agents.md#core-parameters)).

## Frontmatter de un subagente

| Campo | Valores | Uso en Claude Code |
|---|---|---|
| `name` | string | Identidad |
| `description` | string | Selección automática cuando nadie nombra el agente |
| `tools` | lista | **Reemplaza** el pool heredado. Sin `tools`, hereda todas |
| `disallowedTools` | lista | Excepciones dentro de `tools` |
| `model` | id o `inherit` | Modelo del agente |
| `skills` | lista | Precarga el contenido completo de esas skills |
| `maxTurns` | número | Límite de turnos |
| `permissionMode` | string | Modo de permisos dentro del agente |
| `memory` | `user` \| `project` \| `local` | Persistencia entre sesiones |
| `isolation` | `worktree` | Git worktree propio |
| `mcpServers` | lista | Servidores MCP del agente |
| `initialPrompt` | string | Prompt inyectado antes del mensaje de delegación |
| `hooks` | definición | Hooks propios del agente |
| `effort` | `low` … `max` | Esfuerzo de razonamiento |
| `omitClaudeMd` | boolean | Si `true`, no hereda la jerarquía de `CLAUDE.md` |
| `background` | boolean | Si corre en segundo plano por defecto |
| `color` | string | Color en la interfaz |
| `antigravity` | bloque | Se ignora (es para el aprovisionador de Antigravity) |

Qué recibe un subagente al arrancar: su system prompt (el cuerpo), el mensaje de delegación, la jerarquía de `CLAUDE.md` (salvo `omitClaudeMd`), una foto del `git status`, las skills de `skills:` y la lista de agentes hermanos.

### Herramientas de delegación

- **`Agent`** (o `Task`) permite delegar en otro subagente. Sin ella, la delegación descrita en el cuerpo no ocurre.
- **`Skill`** permite cargar cualquier skill en tiempo de ejecución. No tiene traducción en Antigravity: en un paquete agnóstico se usa `skills:` ([subagents.md](subagents.md#delegar-desde-un-agente-agent-y-skill)).

### Profundidad de delegación

Por defecto, un subagente puede lanzar sub-subagentes hasta **3 capas** por debajo de la conversación principal. Se cambia con `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH` (por ejemplo, `"1"`) ([fuente](https://code.claude.com/docs/en/agent-sdk/subagents.md#cap-subagent-depth-concurrency-and-spend)).

El límite de diseño del repo es más estricto: [cap-fanout-depth.md](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md).

## Permisos y variables de entorno (`settings.json`)

Claude Code lee la configuración **del proyecto** en `.claude/settings.json`:

| Clave | Para qué | Ejemplo en la plataforma |
|---|---|---|
| `permissions.allow` | Comandos que se ejecutan sin preguntar | Solo los subcomandos de lectura de `gh_pr.py` (barrera 1 de la demo) |
| `env` | Variables de entorno de la sesión | `GH_PR_PUBLISH=0` (barrera 2: `gh_pr.py` rechaza escribir) |
| `additionalDirectories` | Directorios fuera del proyecto | El directorio temporal de los patches |
| `agent` | Toda la sesión como un agente | Equivale a `claude --agent <name>` |

Para CI hay una sola regla comodín para `gh_pr.py`; el detalle está en el README de `ai-sdlc-backend-java`.

### Remediación de SARIF (`deliver_change.py`)

Permisos por subcomando, para `/remediate-sarif-java` ([sarif-remediation-java-flow.md](../../2-architecture/sarif-remediation-java-flow.md#barreras)):

| Regla | Subcomandos / patrón |
|---|---|
| `allow` | `deliver_change.py preflight\|prepare\|status\|commit\|revert\|verify\|cleanup`, además de `sarif.py *` y `java_build.py *` |
| Piden confirmación (`ask`) | `deliver_change.py push`, `pr-create` |
| `deny` | `Bash(git push*)`, `Bash(gh pr*)`, `Bash(claude *)`, `Bash(agy *)` |
| `additionalDirectories` | la caché privada donde viven los worktrees. Su raíz sale de la variable `AI_SDLC_CACHE_DIR` o, si no existe, de un directorio temporal por usuario |

Sin `additionalDirectories`, el subagente `backend-java-fix` no puede editar el worktree (fuera del proyecto).

**El modelo se fija solo en los puntos de invocación**, porque `model` en el frontmatter del agente solo admite `inherit`: `model: sonnet` en la skill de entrada, `model` en la llamada a `Agent` y `claude -p --model sonnet` en headless.

## Hooks

APM despliega los hooks del paquete en `.claude/settings.json`. Contrato de un hook `PreToolUse`:

| | Claude Code |
|---|---|
| Comando en el evento | `tool_input.command` |
| Bloquear | código de salida **2** + motivo en stderr |
| Hook que falla | se informa del error (en Antigravity, en cambio, bloquea todas las herramientas) |

Un hook agnóstico implementa este contrato y el de Antigravity en el mismo script ([hooks-portables-entre-runtimes.md](../4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md), [0022](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)).

## Commands — formato histórico (prohibido en paquetes nuevos)

**Ningún paquete usa commands ni prompts**, ni nuevos ni existentes ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md), que reemplaza a [0012](../5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md)).

Esta sección existe para reconocer el formato en repos antiguos y migrarlo.

### Por qué están prohibidos

Según la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):
- `commands` solo existe en Claude Code;
- `prompts` (`.apm/prompts/*.prompt.md`) no se despliega como tal en ningún target. En Claude, APM lo convierte en un command en `.claude/commands/`.

Un punto de entrada escrito así no llega a Antigravity, y no da error. Una skill, en cambio, es invocable con `/nombre` en los dos runtimes.

### Cómo era el formato

- Un archivo plano por command: `.claude/commands/<name>.md`. Sin directorio propio ni archivos de soporte.
- La identidad la da el nombre del archivo.
- Claude Code documenta que commands y skills comparten frontmatter y se invocan igual con `/nombre`. La diferencia real era de empaquetado: la skill tiene directorio para archivos de soporte.
- Si un command y una skill tienen el mismo nombre, gana la skill, según la documentación de Claude. Aun así, eran dos archivos para un nombre: el antipatrón que señalaba 0012.

### El caso real de la plataforma

`ai-sdlc-backend-java` tenía dos piezas para `/review-pr-java`:
- el prompt `.apm/prompts/review-pr-java.prompt.md`, desplegado como `.claude/commands/review-pr-java.md`;
- el envoltorio `pr-review-java` (`context: fork` + `agent: backend-java`).

Las dos se sustituyeron por `.apm/skills/review-pr-java/SKILL.md`. Lo que teclea el usuario no cambió.

### Lo que hacía un command → skill equivalente

| Lo que hacía el command | Skill equivalente |
|---|---|
| Acción `/nombre` de un solo archivo | `.apm/skills/<nombre>/SKILL.md`, sin fork: corre inline |
| Delegar en un subagente (`tools: Agent`) | Skill de entrada con `context: fork` + `agent:` + `disable-model-invocation: true` y la delegación pedida en el texto |
| Ejecutar una skill con `context: fork` | La propia skill es la entrada; se borra el command |
| Recibir argumentos (`$ARGUMENTS`) | `$ARGUMENTS` y `argument-hint` en la skill, con un valor por defecto si llega vacío |
| Solo invocación explícita | `disable-model-invocation: true` (Claude) y una `description` "solo cuando el usuario lo pida" (Antigravity) |
| Prompt de APM `.apm/prompts/<n>.prompt.md` | `.apm/skills/<n>/SKILL.md` |

Plantilla y pasos en [puntos-de-entrada-como-skills.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md).

## Plugin y marketplace

El plugin y el marketplace son **solo de Claude Code**. En Antigravity los paquetes se consumen con `apm install` ([plugins.md](plugins.md), [0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).

### Qué es un plugin de Claude Code

Un bundle de skills, agentes, hooks y servidores MCP con nombre, versión y metadatos propios. Claude Code lo instala con:

```text
/plugin marketplace add <repo-del-marketplace>
/plugin install <plugin>@<marketplace>        # ej.: backend-java@ai-sdlc-platform
```

### Layout de un plugin

```
mi-plugin/
├── .claude-plugin/
│   └── plugin.json      # solo el manifiesto vive aquí
├── skills/              # en la raíz del plugin, no dentro de .claude-plugin/
├── agents/
├── hooks/
│   └── hooks.json
├── .mcp.json
└── LICENSE
```

- Error común: poner `skills/` o `agents/` dentro de `.claude-plugin/`. Van en la raíz.
- `.claude-plugin/` solo contiene `plugin.json` y, si el repo también es marketplace, `marketplace.json`.
- El formato de Claude admite una carpeta `commands/`. Los paquetes de la plataforma **no la usan**: está prohibida (sección anterior).

Separar el manifiesto del contenido permite que una herramienta externa (aquí APM) genere el manifiesto sin tocar el contenido.

### Manifiesto (`plugin.json`)

| Campo | Formato | Notas |
|---|---|---|
| `name` | string, kebab-case | Obligatorio |
| `version` | string | — |
| `description` | string | — |
| `author` | objeto | — |
| `displayName` | string | — |
| `homepage` | string (URL) | — |
| `repository` | string (URL) | — |
| `license` | string | — |
| `keywords` | lista de strings | — |
| `metadata` | objeto libre | — |

### Marketplace

- Un marketplace es un catálogo (`marketplace.json`) que lista plugins y dónde encontrarlos.
- El de la plataforma es `ai-sdlc-platform/.claude-plugin/marketplace.json`. Apunta a la rama `claude-plugin` de cada paquete, que publica la action `ai-sdlc-publish-plugin` (`apm pack --format claude-plugin`).
- El detalle de cómo se genera está en [distribucion-claude-code.md](../3-modelo-operativo/distribucion-claude-code.md).

### Nota sobre este repo: plugin.json no se escribe a mano

En `ai-sdlc-platform` y en los paquetes que agrega, `plugin.json` **no es un archivo fuente**:
- lo produce `apm pack` a partir de `apm.yml`, con el mismo mecanismo que genera `marketplace.json`;
- solo aparece en `build/<nombre>-<version>/plugin.json`;
- Claude Code define el formato de destino; APM decide cuándo y con qué contenido se genera.

Así el equipo tiene un catálogo de lo que puede instalar sin mantener el manifiesto a mano en cada repo.

### CI

La revisión en CI usa `anthropics/claude-code-action` con el agente `backend-java-ci` (workflow `pr-review-backend-java.yml`). Antigravity no tiene acción equivalente.

## Fuente oficial

- [Skills — code.claude.com](https://code.claude.com/docs/en/skills.md)
- [Subagents — code.claude.com](https://code.claude.com/docs/en/sub-agents.md)
- [Commands — code.claude.com](https://code.claude.com/docs/en/commands.md)
- [Plugins — code.claude.com](https://code.claude.com/docs/en/plugins.md)
- [Plugins reference — code.claude.com](https://code.claude.com/docs/en/plugins-reference.md)
