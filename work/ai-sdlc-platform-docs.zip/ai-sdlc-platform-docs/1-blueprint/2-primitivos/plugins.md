# Plugins

> **Para quién:** quien se pregunta si un paquete de la plataforma debería distribuirse como plugin.
> **Qué responde:** qué es un plugin, por qué la plataforma distribuye con `apm install`, y en qué se diferencian los plugins de Claude Code y de Antigravity.

## En resumen

- Un plugin es un **bundle instalable** de skills, agentes, reglas, hooks y servidores MCP, con nombre y versión.
- Cada runtime tiene su propio formato de plugin, y **no son compatibles** entre sí (tabla abajo).
- La plataforma distribuye con **`apm install`**, que despliega el mismo origen en los dos runtimes ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).
- El plugin y el marketplace de la plataforma son **solo de Claude Code**, y los genera `apm pack`.

## Qué es un plugin

Un plugin define **cómo se estructura en disco** un bundle de primitivas, en un formato que un runtime sabe instalar. No define:
- cómo se resuelven sus dependencias entre repos;
- cómo se versiona de forma transitiva;
- cómo se publica en un catálogo.

Eso es trabajo de un gestor de paquetes. En la plataforma, APM ([distribucion.md](../3-modelo-operativo/distribucion.md)).

## Por qué la plataforma distribuye con `apm install`

| Necesidad | Plugin | `apm install` |
|---|---|---|
| Un solo origen para los dos runtimes | No: un formato por runtime | Sí: `targets: [claude, antigravity]` |
| Dependencias transitivas entre repos | No | Sí (`apm.yml`, `apm.lock.yaml`) |
| Catálogo propio de la organización | Solo en Claude Code | Genera el `marketplace.json` de Claude |
| Antigravity | Solo el marketplace oficial | Despliegue en `.agents/` + aprovisionador ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) |

Por eso el plugin de Claude es una **salida** de APM (`apm pack`), no la fuente. En Antigravity no se genera plugin.

## Claude Code frente a Antigravity

| | Claude Code | Antigravity |
|---|---|---|
| Manifiesto | `.claude-plugin/plugin.json`, en una subcarpeta del plugin | `plugin.json` en la raíz (también `.antigravity-plugin/plugin.json`) |
| Contenido | `skills/`, `agents/`, hooks, MCP | `skills/`, `agents/`, `rules/`, `hooks.json`, `mcp_config.json`. Sin `commands/` |
| Instalar | `/plugin marketplace add …` + `/plugin install <p>@<mp>` | `agy plugin install <p>@antigravity-plugins-official`, una URL de GitHub o una ruta local |
| Marketplace | De terceros, con `marketplace.json`. El nuestro: `ai-sdlc-platform` | Solo el oficial; no hay marketplaces de terceros documentados |
| Uso en la plataforma | Sí: generado por `apm pack` | No: se instala con `apm install` |

Detalle de cada formato:
- Claude Code: [runtime-claude-code.md](runtime-claude-code.md#plugin-y-marketplace).
- Antigravity: [runtime-antigravity.md](runtime-antigravity.md#plugins-y-marketplace), con las discrepancias de su documentación.

## Cuándo NO hace falta un plugin

- Una sola skill o un agente en un solo repo y para **un** runtime → basta el archivo suelto en `.claude/` o `.agents/`.
- Si tiene que funcionar en los dos runtimes → paquete APM, aunque sea un solo repo.
- Un catálogo de lo que existe → eso es un marketplace, no un plugin ([distribucion.md](../3-modelo-operativo/distribucion.md)).

## Nota sobre este repo: plugin.json no se escribe a mano

Lo genera `apm pack` desde `apm.yml` y solo aparece en `build/`. Detalle en [runtime-claude-code.md](runtime-claude-code.md#nota-sobre-este-repo-pluginjson-no-se-escribe-a-mano).

## Fuente oficial

- [Plugins — code.claude.com](https://code.claude.com/docs/en/plugins.md)
- [Plugins — antigravity.google](https://antigravity.google/docs/plugins)
