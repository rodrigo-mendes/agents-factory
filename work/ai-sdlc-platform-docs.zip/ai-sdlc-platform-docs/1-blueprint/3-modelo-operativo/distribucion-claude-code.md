# Distribución en Claude Code

> **Para quién / qué responde:** para quien publica un paquete en el marketplace de Claude Code o lo usa en CI. Qué genera `apm pack`, cómo es el catálogo `marketplace.json` y qué valida APM del frontmatter.

**Conclusión:** en Claude Code hay dos vías: `apm install` (la común, ver [distribucion.md](distribucion.md)) y el marketplace, que se alimenta con `apm pack`. **El marketplace es solo de Claude**: Antigravity tiene plugins propios pero no documenta marketplaces de terceros.

Ver también:
- [Distribución (agnóstico)](distribucion.md).
- [Distribución en Antigravity](distribucion-antigravity.md).
- [Ficha del runtime Claude Code](../2-primitivos/runtime-claude-code.md) — plugin y marketplace, frontmatter.

---

## Qué añade Claude Code a la vía común

| Pieza | Qué es | Quién la produce |
|---|---|---|
| `plugin.json` | Manifiesto del bundle de plugin | `apm pack` |
| `.claude-plugin/marketplace.json` | Catálogo que lee `/plugin marketplace add` | `apm pack` |
| Rama `claude-plugin` | Rama donde se publica el bundle para los consumidores del marketplace | CI de `ai-sdlc-platform` (`ai-sdlc-publish-plugin`) |
| `claude-code-action` | Revisión headless en GitHub Actions (ej. `pr-review-backend-java.yml` con `backend-java-ci`) | Workflow reutilizable de `ai-sdlc-platform` |

Frontera exacta:
- Claude Code sabe **leer** `plugin.json` y `marketplace.json`; por eso funcionan al instalarse.
- No tiene comando nativo para **generarlos** ni **resolverlos**: eso es 100 % APM.
- `plugin.json` no se escribe a mano ([plugins.md](../2-primitivos/plugins.md)).

### Layout tras `apm pack`

```
build/<nombre>-<version>/plugin.json
.claude-plugin/marketplace.json
```

### Instalar desde el marketplace

Tras añadir el marketplace con `/plugin marketplace add MyInvestor-Core/ai-sdlc-platform`:

```text
/plugin install backend-java@ai-sdlc-platform
```

---

## Comandos propios de esta vía

| Comando | Función |
|---|---|
| `apm pack` | Genera `plugin.json` (bundle) y `.claude-plugin/marketplace.json` |
| `apm marketplace` | Gestión de marketplace (publicación, listado) |

`apm pack` resuelve cada entrada remota contra `git ls-remote`, deja intactas las entradas de ruta local y escribe cada marketplace de forma atómica.

---

## `marketplace.json` — esquema que produce APM

| Campo | Formato | Notas |
|---|---|---|
| `name` | string | ID del marketplace |
| `owner` | objeto `{name, email?, url?}` | `name` obligatorio |
| `plugins` | lista | cada entrada: `name`, `source` |
| `plugins[].source` | string, u objeto `{source: github\|url\|git-subdir\|npm\|archive\|command, repo, ref}` | Claude Code usa `source`; Copilot CLI usa `repository`/`ref`. APM genera el formato de cada target |
| `plugins[].description`, `.version`, `.displayName`, `.category`, `.tags`, `.defaultEnabled` | metadatos opcionales | — |

---

## Frontmatter: qué valida APM y qué no

- APM valida un subconjunto pequeño y común a varios harnesses: `name` y `description`, y en agentes también `model`, `tools`, `color` y `handoffs`.
- El resto pasa **sin validar** hacia `.claude/`, incluidas las extensiones de Claude Code: `skills:` (precarga), `context: fork`, `disable-model-invocation`, `memory`, `isolation`.
- No dependas de APM para comprobar esos campos. La tabla completa está en [runtime-claude-code.md](../2-primitivos/runtime-claude-code.md); el contenido agnóstico, en [skills.md](../2-primitivos/skills.md) y [subagents.md](../2-primitivos/subagents.md).

---

## Fuentes oficiales (Microsoft)

- [Guía: Plugins](https://microsoft.github.io/apm/guides/plugins/)
- [Guía: Marketplaces](https://microsoft.github.io/apm/guides/marketplaces/)
- [Publish to a marketplace](https://microsoft.github.io/apm/producer/publish-to-a-marketplace/)
- [Referencia CLI: apm marketplace](https://microsoft.github.io/apm/reference/cli/marketplace/)
