# Distribución con APM (agnóstico)

> **Para quién / qué responde:** para quien publica o instala un paquete. Cómo llega un paquete escrito una vez en `.apm/` a cada runtime (Claude Code, Antigravity), qué hace APM y qué hay que declarar.

**Conclusión:** APM es la única pieza que despliega el mismo origen en los dos runtimes. Cada paquete declara `targets: [claude, antigravity]` y quien instala ejecuta `apm install`. Lo que APM no cubre en Antigravity lo completa un aprovisionador; el marketplace es solo de Claude.

Detalle de cada runtime:
- [Distribución en Claude Code](distribucion-claude-code.md) — `apm pack`, `plugin.json`, `marketplace.json` y CI.
- [Distribución en Antigravity](distribucion-antigravity.md) — qué no despliega APM, aprovisionador, `lifecycle` y plugins de Antigravity.

---

## Diagrama de distribución

**No es flujo de ejecución** (eso está en [modelo-ejecucion.md](modelo-ejecucion.md)). Es la vista de *build/install-time*:
- APM lee el `apm.yml`, resuelve las dependencias y despliega en cada runtime de `targets:` ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).
- Ningún runtime "llama" a APM: APM instala *hacia* ellos.

```mermaid
flowchart TD
    subgraph PKG["Paquete APM — unidad de distribución (.apm/)"]
        direction TB

        subgraph ROLES["ROLES"]
            AG["Agents<br/>Persona + Tools<br/>ej. ai-sdlc-agent-backend-java"]
            MCP["MCP<br/>Tools"]
            MCP --> AG
        end

        subgraph CAP["CAPACIDADES"]
            CORE["Core Skills<br/>Process / Orchestrator<br/>ej. ai-sdlc-core-common"]
            SHARED["Shared Skills<br/>Atomic Actions<br/>ej. ai-sdlc-shared-common"]
            TECH["Tech Skills<br/>Tech-specific<br/>ej. ai-sdlc-tech-java"]
            CORE --> SHARED
            CORE --> TECH
        end

        subgraph KB["CONOCIMIENTO"]
            KBB["KB Base<br/>Instructions + Reference<br/>ej. ai-sdlc-kb-java"]
        end

        AG --> CORE
        TECH --> KBB
    end

    PKG -- "apm.yml del consumidor<br/>(dependencies + targets)" --> APM["APM<br/>(apm install)"]
    APM -- ".claude/" --> CC["Claude Code<br/>(interactivo / claude -p)"]
    APM -- ".agents/<br/>(sin agentes)" --> AGY["Antigravity<br/>(agy / agy -p)"]
    APM -- "lifecycle post-install" --> PROV["Aprovisionador<br/>provision_agents_antigravity.py"]
    PROV -- "agentes + rutas de hooks" --> AGY

    style PKG fill:#fff,stroke:#c0392b,stroke-dasharray: 5 5
    style ROLES fill:#e8f0fe,stroke:#2c5cc5
    style CAP fill:#fff4e2,stroke:#d68910
    style KB fill:#f0e8dc,stroke:#8b6b4a
```

El catálogo `marketplace.json` y `apm pack` no aparecen: son una vía adicional, **solo de Claude Code** ([Distribución en Claude Code](distribucion-claude-code.md)).

### Equivalencia con los primitivos del blueprint

| Elemento del diagrama | Primitivo / archivo de detalle |
|---|---|
| Claude Code / skill de entrada | [modelo-ejecucion-claude-code.md](modelo-ejecucion-claude-code.md) · [skills.md](../2-primitivos/skills.md) ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)) |
| Antigravity (`agy`) | [distribucion-antigravity.md](distribucion-antigravity.md) · [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md) |
| APM | este archivo |
| Paquete (caja punteada) | [plugins.md](../2-primitivos/plugins.md) — unidad que agrupa todo lo interior |
| Agents (Persona + Tools) | [subagents.md](../2-primitivos/subagents.md) — frontmatter `tools:` |
| MCP (Tools) | `mcpServers:` en [subagents.md](../2-primitivos/subagents.md) |
| Core Skills (orquestador) | [skills.md](../2-primitivos/skills.md) — skill coordinadora |
| Shared Skills (acciones atómicas) | [skills.md](../2-primitivos/skills.md) — skill reusable, sin fork propio |
| Tech Skills (de dominio) | [skills.md](../2-primitivos/skills.md) — ej. `act-java-check-style` |
| KB Base (Instructions + Reference) | [skills.md](../2-primitivos/skills.md) — conocimiento pasivo, ej. `kb-java-best-practices` |
| Aprovisionador | [distribucion-antigravity.md](distribucion-antigravity.md) ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) |

Drill-down a nivel de repos reales en [topologia-repos.md](topologia-repos.md).

---

## Qué es APM y qué hace

- **Herramienta de terceros.** APM (Agent Package Manager) es de Microsoft; Anthropic y Google no lo documentan.
- **Objetivo:** declarar en un único `apm.yml` las skills, agentes, MCP, hooks e `instructions` que necesita un proyecto. Quien clona el repo obtiene el setup completo con `apm install`.
- **Resolución transitiva**, como npm o pip, pero para varios harnesses.
- **No interpreta** la semántica de cada runtime: mueve archivos, valida un subconjunto pequeño de campos (`name`, `description`…) y deja pasar el resto tal cual.
  - Cada runtime decide qué campos lee ([runtime-claude-code.md](../2-primitivos/runtime-claude-code.md), [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md)).

### Por qué así

- `ai-sdlc-platform` es un agregador sin código propio: declara `dependencies.apm` hacia `ai-sdlc-backend-java`, que arrastra sus dependencias transitivas.
- Cada paquete se versiona en su repo, con su ciclo de vida, y se consume desde varios agregadores sin duplicar archivos ([0003](../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md)).

### Cuándo usar y cuándo no

| Situación | ¿APM? |
|---|---|
| Tiene que funcionar en **más de un runtime** | **Siempre**, aunque sea un solo repo: APM es la única fuente que despliega en los dos |
| Se reutiliza entre varios repos, con versión y dependencias transitivas | Sí |
| Vive en un solo repo y se usa en **un solo** runtime | No hace falta: basta un archivo suelto en `.claude/` o en `.agents/` |
| Se espera que APM valide campos propios de un runtime (`context: fork`, `memory`…) | No: APM los pasa intactos, sin comprobarlos |

---

## Layout: origen y despliegue

```
mi-paquete/
  apm.yml                 # manifiesto: dependencies.apm, targets…
  apm.lock.yaml           # lockfile generado; no se edita a mano
  .apm/
    agents/<name>.agent.md
    skills/<name>/SKILL.md          # también las skills de entrada /nombre
    instructions/<name>.instructions.md
    hooks/<name>.json + hooks/scripts/
  # sin .apm/prompts/ ni commands/: prohibidos (0020)

# tras `apm install` en el consumidor:
apm_modules/<owner>/<repo>/...      # dependencias resueltas

.claude/agents/<name>.md            # target claude
.claude/skills/<name>/SKILL.md      # target claude
.claude/rules/<name>.md             # target claude
.claude/settings.json               # target claude (hooks)

.agents/skills/<name>/SKILL.md      # target antigravity
.agents/rules/<name>.md             # target antigravity
.agents/hooks.json                  # target antigravity (ruta corregida por el aprovisionador)
.agents/mcp_config.json             # target antigravity
.agents/agents/<name>.md            # NO lo despliega APM: lo genera el aprovisionador
```

---

## Qué hay que declarar

- **`targets` por paquete, obligatorio.** Cada paquete declara `targets: [claude, antigravity]`.
  - APM se salta un paquete cuyo `targets` no incluye el target activo, aunque se pase `--target` y aunque lo pida otro paquete: `Package targets [claude] do not overlap authorized active targets; skipping`. No da error.
- **El consumidor también declara `targets`** en su `apm.yml`. Antigravity no se autodetecta y queda fuera de `--target all`.
- **`lifecycle` del aprovisionador**, solo si el consumidor usa Antigravity y hay agentes o hooks ([Distribución en Antigravity](distribucion-antigravity.md)).

---

## Comandos comunes

| Comando | Función |
|---|---|
| `apm install` | Resuelve `apm.yml`, descarga a `apm_modules/` y despliega en cada target (`.claude/`, `.agents/`). `--target <t>` limita el destino |
| `apm install --update` | Fuerza el último commit de cada ref |
| `apm lifecycle trust` | Marca como confiable el bloque `lifecycle:` del proyecto. Sin ello, APM no ejecuta sus scripts (`post-install`…) |
| `apm audit` | Compara lo desplegado con lo que APM generaría e informa de *drift* |

Instala siempre sin tokens en el entorno: con `GITHUB_TOKEN` o `GITHUB_APM_PAT` exportados, `apm install` escribe credenciales en `.mcp.json`.

```bash
env -u GITHUB_TOKEN -u GITHUB_APM_PAT apm install
```

---

## Matriz de targets

Qué primitiva llega a cada runtime, según la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):

| Primitiva | `.claude/` | `.agents/` |
|---|---|---|
| `instructions` | ✅ | ✅ `rules/` |
| `prompts` | ❌ (APM lo convierte en command) | ❌ |
| `agents` | ✅ | ❌ (los genera el aprovisionador) |
| `skills` | ✅ | ✅ `skills/` |
| `commands` | ✅ | ❌ |
| `hooks` | ✅ | ✅ `hooks.json` |
| `mcp` | ✅ | ✅ `mcp_config.json` |

Por eso un paquete agnóstico usa solo agentes y skills, sin commands ni prompts ([modelo-ejecucion.md](modelo-ejecucion.md)).

---

## Target antigravity

Resumen; el detalle está en [distribucion-antigravity.md](distribucion-antigravity.md).
- Requiere **APM ≥ 0.33.0** (el CI usa 0.32.0, sin este target). Comprobado con `agy` 1.4.8.
- APM despliega reglas, skills, hooks y MCP en `.agents/`, pero **no agentes**.
- El aprovisionador genera `.agents/agents/` y corrige las rutas de los hooks. Lo dispara el `lifecycle` del consumidor, nunca el del paquete.
- Permisos y `env` no se despliegan: son globales en `agy`.
- `apm audit` informa de *drift* en `.agents/hooks.json`. Es esperado (sale con 0).

---

## Fuentes oficiales (Microsoft)

- [APM — documentación](https://microsoft.github.io/apm/)
- [Repositorio microsoft/apm](https://github.com/microsoft/apm)
- [Matriz de targets](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity)
- [Guía: Skills](https://microsoft.github.io/apm/guides/skills.md) / [Autoría de skills](https://microsoft.github.io/apm/producer/author-primitives/skills/)
- [Guía: Instructions y agents](https://microsoft.github.io/apm/producer/author-primitives/instructions-and-agents/)
