# Topología de repositorios

> **Para quién / qué responde:** para quien busca en qué repo vive cada capa y de quién depende. Es el drill-down del [Diagrama de distribución](distribucion.md#diagrama-de-distribución): los mismos nodos, como repos reales.

**Conclusión:** hoy hay tres repos de contenido más `ai-sdlc-platform`. Todos los de contenido declaran `targets: [claude, antigravity]`. Convención de nombre: `ai-sdlc-<capa>-<tema>`.

Dos vistas del mismo grafo:

```mermaid
flowchart TD
    PLATFORM["ai-sdlc-platform"]
    GH[".github"]

    subgraph PKG2["Paquete APM — unidad de distribución"]
        AGENT["ai-sdlc-agent-backend-java"]
        MCP2["MCP"]
        CORE2["ai-sdlc-core-common"]
        SHARED2["ai-sdlc-shared-common"]
        TECH2["ai-sdlc-tech-java"]
        KB2["ai-sdlc-kb-java"]

        MCP2 --> AGENT
        CORE2 -- "deps" --> SHARED2
    end

    PLATFORM -- "deps" --> AGENT
    AGENT -- "deps" --> CORE2
    AGENT -- "deps" --> TECH2
    CORE2 -- "deps" --> TECH2
    TECH2 -- "deps" --> KB2

    style PKG2 fill:#fff,stroke:#c0392b,stroke-dasharray: 5 5
```

```mermaid
block-beta
columns 3

PLATFORM["ai-sdlc-platform"] space GH[".github"]

block:PKG2["Paquete APM — unidad de distribución"]
    columns 3
    AGENT["ai-sdlc-agent-backend-java"] MCP2["MCP"] space
    CORE2["ai-sdlc-core-common"] SHARED2["ai-sdlc-shared-common"] TECH2["ai-sdlc-tech-java"]
    space space KB2["ai-sdlc-kb-java"]
end

PLATFORM -- "deps" --> AGENT
MCP2 --> AGENT
AGENT -- "deps" --> CORE2
AGENT -- "deps" --> TECH2
CORE2 -- "deps" --> SHARED2
CORE2 -- "deps" --> TECH2
TECH2 -- "deps" --> KB2

classDef pkg fill:#fff,stroke:#c0392b,stroke-width:2px,stroke-dasharray: 5 5
class PKG2 pkg
```

| Capa | Repositorio (convención objetivo) | Repositorio real hoy | Primitivas | Depende de | Marketplace |
|---|---|---|---|---|---|
| Marketplace / gobierno | `ai-sdlc-platform` | `ai-sdlc-platform` | Catálogo (marketplace solo de Claude), workflow de review en CI, linter · fuente de `ci/provision_agents_antigravity.py` ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) | — | Es el marketplace |
| Agentes | `ai-sdlc-agent-backend-java` | `ai-sdlc-backend-java` | Agente `backend-java`, `backend-java-ci`, `backend-java-remediate`, `backend-java-fix` · skills de entrada `review-pr-java` y `remediate-sarif-java` ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)) · MCP `github`, `context7` | `ai-sdlc-shared-skills`, `ai-sdlc-kb-java` | Sí |
| Core skills | `ai-sdlc-core-common` | `ai-sdlc-shared-skills` | `proc-pr-review`, `proc-sarif-remediation` | — | No |
| Shared skills | `ai-sdlc-shared-common` | `ai-sdlc-shared-skills` | `act-common-scan-security`, `act-common-write-report` (con modo `remediation`), `act-common-github-pr`, `act-common-apply-sarif`, `act-common-deliver-change` · hook `github-pr-preflight` (que también reconoce `deliver_change.py`) · copia de `provision_agents_antigravity.py` (para que llegue a `apm_modules/`) | — | No |
| Tech skills | `ai-sdlc-tech-java` | `ai-sdlc-kb-java` | `act-java-check-style`, `act-java-check-coverage`, `act-java-run-build` | — | No |
| Conocimiento | `ai-sdlc-kb-java` | `ai-sdlc-kb-java` | Instructions `std-java-coding` · skill `kb-java-best-practices` | — | No |

Cómo leer la tabla:
- **Convención objetivo:** la división ideal por capa.
- **Real hoy:** lo que existe. Las capas core y shared conviven en `ai-sdlc-shared-skills`, y las tech skills de Java viven en `ai-sdlc-kb-java`.
- **Entrada:** `/review-pr-java` y `/remediate-sarif-java` son skills de entrada, no commands ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).

Los tres repos de contenido declaran `targets: [claude, antigravity]` ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)). Si a uno le falta `antigravity`, APM se salta ese paquete al instalar para Antigravity, aunque lo pida otro.

Todo lo anterior es *build/install-time*. Qué pasa cuando alguien invoca el paquete: [modelo-ejecucion.md](modelo-ejecucion.md).
