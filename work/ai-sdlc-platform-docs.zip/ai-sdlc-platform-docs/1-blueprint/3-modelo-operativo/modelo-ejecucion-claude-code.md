# Modelo de ejecución en Claude Code

> **Para quién / qué responde:** para quien ejecuta o depura un paquete en Claude Code. Qué tipos de entrada ofrece Claude, cómo controla quién invoca una skill y cómo corren ahí las entradas agnósticas.

**Conclusión:** en Claude Code la skill de entrada corre directamente dentro del agente gracias a `context: fork` + `agent:`, y `disable-model-invocation: true` impide que el modelo la active sola. Las entradas A–D son **formato histórico**: A y B usan Commands, que están prohibidos.

Ver también:
- [Modelo de ejecución (agnóstico)](modelo-ejecucion.md) — qué usar en un paquete y la correspondencia entre runtimes.
- [Modelo de ejecución en Antigravity](modelo-ejecucion-antigravity.md).
- [Ficha del runtime Claude Code](../2-primitivos/runtime-claude-code.md) — frontmatter, permisos, `env` y hooks.

---

## 1. Tipos de entrada de Claude Code

Todas las formas de empezar trabajo que documenta Claude Code ([Skills](https://code.claude.com/docs/en/skills.md), [Subagents](https://code.claude.com/docs/en/sub-agents.md)). La última columna indica si hay equivalente en [Antigravity](modelo-ejecucion-antigravity.md).

| Tipo de entrada | Cómo se invoca | Qué se ejecuta | ¿En Antigravity? |
|---|---|---|---|
| **Skill por nombre** | `/nombre [args]` al **inicio** del mensaje; el nombre sale de `name` o del directorio | La skill, con `$ARGUMENTS`, `$0…$N` / `$ARGUMENTS[N]` o argumentos con nombre (`arguments: [a, b]` → `$a`) | ✅ `/nombre` + `$ARGUMENTS` |
| **Skill mencionada a mitad de frase** | `… y luego /deploy a staging` | No la ejecuta: autoriza a Claude a usarla si lo juzga pedido | — (no documentado) |
| **Varias skills en un mensaje** | `/write-tests /fix-issue 123` (la primera + hasta 5 más; en `claude -p`, solo la primera) | Todas, con los mismos argumentos | — (no documentado) |
| **Skill automática por `description`** | Lenguaje natural que encaja con `description` (+ `when_to_use`) | La skill, si no tiene `disable-model-invocation: true` | ✅ por `description` |
| **Command** (formato antiguo) | `/nombre` desde `.claude/commands/nombre.md` | El command; si comparte nombre con una skill, gana la skill | ❌ — **prohibido en los paquetes** |
| **Skill de plugin** | `/plugin:nombre` | La skill, con espacio de nombres. Los commands de plugin están prohibidos | Antigravity tiene plugins propios, sin commands |
| **Prompt MCP** | Como `/` ([MCP prompts as commands](https://code.claude.com/docs/en/mcp.md)) | El prompt que expone el servidor MCP | — (no documentado); no se usa como entrada de paquete |
| **Subagente automático por `description`** | Lenguaje natural; Claude delega si encaja | El subagente, con contexto aislado | ✅ el planificador delega por `description` |
| **Subagente pedido explícitamente** | "Usa el subagente `code-reviewer` para…" | El subagente nombrado (normalmente) | ✅ `invoke_subagent` |
| **Subagente por @-mención** | `@"code-reviewer (agent)"`, `@agent-<name>` o `@agent-<plugin>:<name>` | El subagente mencionado, **garantizado** | — (en `agy` las @-menciones adjuntan contexto) |
| **Sesión entera como un agente** | `claude --agent <name>` o `"agent": "<name>"` en `.claude/settings.json` (gana la opción) | Toda la conversación con ese agente | ✅ `agy --agent <name>` |
| **Agentes definidos al vuelo** | `claude --agents '{"<name>": {...}}'` | Agentes solo para esa sesión | — |
| **Headless** | `claude -p "<prompt o /skill>"` | Cualquiera de las anteriores, sin sesión interactiva | ✅ `agy -p` |
| **CI** | `anthropics/claude-code-action` (ej. `pr-review-backend-java.yml` con `backend-java-ci`) | Headless en GitHub Actions | ❌ (sin acción equivalente) |

### Control de invocación (solo Claude Code)

| Frontmatter | La invoca el usuario | La invoca Claude |
|---|---|---|
| (por defecto) | sí | sí |
| `disable-model-invocation: true` | sí | no (Claude Code bloquea la llamada) |
| `user-invocable: false` | no (no sale en `/`) | sí |

Antigravity ignora los dos campos. Allí el único freno es la `description`.

---

## 2. Cómo corren las entradas agnósticas

| Entrada agnóstica | Cómo la ejecuta Claude Code |
|---|---|
| **Skill de entrada → agente** | `context: fork` + `agent:` ejecutan la skill dentro del subagente, que entra por la rama "eres el agente". `disable-model-invocation: true` impide que Claude la active sola |
| **Agente por `description`** | Claude delega en el subagente cuya `description` encaja |
| **Skill inline** | La skill corre en el contexto principal |
| **Headless** | `claude -p "/skill …"`, con las mismas entradas |

```mermaid
sequenceDiagram
    participant U as Usuario
    participant CC as Claude Code
    participant A as Subagente backend-java
    participant S1 as Skill orquestadora (proc-pr-review)
    participant S2 as Skills especialistas / KB

    U->>CC: /review-pr-java <PR>
    CC->>A: context: fork + agent: backend-java
    Note over A: límite de aislamiento — no hereda el historial
    A->>S1: rama "eres el agente": ejecuta el proceso
    S1->>S2: roles (style, security, coverage) + KB
    S2-->>S1: hallazgos
    S1-->>A: informe
    A-->>U: solo el resultado final
```

La rama "no eres el agente" del texto no se usa en Claude: el fork ya entra en el agente. Está para los runtimes que ignoran el fork ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).

---

## 3. Formato histórico de Claude Code — no usar en paquetes nuevos

Antes de la regla agnóstica, el blueprint describía cuatro entradas (A–D). Se mantienen como referencia para leer paquetes y ADRs antiguos.

| Entrada histórica | Estado | Equivalente agnóstico |
|---|---|---|
| A — Command → Subagent | ❌ prohibida (usa Command) | Skill de entrada → agente |
| B — Command → Skill con `context: fork` | ❌ prohibida (usa Command) | Skill de entrada → agente |
| C — Subagente por `description` | ✅ sigue vigente | Agente por `description` |
| D — Skill invocada directamente | ✅ sigue vigente | Skill inline |

### Entradas A y B — Command → Subagent / Command → Skill con fork

- **A:** un Command delegaba en un subagente ya definido (`tools: Agent`). El aislamiento lo daba el subagente.
- **B:** un Command ejecutaba una skill con `context: fork` + `agent:` + `disable-model-invocation: true`. El aislamiento estaba en el frontmatter de la skill.
- Las dos se sustituyen quitando el Command: la skill es la entrada y pide la delegación en su texto ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).

```mermaid
flowchart LR
    subgraph A["A (histórica)"]
        CA["Command"] -- "tools: Agent" --> AA["Agente"]
    end
    subgraph B["B (histórica)"]
        CB["Command"] -- "ejecuta" --> SB["Skill con fork"]
    end
    subgraph N["Agnóstica (actual)"]
        SN["Skill de entrada<br/>fork + agent: + texto"] --> AN["Agente"]
    end
    AA --> P["Skill orquestadora → especialistas → KB"]
    SB --> P
    AN --> P

    style N fill:#e2f6e2,stroke:#27ae60
```

### Entrada C — Invocación directa de Subagent, sin Command

- Sin `/nombre`: el usuario describe la tarea, o un agente orquestador delega.
- Claude elige el subagente por su `description` ([subagentes](../2-primitivos/subagents.md)).
- Sigue vigente: es la entrada agnóstica "agente por `description`".
- El diagrama asume un candidato claro. Si la petición es ambigua, ver el [agente router](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md) y [0001](../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md).

```mermaid
sequenceDiagram
    participant U as Usuario / agente orquestador
    participant A as Agente (subagent)
    participant S1 as Skill orquestadora
    participant S2 as Skills especialistas / KB

    U->>A: describe la tarea (matching por description)
    Note over A: límite de aislamiento
    A->>S1: ejecuta inline
    S1->>S2: aplica checklists y consulta KB
    S2-->>S1: hallazgos
    S1-->>A: consolidado
    A-->>U: solo el resultado final
```

### Entrada D — Usuario invoca la Skill directamente, sin Command aparte

- La skill es su propia entrada: sale en el menú `/` (`user-invocable: true`, el valor por defecto).
- Sin `context: fork`, corre en el contexto de quien la llama ([skills](../2-primitivos/skills.md)).
- Sigue vigente: es la entrada agnóstica "skill inline".

```mermaid
flowchart LR
    U["Usuario<br/>/skill-orquestadora &lt;args&gt;"] --> S1["Skill orquestadora<br/>(sin context: fork)"]
    S1 --> S2["Skill especialista A"]
    S1 --> S3["Skill especialista B"]
    S3 --> S4["Skill KB"]
```
