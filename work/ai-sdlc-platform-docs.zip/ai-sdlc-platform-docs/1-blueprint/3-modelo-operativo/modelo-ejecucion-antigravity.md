# Modelo de ejecución en Antigravity

> **Para quién / qué responde:** para quien ejecuta o depura un paquete en Antigravity CLI (`agy`). Qué tipos de entrada ofrece `agy`, cómo corren ahí las entradas agnósticas y qué particularidades hay que conocer.

**Conclusión:** Antigravity ignora `context: fork` y `agent:`. La skill de entrada corre en el agente principal, que lee el texto y delega con `invoke_subagent`. Si no puede delegar, se detiene y lo dice. Comprobado con `agy` 1.4.8 en la demo `out-git/demo-pr-review-agy/`.

Ver también:
- [Modelo de ejecución (agnóstico)](modelo-ejecucion.md) — qué usar en un paquete y la correspondencia entre runtimes.
- [Modelo de ejecución en Claude Code](modelo-ejecucion-claude-code.md).
- [Ficha del runtime Antigravity](../2-primitivos/runtime-antigravity.md) — layout, campos que lee e ignora, traducción de `tools`.
- [Distribución en Antigravity](distribucion-antigravity.md) — aprovisionador, `lifecycle` y plugins.

---

## 1. Tipos de entrada de Antigravity

Según la documentación oficial ([CLI reference](https://antigravity.google/docs/cli/reference), [Subagents](https://antigravity.google/docs/subagents), [Skills](https://antigravity.google/docs/skills)) y lo comprobado con `agy` 1.4.8.

La última columna indica si hay equivalente en [Claude Code](modelo-ejecucion-claude-code.md).

| Tipo de entrada | Cómo se invoca | Qué se ejecuta | ¿En Claude Code? |
|---|---|---|---|
| **Skill por nombre** | `/<nombre> [texto]` | La skill; el texto llega en `$ARGUMENTS` (comprobado) | ✅ |
| **Skill automática por `description`** | Lenguaje natural. `agy` solo anuncia nombre y `description`; el modelo decide si la carga | La skill. **No hay** forma de impedirlo | ✅ |
| **Subagente por delegación** | El agente principal llama a `invoke_subagent` (rol + prompt inicial): lo decide el planificador, lo pide el usuario o lo pide una skill | El subagente, en paralelo y con contexto vacío. Se supervisa en `/agents` | ✅ |
| **Sesión entera como un agente** | `agy --agent <name>` o el panel `/agents` | Toda la conversación con ese agente (requiere `mainAgent: true`, el valor por defecto) | ✅ `claude --agent` |
| **Comandos integrados** | `/plan`, `/goal`, `/boost`, `/grill-me`, `/browser`, `/btw`, `/teamwork-preview` | Modos integrados: plan, objetivo autónomo, razonamiento multiagente, entrevista previa, navegador, pregunta lateral, equipos | Parcial (Claude tiene los suyos) |
| **Workflow dinámico** | Herramienta `run_workflow` (script Python con `agent`, `parallel`, `pipeline`, `phase`), skill integrado `run-workflow` | Orquestación de muchos agentes como código; `type_name` admite agentes propios | — |
| **Tareas programadas** | `/schedule <cuándo> <tarea>` o el skill integrado `/automation` | Una conversación nueva en cada ejecución | — |
| **Headless** | `agy -p "<prompt o /skill>"`; `--output-format text\|json\|stream-json`, `--json-schema`, `--print-timeout` | Cualquiera de las anteriores, sin sesión interactiva | ✅ `claude -p` |
| **Prompt inicial + interactivo** | `agy -i "<prompt>"` | Ejecuta el prompt y sigue en la sesión | ✅ |
| **Entrada estructurada** | `agy -p --input-format stream-json --output-format stream-json` | Un turno por cada mensaje NDJSON de stdin | ✅ |
| **Continuar o retomar** | `agy -c`, `--conversation <id>`, `/resume`, `/fork` | Sigue o duplica una conversación | ✅ |
| **Remote Control** | `--remote-control` o `/remote-control on` | La sesión se maneja desde otro dispositivo | ✅ |
| **@-menciones** | `@` en el prompt | **No eligen agente**: adjuntan contexto (archivos, conversaciones, terminales, reglas, MCP) | — (en Claude `@agent-…` sí elige) |
| **Workflows antiguos** | `.agents/workflows/*.md` como `/nombre` | **Obsoletos**: se migran a skills (skill integrado `migrate-workflows`) | — |

Lo que **no** existe en Antigravity:
- Commands y prompts desplegados por APM.
- `context: fork` y `agent:` en una skill.
- Control de invocación: `user-invocable` y `disable-model-invocation`. `disable-slash-command` (no documentado) no impidió invocar con `/` en modo headless.
- Elegir un subagente con una @-mención.

---

## 2. Cómo corren las entradas agnósticas

Los subagentes viven en `.agents/agents/`. No los despliega APM: los genera el aprovisionador ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

| Entrada agnóstica | Cómo la ejecuta `agy` |
|---|---|
| **Skill de entrada → agente** | La skill corre en el **agente principal**. Lee "si no eres el agente, delega" y llama a `invoke_subagent`. El subagente arranca vacío, recibe la petición literal y entra por la rama "eres el agente". Si no puede delegar, se detiene y lo explica |
| **Agente por `description`** | El planificador del agente principal delega según la `description` del subagente |
| **Skill inline** | Igual que en Claude: corre en el contexto del agente principal |
| **Headless** | `agy -p "/skill …"`, con las mismas entradas |

```mermaid
sequenceDiagram
    participant U as Usuario
    participant M as Agente principal (agy)
    participant A as Subagente backend-java
    participant S1 as Skill orquestadora (proc-pr-review)
    participant S2 as Skills especialistas / KB

    U->>M: /review-pr-java <PR>
    Note over M: la skill corre aquí — agy ignora context: fork y agent:
    M->>A: invoke_subagent(petición literal)
    Note over A: límite de aislamiento — contexto vacío
    A->>S1: rama "eres el agente": ejecuta el proceso
    S1->>S2: roles (style, security, coverage) + KB
    S2-->>S1: hallazgos
    S1-->>A: informe
    A-->>M: informe
    M-->>U: informe (sin reescribirlo)
```

En la demo, la revisión delega en `backend-java` y da el mismo resultado que en Claude Code: REQUEST_CHANGES con el blocker por inyección en campo.

---

## 3. Particularidades

### Agentes

| Tema | Comportamiento en `agy` 1.4.8 |
|---|---|
| `tools:` | Nombres propios (`view_file`, `run_command`, `invoke_subagent`…). El aprovisionador traduce los de Claude y falla con un nombre sin traducción verificada |
| Agente sin `tools` | Recibe un conjunto reducido; por eso el aprovisionador emite todas, delegación incluida |
| `skills:` en el agente | Precarga, pero **no limita** las skills que puede usar |
| Campos propios | Bloque opcional `antigravity:` (`mainAgent`, `subagent`, `commandExecutionPolicy`), que Claude ignora |
| `agy agents` | **No lista** los agentes de proyecto. `agy --agent <name>` sí los usa: compruébalo con `agy -p "hola" --agent backend-java` |

### Campos de skill que se ignoran

`context`, `agent`, `user-invocable`, `disable-model-invocation`, `model` y `allowed-tools`. No rompen nada, pero se pierde control. Por eso la skill de entrada pide la delegación en su texto y usa la `description` como freno.

### Permisos y entorno

- **Permisos solo globales:** `~/.gemini/antigravity-cli/settings.json`. `agy` no lee un `.agents/settings.json` de proyecto.
- **Sin `env` de proyecto:** las variables (`GH_PR_PUBLISH`, `TMPDIR`) se exportan en la shell antes de abrir `agy`.
- **Directorio temporal fuera del proyecto:** `agy --add-dir <ruta>`.
- **Headless:** un hook no puede **conceder** permisos en `agy -p`. Para ejecutar `gh_pr.py` hace falta la regla global `{"permissions": {"allow": ["command(python3)"]}}`. Afecta a toda la máquina: añádela solo cuando haga falta.
- **Interactivo:** no hace falta la regla; `agy` pide confirmación por comando.

### Hooks

| Tema | Comportamiento |
|---|---|
| Contrato de bloqueo | `{"decision":"deny","reason":…}` en stdout + código 0. Con código 2 también bloquea, pero lo muestra como "hook failed" ([0022](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)) |
| Hook que falla | **Bloquea todas las herramientas**, `invoke_subagent` incluida |
| Ruta desplegada | APM escribe `python3 .agents/hooks/…` (relativa a la raíz), pero `agy` ejecuta desde `.agents/`. La ruta queda `.agents/.agents/…` y el hook falla. El aprovisionador la convierte en absoluta y quita el duplicado que APM añade en cada install |

Síntoma típico de la ruta sin corregir: `/review-pr-java` responde "no puedo delegar … PreToolUse hook failed … `.agents/.agents/…`". La skill se detiene en lugar de revisar sin el agente, como pide [0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md).

### Plugins y marketplace

- Antigravity **tiene plugins** propios y un marketplace oficial, `antigravity-plugins-official`.
- No documenta marketplaces de terceros. Por eso **nuestro marketplace es solo de Claude** y en Antigravity los paquetes se consumen con `apm install --target antigravity`.
- Detalle del formato de plugin: [Distribución en Antigravity](distribucion-antigravity.md).

### CI

No hay acción de CI equivalente a `claude-code-action`.

---

## 4. Comprobaciones de la demo (`agy` 1.4.8)

| Pregunta | Resultado |
|---|---|
| ¿Una skill recibe el texto que sigue a `/nombre`? | Sí, en `$ARGUMENTS` |
| ¿Una skill puede delegar pidiéndolo en su texto? | Sí, con `invoke_subagent` |
| ¿`agy agents` lista los agentes del proyecto? | No, pero `agy --agent <nombre>` sí los usa |
| ¿`skills:` de un subagente limita lo que puede usar? | No: solo precarga |
| ¿Un hook `PreToolUse` puede bloquear? | Sí, con `deny` en stdout y código 0 |
| ¿Un hook puede conceder permiso en `agy -p`? | No: hace falta una regla global |
| ¿Se lee un `.agents/settings.json` de proyecto? | No |
| ¿Un subagente con la política por defecto (`sandbox`) puede usar `gh` con red? | Sí |
| ¿`disable-slash-command: true` impide lanzar una skill con `/`? | No (en headless se sigue pudiendo) |
| ¿Funcionan tal cual los hooks que despliega APM 0.33.0? | No: hace falta la corrección de ruta del aprovisionador |
