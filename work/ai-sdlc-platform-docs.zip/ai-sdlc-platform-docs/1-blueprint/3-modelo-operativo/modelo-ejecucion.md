# Modelo de ejecución (agnóstico)

> **Para quién / qué responde:** para quien diseña un paquete. Qué primitivas usar para que funcione en cualquier runtime (Claude Code, Antigravity) y qué camino sigue una invocación desde que entra hasta que responde.

**Conclusión:** un paquete agnóstico usa **solo agentes y skills** (más `instructions`, hooks y MCP). Todo `/nombre` es una **skill de entrada**. Si la skill tiene que correr dentro de un agente, lo declara en el frontmatter **y** lo pide en su texto.

Detalle de cada runtime:
- [Modelo de ejecución en Claude Code](modelo-ejecucion-claude-code.md) — tipos de entrada de Claude, control de invocación y formato histórico (entradas A–D).
- [Modelo de ejecución en Antigravity](modelo-ejecucion-antigravity.md) — tipos de entrada de `agy`, `invoke_subagent` y particularidades.

Otras vistas:
- [Distribución](distribucion.md#diagrama-de-distribución) — *build/install-time*: cómo llega un paquete a estar instalado.
- [Topología de repositorios](topologia-repos.md) — qué repo contiene qué capa.

---

## 1. Regla: solo agentes y skills

**Prohibido:** `commands` (`.claude/commands/`) y `prompts` (`.apm/prompts/`), en cualquier paquete ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)). No hay excepción "solo para Claude".

El motivo es que no todos los harnesses los soportan. Así lo recoge la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):

| Primitiva | Claude Code (`.claude/`) | Antigravity (`.agents/`) | ¿En un paquete agnóstico? |
|---|---|---|---|
| `instructions` | ✅ | ✅ `rules/<name>.md` (`applyTo` → `trigger: glob` + `globs`) | ✅ sí |
| `prompts` | ❌ (APM lo convierte en command) | ❌ | ❌ prohibido |
| `agents` | ✅ | ❌ (APM no los despliega) | ✅ sí; en Antigravity los genera el aprovisionador ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) |
| `skills` | ✅ | ✅ `skills/<name>/SKILL.md` | ✅ sí, también para toda entrada `/nombre` |
| `commands` | ✅ | ❌ | ❌ prohibido: no llega a Antigravity |
| `hooks` | ✅ | ✅ `hooks.json` | ✅ sí, con script portable ([0022](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)) |
| `mcp` | ✅ | ✅ `mcp_config.json` | ✅ sí |

Notas de la matriz para Antigravity:
- **Sin autodetección:** se activa con `--target antigravity` o con `targets:` en el `apm.yml`. Queda fuera de `--target all`.
- **Rutas:** `.agents/` en el proyecto y `~/.gemini/` a nivel de usuario.
- **Compilación:** genera `AGENTS.md` y omite las `instructions` ya desplegadas como reglas.

Reglas que se derivan (comprobadas en la demo `out-git/demo-pr-review-agy/`):

| Regla | Por qué |
|---|---|
| Toda entrada `/nombre` es una skill | Commands y prompts no llegan a Antigravity. `/review-pr-java` es `.apm/skills/review-pr-java/SKILL.md` |
| La skill de entrada pide la delegación **en su texto** | Antigravity ignora `context: fork` y `agent:` ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)) |
| Los agentes se escriben en `.apm/agents/*.agent.md` | El aprovisionador los traduce a `.agents/agents/` tras el install |
| Cada paquete declara `targets: [claude, antigravity]` | APM se salta un paquete sin el target activo, aunque lo pida otro |
| El comportamiento no depende de campos de un solo runtime | `user-invocable`, `disable-model-invocation`, `context: fork` y `agent:` no tienen efecto en Antigravity |

---

## 2. Jerarquía interna común

Sea cual sea la entrada y el runtime, por debajo corre la misma jerarquía. Cada nodo juega siempre el mismo rol ([tipos de skill](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md)).

```mermaid
flowchart LR
    E["Entrada"] --> A["Agente<br/>(opcional: aislamiento)"]
    A --> S1["Skill orquestadora"]
    S1 --> S2["Skill especialista A"]
    S1 --> S3["Skill especialista B"]
    S3 --> S4["Skill KB"]
```

| Nodo | Tipo de skill |
|---|---|
| Skill orquestadora | Orquestadora / coordinadora |
| Skill especialista A / B | Especialista (checklist de dominio) |
| Skill KB | Conocimiento pasivo |

- Entre entradas cambia **dónde está el aislamiento de contexto**, o si existe.
- Entre runtimes cambia **cómo se consigue** ese aislamiento.

---

## 3. Entradas agnósticas

Con solo agentes y skills hay tres formas de entrar, y las tres funcionan en los dos runtimes. Headless no es una cuarta forma: es cualquiera de ellas sin sesión interactiva.

| Entrada | Qué escribe quien diseña | Aislamiento |
|---|---|---|
| **Skill de entrada → agente** | Skill `/nombre` con `context: fork` + `agent:` + `disable-model-invocation: true`, **y** la delegación pedida en el texto | Sí, en el agente |
| **Agente por `description`** | Agente con una `description` precisa; sin skill de entrada | Sí, en el agente |
| **Skill inline** | Skill `/nombre` sin fork ni delegación | No: corre en el contexto de quien la llama |
| **Headless** | Nada extra: `claude -p` / `agy -p` con cualquiera de las anteriores | El de la entrada que use |

### 3.1 Skill de entrada → agente

Es el caso real: `/review-pr-java` delega en `backend-java`, el único agente que conoce la tabla rol → skill.

La skill lleva cuatro piezas:
- **Frontmatter de Claude:** `context: fork` + `agent: <agente>` + `disable-model-invocation: true`.
- **Texto con dos ramas:** "si no eres `<agente>`, delega en él y espera su informe" / "si eres `<agente>`, ejecuta el proceso".
- **Salida explícita:** "si no puedes delegar, detente y dilo" ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).
- **`description`** con "úsalo solo cuando el usuario lo pida". En Antigravity es el único freno a la activación automática.

```mermaid
flowchart LR
    U["/review-pr-java &lt;PR&gt;"] --> R{runtime}
    R -- "Claude Code:<br/>context: fork + agent:" --> A["Subagente backend-java<br/>(rama 'eres el agente')"]
    R -- "Antigravity:<br/>ignora el fork" --> M["Agente principal"]
    M -- "invoke_subagent<br/>(rama 'no eres el agente')" --> A
    M -- "no puede delegar" --> X["Se detiene y lo explica"]
    A --> P["proc-pr-review → roles → informe"]
```

### 3.2 Agente por `description`

- No hay `/nombre`. El usuario describe la tarea, u otro agente delega.
- El modelo elige el agente comparando su `description` ([subagentes](../2-primitivos/subagents.md)).
- Si la petición es ambigua y hay varios candidatos, se usa el [agente router](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md) ([0001](../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md)).

### 3.3 Skill inline

- La skill es su propia entrada `/nombre` y corre en el contexto de quien la llama ([skills](../2-primitivos/skills.md)).
- Sirve para flujos simples en los que el resultado intermedio debe quedar en el contexto.
- Sin aislamiento: todo el trabajo intermedio ocupa el contexto principal.

---

**Segundo caso: `/remediate-sarif-java`.** La skill forkea a `backend-java-remediate`, que delega el rol `code-fix` en el subagente `backend-java-fix` con `Agent` (Claude) o `invoke_subagent` (Antigravity). La profundidad es 2, dentro del límite de 3. Como el subagente no puede preguntar, la entrada interactiva se parte en pasos con el estado en `run.json` ([sarif-remediation-java-flow.md](../../2-architecture/sarif-remediation-java-flow.md)).

**Delegar lanzando un proceso CLI desde un script (`claude -p`, `agy -p`) no es hoy un mecanismo permitido.** La delegación es solo por `Agent`/`invoke_subagent` ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)). El adaptador de agente externo es el ítem [N9](../../2-architecture/mejoras-pendientes.md#n9-adaptador-de-agente-externo-fase-2-de-la-remediación) y necesita un ADR nuevo antes de implementarse.

## 4. Correspondencia entre runtimes

Qué usar en cada runtime para el mismo objetivo. En negrita, lo agnóstico.

| Objetivo | Claude Code | Antigravity |
|---|---|---|
| Entrada que el usuario teclea | **skill `/nombre`** | **skill `/nombre`** |
| Ejecutarla dentro de un agente concreto | **skill con `context: fork` + `agent:` + delegación en el texto** | **la misma skill: el agente principal delega con `invoke_subagent`** |
| Que el modelo elija el agente | **subagente por `description`** | **subagente por `description` (planificador)** |
| Forzar un agente para una tarea | `@agent-<name>` | pedirlo en el texto ("delega en `<name>`") |
| Toda la sesión como un agente | `claude --agent <name>` / `"agent"` en settings | `agy --agent <name>` / panel `/agents` |
| Que el modelo no active sola una skill | `disable-model-invocation: true` | solo la `description` ("úsalo solo cuando el usuario lo pida") |
| Sin sesión interactiva | **`claude -p`** | **`agy -p`** |
| Fijar el modelo | `model:` en la skill de entrada, `model` en la llamada a `Agent`, `claude -p --model` (el agente queda en `inherit`) | no hay campo portable: sale de la sesión `agy` |
| CI | `claude-code-action` | — |

`@agent-<name>` y `--agent` son útiles para depurar, pero no sirven como única forma de llegar al agente.

---

## 5. Diferencias de comportamiento (resumen)

| Aspecto | Claude Code | Antigravity (`agy` 1.4.8) |
|---|---|---|
| Dónde se despliega | `.claude/` | `.agents/` |
| Aislamiento de la skill de entrada | `context: fork` + `agent:` | delegación en el texto → `invoke_subagent` |
| Origen del agente | desplegado por APM | generado por el aprovisionador |
| Campos de control de invocación | `disable-model-invocation`, `user-invocable` | se ignoran; solo la `description` |
| Permisos y `env` del proyecto | `.claude/settings.json` | no hay; solo permisos globales |
| Hooks `PreToolUse` | bloquean con código 2 | bloquean con `{"decision":"deny"}`; un hook que falla bloquea todo |
| Distribución por marketplace | sí (nuestro marketplace) | no: tiene plugins y un marketplace oficial, pero el nuestro es solo de Claude |

El detalle, con las causas y cómo resolverlas, está en [Claude Code](modelo-ejecucion-claude-code.md) y en [Antigravity](modelo-ejecucion-antigravity.md).
