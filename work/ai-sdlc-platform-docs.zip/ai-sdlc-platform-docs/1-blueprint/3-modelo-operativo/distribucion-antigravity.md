# Distribución en Antigravity

> **Para quién / qué responde:** para quien instala un paquete para Antigravity CLI (`agy`). Qué despliega APM y qué no, cómo se completa con el aprovisionador y qué ofrecen los plugins de Antigravity.

**Conclusión:** en Antigravity los paquetes se consumen con `apm install --target antigravity` (APM ≥ 0.33.0). APM no despliega agentes y deja mal las rutas de los hooks; lo corrige un aprovisionador que el **consumidor** dispara con su `lifecycle`. Nuestro marketplace no sirve aquí.

Ver también:
- [Distribución (agnóstico)](distribucion.md).
- [Distribución en Claude Code](distribucion-claude-code.md).
- [Modelo de ejecución en Antigravity](modelo-ejecucion-antigravity.md).
- [Ficha del runtime Antigravity](../2-primitivos/runtime-antigravity.md).

---

## Qué despliega APM y qué no

Requiere APM ≥ 0.33.0 (el CI usa 0.32.0, sin este target). Comprobado con `agy` 1.4.8.

| Primitiva | `.claude/` | `.agents/` | Quién lo despliega en Antigravity |
|---|---|---|---|
| Reglas (`instructions`, `applyTo`) | `rules/` | `rules/` (`globs`) | APM |
| Skills | `skills/` | `skills/` | APM |
| Skills de entrada `/nombre` | `skills/` ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)) | `skills/` | APM |
| Agentes | `agents/` | `agents/` | **El aprovisionador** ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) |
| Hooks | `settings.json` | `hooks.json` (contenedor `apm`) | APM, con rutas que **corrige el aprovisionador** |
| MCP | `.mcp.json` | `mcp_config.json` | APM |
| Permisos y `env` | `settings.json` | — (solo globales: `~/.gemini/antigravity-cli/settings.json`) | Nadie: lo configura cada máquina |

Commands y prompts no se despliegan en `.agents/`. Por eso están prohibidos en los paquetes ([distribucion.md](distribucion.md#matriz-de-targets)).

---

## El aprovisionador

`provision_agents_antigravity.py` cubre los dos huecos de APM ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)). Es **temporal**: se retira cuando APM los cubra.

| Qué hace | Detalle |
|---|---|
| Genera agentes | Lee `apm_modules/**/.apm/agents/*.agent.md` y escribe `.agents/agents/<name>.md`. Traduce `tools` (`Read`→`view_file`, `Bash`→`run_command`, `Task`/`Agent`→`invoke_subagent`…), `model` → `inherit`, `skills` → `../skills/<n>`, y copia el bloque opcional `antigravity:` |
| Corrige hooks | En el contenedor `apm` de `.agents/hooks.json`, convierte en absolutas las rutas `.agents/…` y elimina duplicados |
| Es seguro | Lleva un manifiesto, no pisa archivos ajenos, borra los agentes de paquetes desinstalados. Modos `--dry-run`, `--check` y `--clean` |
| Falla a propósito | Si un agente usa una herramienta sin traducción verificada, sale con error |

**Origen:** fuente única en `ai-sdlc-platform/ci/` y copia en `ai-sdlc-shared-skills/.apm/hooks/scripts/`, para que llegue a `apm_modules/`. El CI compara las dos con `cmp`.

### Disparo: `lifecycle` del consumidor

APM solo ejecuta los `lifecycle` de la máquina (`/etc/apm/policy.d`), del usuario (`~/.apm/apm.yml`) y del proyecto. **Nunca los de los paquetes dependientes.** Por eso lo declara quien instala:

```yaml
targets: [claude, antigravity]
lifecycle:
  post-install:   [{type: command, command: "uv run -q --with pyyaml python apm_modules/myinvestor-core/ai-sdlc-shared-skills/.apm/hooks/scripts/provision_agents_antigravity.py --from-hook"}]
  post-update:    [ …igual… ]
  post-uninstall: [ …igual… ]
```

Después:
- `apm lifecycle trust`. Sin la confianza, APM no ejecuta el bloque.
- Requiere `uv`: el script necesita PyYAML y el `python3` del sistema puede no tenerlo.
- El script solo actúa si `targets` incluye `antigravity`.
- Para probarlo: `apm lifecycle test post-install -v` y `provision_agents_antigravity.py --check`.

### Corrección de la ruta de los hooks

- APM escribe `python3 .agents/hooks/…`, relativo a la raíz del proyecto.
- `agy` ejecuta los hooks desde `.agents/`: la ruta queda `.agents/.agents/…` y el hook falla.
- Un hook que falla en `agy` **bloquea todas las herramientas**, `invoke_subagent` incluida.
- En cada install, APM no reconoce la entrada corregida y vuelve a añadir la relativa. El aprovisionador quita ese duplicado; tras reinstalar queda una sola entrada estable.

### `apm audit` y el *drift*

`apm audit` informa de *drift* en `.agents/hooks.json` tras la corrección. Es esperado: el archivo difiere de lo que escribió APM. Sale con 0.

---

## Plugins y marketplace de Antigravity

Antigravity tiene plugins propios ([plugins](https://antigravity.google/docs/plugins), [marketplace](https://antigravity.google/docs/marketplace)). No siguen el formato de Claude, y **no los usamos para distribuir**.

| Tema | Antigravity |
|---|---|
| Manifiesto | `plugin.json` **en la raíz** del plugin (también acepta `.antigravity-plugin/plugin.json`) |
| Contenido | `skills/`, `agents/`, `rules/`, `hooks.json` en la raíz, `mcp_config.json`. **Sin `commands/`** |
| Dónde se descubre | `.agents/plugins/<name>/` (proyecto) y `~/.gemini/config/plugins/` (global) |
| Instalar | `agy plugin install <p>@antigravity-plugins-official`, una URL de GitHub o una ruta local |
| Marketplace | Solo el oficial, `antigravity-plugins-official`. No hay documentación de marketplaces de terceros ni de su formato de catálogo |
| Importar desde Claude | La CLI 1.4.8 muestra `agy plugin import`, pero no está en la documentación web: **sin verificar** |

Consecuencia: el catálogo `ai-sdlc-platform` (marketplace de Claude) no sirve en Antigravity. La vía es `apm install` con `targets: [claude, antigravity]` y el `lifecycle` del aprovisionador en cada repo consumidor.
