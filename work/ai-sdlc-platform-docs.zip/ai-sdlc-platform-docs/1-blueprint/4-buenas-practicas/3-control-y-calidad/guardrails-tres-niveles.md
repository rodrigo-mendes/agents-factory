# Guardrails de tres niveles

## Qué es

Una sección de reglas de comportamiento dividida en tres niveles fijos: **Siempre hacer** / **Preguntar primero** / **Nunca hacer**, con una regla de ubicación estructural — no de contenido — sobre dónde debe vivir esa sección dentro del documento (no aplica link oficial — patrón propio del repo).

## Cómo funciona

Regla de ubicación: la sección de guardrails va después de cualquier navegación rápida (índice, tabla de contenidos) y antes de cualquier contenido largo. Nunca va escondida dentro de una subsección donde un lector rápido no la vea.

Requisitos de contenido por nivel:

- "Siempre hacer" incluye código o pasos ejecutables, no solo intención.
- "Nunca hacer" exige un ejemplo ❌ y uno ✅ lado a lado, con la razón de por qué uno está mal — no basta con prohibir, hay que mostrar el contraste.

## Cuándo aplica

Cualquier `SKILL.md` o `*.agent.md` cuyo comportamiento tenga algo riesgoso o ambiguo que valga la pena hacer explícito — acciones destructivas, decisiones con trade-off, casos donde la intuición del modelo puede ir para el lado equivocado sin una regla escrita.

## "Preguntar primero" en modo no interactivo

Sin humano, no hay a quién preguntar. En un proceso con modo autónomo, el nivel "Preguntar primero" se define por modo: en **interactivo**, el paso termina y devuelve la pregunta; en **autónomo**, **falla con un código de error** y una pista de corrección. Nunca queda esperando ni asume un valor por su cuenta.

Ejemplo (remediación de SARIF): repo ausente → `missing_repo`; repo ambiguo → `ambiguous_repo`; baseline en rojo → `baseline_failed`. Ver [ADR 0005, actualización 2026-11-03](../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md).
