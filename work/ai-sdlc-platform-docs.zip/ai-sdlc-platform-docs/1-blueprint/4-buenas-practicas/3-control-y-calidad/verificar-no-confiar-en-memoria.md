# Verificar objetivamente, no confiar en memoria o informes previos

## Qué es

Un agente que reporta conteos, métricas o estado de un repositorio debe re-verificar con herramientas (`ls`, `wc`, `grep`, `find`) en el momento de reportar — nunca repetir un conteo citado en un informe anterior sin volver a comprobarlo (no aplica link oficial — patrón propio del repo).

## Cómo funciona

Caso real documentado: un audit previo reportó "26 rules / 10 sin `paths`" cuando la cifra real, re-verificada, era "24, todas con `paths`".

El error no vino de una mala lectura inicial — vino de que un informe posterior citó el conteo del informe anterior en vez de volver a contar, propagando el dato falso sin que nadie lo notara hasta una verificación explícita.

## Cuándo aplica

Cualquier agente que audita un repositorio, reporta métricas, o cita estado del código como parte de su output — especialmente cuando ese agente tiene acceso a un informe/resumen previo que podría parecer una fuente válida más rápida que volver a contar.

## Segundo caso real

El flujo de revisión no cita su propio estado previo: `publish` vuelve a leer el head de GitHub antes de publicar; cada rol obtiene el patch con `patch --expect-sha` (falla si el head cambió); y `verify` pregunta a GitHub, no al agente, si existe el resumen del commit.
