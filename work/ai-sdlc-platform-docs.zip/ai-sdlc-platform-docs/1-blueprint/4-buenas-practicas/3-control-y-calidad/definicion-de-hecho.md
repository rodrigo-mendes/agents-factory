# Definición de hecho

## Qué es

Lista explícita y verificable con herramienta de las condiciones que deben cumplirse para considerar una fase o tarea terminada. No es el juicio subjetivo del agente sobre si "ya está bien" (no aplica link oficial — patrón propio del repo).

Ejemplo de condiciones:

- tests pasan;
- build limpio;
- gate de escritura superado;
- hallazgos del bucle de verificación resueltos o reportados según su límite de reintentos.

## Cómo funciona

Se declara antes de empezar la fase de implementación, como parte del plan presentado en el gate previo a escribir (ver [gate-antes-de-escribir.md](gate-antes-de-escribir.md)).

La fase de validación del ciclo de vida (ver [../2-orquestacion/ciclo-de-vida-de-fases.md](../2-orquestacion/ciclo-de-vida-de-fases.md)) se mide contra esta lista, comprobada con herramienta en el momento.

No se mide contra memoria ni contra la impresión del agente (ver [verificar-no-confiar-en-memoria.md](verificar-no-confiar-en-memoria.md)).

Si alguna condición no se cumple, la fase entra en modo de fallo "corregir y reintentar", acotado por el [bucle de verificación y límite de reintentos](../2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md).

## Cuándo aplica

Mismo alcance que ciclo-de-vida-de-fases: cualquier agente con tarea multi-paso no trivial. No aplica a skills de un solo paso donde declarar una lista de condiciones sería ceremonia sin beneficio.

## Evolución observada en la implementación

Una revisión de PR está "hecha" cuando, comprobado con herramienta:

1. el informe lo generó `act-common-write-report` con su plantilla y empieza por `<!-- ai-sdlc-review sha=<SHA> -->`;
2. ese SHA coincide con el head actual del PR;
3. el patch analizado es idéntico a `gh pr diff`;
4. el `git status` del repo revisado no cambió;
5. en CI, `gh_pr.py verify` encuentra el resumen del commit.

Las dos demos lo comprueban con `scripts/05-validate-local.sh`: [Claude Code](../../../../out-git/demo-pr-review/README.es.md) y [Antigravity](../../../../out-git/demo-pr-review-agy/README.es.md) (paso 6).

Los checks son los mismos en los dos runtimes; además, en modo lectura, el PR queda con 0 comentarios.

## Caso con cambios de código: remediación de SARIF

Cuando el trabajo cambia código, la definición de hecho se declara **por ítem** y **por ejecución**, ambas comprobadas con herramienta:

- **Por ítem aplicado**: pasaron las fases exigidas (compile → unit → integración, si existe); hay exactamente 1 commit con los trailers del ítem; el diff toca el archivo del ítem.
- **Por ejecución**: `deliver_change.py verify` correcto (`run.json` × `git log base..HEAD` × HEAD, worktree limpio); si se publicó, el cuerpo de la PR empieza por el marcador correcto, el `head_sha` del marcador es el HEAD local y la PR es draft; el worktree se eliminó o se conservó a propósito por un fallo.
- **`partial` nunca cuenta como ✅**: si la integración no pudo correr (p. ej. sin Docker), el resultado es ⚠️ "applied, integration not run" y la PR lleva `[partial]` en el título.
- El SARIF no se vuelve a ejecutar y el informe lo dice ("not re-scanned"): no se afirma que el hallazgo desapareció.

Ver [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).
