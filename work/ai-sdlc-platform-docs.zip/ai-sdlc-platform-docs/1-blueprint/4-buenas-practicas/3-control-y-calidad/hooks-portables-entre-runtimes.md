# Hooks portables entre runtimes

## Qué es

Un hook `PreToolUse` escrito una vez que funciona en Claude Code y en Antigravity: entiende los dos formatos de evento y bloquea con el contrato de cada runtime (no aplica link oficial — patrón propio del repo).

## Cómo funciona

```mermaid
flowchart LR
  E[evento por stdin] --> D{¿tiene toolCall?}
  D -->|sí: Antigravity| A["comando = toolCall.args.CommandLine"]
  D -->|no: Claude Code| C["comando = tool_input.command"]
  A --> K{¿prerrequisito incumplido?}
  C --> K
  K -->|no| OK[sale con 0, sin salida]
  K -->|sí, Antigravity| DA["stdout: {decision: deny, reason}<br/>sale con 0"]
  K -->|sí, Claude| DC["stderr: motivo<br/>sale con 2"]
```

| | Claude Code | Antigravity (`agy` 1.4.8) |
|---|---|---|
| Comando en el evento | `tool_input.command` | `toolCall.args.CommandLine` |
| Bloquear | código 2 + stderr | `{"decision":"deny","reason":…}` en stdout, código 0 |
| Pedir confirmación | — (permisos de `settings.json`) | `{"decision":"ask"}` (en modo headless equivale a denegar) |
| Conceder permiso | permisos de `settings.json` | **no** en modo headless; solo con una regla global en `~/.gemini/antigravity-cli/settings.json` |
| Si el hook falla | se informa | **bloquea todas las herramientas** |

Reglas:
- Un error interno del hook nunca bloquea: el script sale con 0 y avisa por stderr.
- Los tests usan eventos de los dos runtimes.
- La ruta del script en el `hooks.json` desplegado tiene que funcionar desde el directorio en el que el runtime ejecuta los hooks: en Antigravity, `.agents/` (ver [0021](../../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

## Cuándo aplica

Cualquier hook de un paquete con `targets` que incluya más de un runtime. Un hook que solo existe para un runtime no necesita la detección.

## Evolución observada en la implementación

`ai-sdlc-shared-skills/.apm/hooks/scripts/check_prereqs.py` (hook `github-pr-preflight`) no encontraba el comando en el evento de Antigravity y dejaba pasar todo.

Tras el cambio, en `agy` un `apm install` con `GITHUB_TOKEN` exportado se bloquea con `tool call denied by pre-tool hook: ✖ GITHUB_TOKEN exportada(s)…`.

La demo de Antigravity añade un segundo hook propio (`demo-permissions`) que pide confirmación para publicar, porque `agy` no lee permisos del proyecto.
