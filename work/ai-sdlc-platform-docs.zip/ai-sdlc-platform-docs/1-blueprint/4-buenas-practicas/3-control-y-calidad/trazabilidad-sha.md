# Trazabilidad por SHA de artefactos generados

## Qué es

Todo archivo generado o regenerado como resultado de ejecutar una skill, agente o subagente queda documentado junto con el SHA del contenido (o de la fuente) que lo produjo. Esto vale para todos, no solo para los archivos que despliega APM (no aplica link oficial — patrón propio del repo).

Generaliza un mecanismo que el blueprint ya documenta puntualmente para un solo caso.

`apm.lock.yaml` registra cada archivo desplegado por un package (`.claude/agents/*.md`, `.claude/skills/*/SKILL.md`) junto a su hash SHA256 (`deployed_file_hashes`, ver [../../3-modelo-operativo/distribucion.md](../../3-modelo-operativo/distribucion.md)).

## Cómo funciona

Mismo patrón que `apm.lock.yaml` ya usa (`deployed_files` + `deployed_file_hashes`), aplicado a cualquier artefacto que un agente genere, no solo a despliegues de APM. Junto al artefacto (o en un índice al lado) se registra el SHA del contenido/versión de la skill que lo generó.

Eso permite responder, en cualquier momento, "¿este archivo sigue reflejando la fuente que lo generó, o quedó desactualizado?" sin tener que releer y comparar todo el contenido a mano.

## Cuándo aplica

Cualquier artefacto que un humano pueda editar a mano después de que un agente lo generó. El SHA es lo que permite detectar drift silencioso: el humano edita, el agente regenera después sin saberlo y pisa el cambio, o al revés.

Ejemplo: un `README.md` que un agente regenera a partir de código fuente debería registrar el SHA del código fuente al momento de generarlo, para que una futura regeneración sepa si la fuente cambió desde la última vez.

## Metadata mínima por artefacto

Junto al SHA, cada artefacto (o su entrada en el índice) registra:

- **Autor creación**: quién (humano o agente) generó primera versión.
- **Timestamp creación**: fecha/hora ISO 8601 de esa primera generación.
- **Autor última edición**: quién tocó última versión (humano o agente).
- **Timestamp última edición**: fecha/hora ISO 8601 de ese último cambio.
- **Agente/skill responsable**: qué agente o skill generó o regeneró el artefacto (nombre + versión/SHA de la skill).

Sin esto, SHA solo dice "cambió o no" — no dice quién ni cuándo. Ambos datos hacen falta para diagnosticar drift: SHA detecta el qué, metadata detecta el quién y cuándo.

## Evolución observada en la implementación

Se registra el SHA de la **entrada** (el commit analizado), no el del artefacto. El marcador `<!-- ai-sdlc-review sha=<SHA> -->` va en la primera línea del informe publicado, y el patch en caché se nombra `…-<n>-<sha12>.patch`. Con eso:

- el publicador sabe si el resumen es de este commit y lo **actualiza en sitio** en vez de duplicarlo;
- `verify` lo comprueba;
- la publicación se rechaza (`stale_head`) si el head se movió.

La metadata de autor y fecha la aporta la plataforma (autor y marcas de tiempo del comentario en GitHub), por eso no se duplica en el cuerpo.

Fuente: `act-common-write-report/references/review-summary-template.md` y `gh_pr.py`.

## Caso con commits y PR: remediación de SARIF

Aquí el artefacto son commits y una PR, y la trazabilidad va en dos sitios:

- **Trailers de cada commit**: `Sarif-Item:`, `Rule:`, `Fix-Source: sarif|agent`, `Attempts:`, `Generated-By: backend-java-remediate@<versión>`.
- **Marcador en la primera línea del cuerpo de la PR**: `<!-- ai-sdlc-remediation run=<id> base_sha=<sha> head_sha=<sha> sarif_sha256=<hash> -->`.

Idempotencia: el `run-id` es determinista (`sha256(ids ordenados)[:12]`; el `base_sha` va en `run.json` y en el marcador), así que repetir la ejecución reutiliza el mismo branch y worktree. Si ya existe una PR del branch, `pr-create` actualiza el cuerpo **solo si** el `head_sha` del marcador es el head actual; si no, falla con `stale_head`. `verify` contrasta los trailers con `run.json`.

Ver [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).
