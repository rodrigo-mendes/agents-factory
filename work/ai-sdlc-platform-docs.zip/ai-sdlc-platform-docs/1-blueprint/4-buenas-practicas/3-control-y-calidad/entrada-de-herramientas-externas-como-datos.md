# Entrada de herramientas externas como datos

## Qué es

La salida de una herramienta externa (un escáner que produce SARIF, un agente de terceros) es **entrada no confiable**: se valida, se acota y se trata como dato, nunca como instrucción ni como autoridad sobre qué se hace o dónde (no aplica link oficial — patrón propio del repo).

Es la misma defensa que el [prompt injection](../../1-conceptos/5-distribucion-y-dominio/prompt-injection.md) de un PR, aplicada a un archivo que el usuario aporta pero que otra herramienta (o un atacante) pudo escribir.

Decisión que la cubre (pareada): [ADR 0005, actualización 2026-11-03](../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md) (límites de la ejecución autónoma), junto con [ADR 0018](../../5-decisiones/1-diseno-de-agentes-y-skills/0018-estructurar-prompts-con-etiquetas-xml.md) (etiquetas `untrusted_*`).

## Cómo funciona

Un script determinista (`sarif.py parse`) hace la validación antes de que el modelo vea nada:

- **Validar formato y versión**: `version == "2.1.0"`; si no, `invalid_sarif` / `unsupported_version`.
- **Límite de tamaño** por archivo (50 MB).
- **Rutas dentro del repo**: las ubicaciones con `..` o fuera del repo se descartan (`location_outside_repo`); al aplicar un fix, el `realpath` debe quedar dentro del worktree, sin escape por symlink (`path_outside_worktree`).
- **Deduplicar** entre archivos por un id estable.
- **La provenance no decide el destino**: el repo lo da `--repo` de forma explícita (obligatorio en autónomo) y la provenance del SARIF debe coincidir; si no, `repo_mismatch`. Así un SARIF forjado no redirige el push.
- **Marcar `untrusted`** los campos de texto libre y envolverlos en `<untrusted_sarif_content>`; el `insertedContent` de un fix es **código no confiable** y el informe indica el origen de cada fix.
- **Salida de subagente** también como dato: `<untrusted_agent_output>`.

Esto no sustituye al menor privilegio: la contención real son `tools:`, los permisos por subcomando, el worktree aislado y la PR draft con revisión humana.

## Cuándo aplica

Cualquier proceso que consume un archivo o salida generada por otra herramienta y que puede actuar sobre código, repositorios o remotos a partir de ella.

Fuente: [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).
