# Gate antes de escribir

## Qué es

Un checkpoint humano obligatorio antes de que un agente escriba cualquier archivo, cuando la tarea involucra decisiones no triviales (qué archivos tocar, cómo estructurar el cambio) (no aplica link oficial — patrón propio del repo).

No es una confirmación genérica de "¿seguro?" — es presentar el plan concreto antes de ejecutarlo.

## Cómo funciona

El agente entra en un modo de solo-lectura, investiga, y presenta una tabla o resumen del plan (qué va a crear/modificar y por qué) antes de escribir nada. Solo sale de ese modo y empieza a escribir cuando el usuario aprueba explícitamente.

Regla dura asociada: "no escribir ningún archivo antes de que el usuario apruebe el plan" — no es una sugerencia, es un bloqueo.

## Cuándo aplica

Cualquier agente o skill con capacidad de escritura (`Write`/`Edit`/`Bash` con efectos) que toma decisiones de diseño no triviales — qué estructura usar, qué archivos crear, en qué orden.

No aplica a ediciones mecánicas de alcance ya acordado explícitamente (ej. "corregí el typo que me señalaste" no necesita este gate cada vez).

Corte relacionado: la [skill de entrada → agente](../../3-modelo-operativo/modelo-ejecucion.md#31-skill-de-entrada--agente).

- En Claude Code, con `disable-model-invocation: true`, el checkpoint queda en el momento de invocación: solo una persona la teclea.
- En Antigravity ese campo se ignora y el freno es la `description`.

Este patrón añade un punto intermedio explícito, dentro de la misma ejecución, que vale en los dos runtimes.

## Evolución observada en la implementación

La "escritura" externa del flujo de revisión es **publicar en el PR**. El gate es común a los dos runtimes:

1. El informe completo (el "plan") se muestra **antes** y termina con "¿publicar?".
2. La skill de entrada pasa `publish=false` salvo que el usuario pida publicar.
3. Una traba que el modelo no puede mover (`GH_PR_PUBLISH=0`) hace que `gh_pr.py` rechace toda escritura (`publish_disabled`).

Es una variante del patrón: checkpoint humano **más** bloqueos de plataforma, porque en una prueba e2e el agente intentó publicar sin que se le hubiera pedido.

Las barreras de plataforma se montan distinto en cada runtime:

| Barrera | Claude Code | Antigravity |
|---|---|---|
| Solo comandos de lectura | `permissions.allow` de `.claude/settings.json` | Hook de la demo (`demo-permissions`): `allow` para las lecturas, **`ask`** para `publish`, `comment` y `review-inline` |
| Traba `GH_PR_PUBLISH=0` | `env` de `.claude/settings.json` | Exportada en la shell antes de abrir `agy` (no hay `env` de proyecto) |
| Modo headless (`-p`) | Permisos del proyecto | Hace falta la regla global `command(python3)` en `~/.gemini/antigravity-cli/settings.json`. Lo no permitido se deniega, incluido el `ask` del hook |

En CI (solo Claude Code) el gate se sustituye por el límite de herramientas y la verificación posterior.

Fuentes:
- `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` (`publish=false`);
- `act-common-write-report/SKILL.md` y `gh_pr.py`;
- [demo de Claude Code](../../../../out-git/demo-pr-review/README.es.md) (paso 4) y [demo de Antigravity](../../../../out-git/demo-pr-review-agy/README.es.md) (paso 4).

## Modo autónomo y flujo en pasos (remediación de SARIF)

`/remediate-sarif-java` escribe código, así que necesita el gate en dos formas. Decisión: [ADR 0005, actualización 2026-11-03](../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md). Flujo completo: [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).

**Interactivo, en pasos.** Un subagente no puede preguntar a mitad de la ejecución, así que el gate va **entre invocaciones**, con el estado persistido en `run.json`:

| Paso | Qué hace | ¿Escribe? |
|---|---|---|
| `plan` | tabla de ítems × acción prevista + definición de hecho; devuelve el `run-id` | no |
| `apply <run-id>` | worktree, baseline, bucle por ítem, commits; devuelve el informe y pregunta "¿publicar?" | solo en el worktree aislado |
| `publish <run-id>` | verifica el estado contra git, push y PR draft | remoto |

**Autónomo.** Sin humano que apruebe, el gate lo sustituyen barreras que el modelo no puede mover:

- escritura solo en un worktree fuera del proyecto;
- publicar exige `publish=true` **y** `GIT_CHANGE_PUBLISH=1` (sin la variable, no publica);
- la PR es siempre draft, fijado en el script;
- verificación posterior (`deliver_change.py verify`) antes de publicar;
- "Preguntar primero" se convierte en **fallo con código** (`missing_repo`, `baseline_failed`…) y una pista de corrección; nunca se queda esperando.
