# Tipos de skill

No es un campo de frontmatter — es una convención de diseño sobre el **rol** que juega cada skill dentro de una jerarquía (no aplica link oficial — patrón propio del repo).

Ver el árbol completo en acción en [../../3-modelo-operativo/modelo-ejecucion.md](../../3-modelo-operativo/modelo-ejecucion.md).
Frontmatter y demás detalles de la skill como primitivo en [../../2-primitivos/skills.md](../../2-primitivos/skills.md).

Por qué existe esta taxonomía: [../../5-decisiones/1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md](../../5-decisiones/1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md).

| Tipo | Rol | Rasgo distintivo | Ejemplo |
|---|---|---|---|
| Orquestadora / coordinadora | Decide el orden de pasos, delega a otras skills | Es la única con lógica de "siguiente paso"; normalmente la que lleva [`context: fork`](../../2-primitivos/subagents.md) si el flujo se aísla | `java-reviewer` (rol orquestador dentro de su propio agente) |
| Especialista (checklist de dominio) | Aplica un conjunto fijo de reglas verificables sobre un input concreto | Devuelve hallazgos con severidad/dimensión cerrada, no decide flujo | `java-code-review`, `java-security-review` |
| Conocimiento pasivo | Nunca se activa sola; solo la leen por ruta otras skills/agentes | Casi siempre sin `description` orientada a activación, o con `disable-model-invocation: true` (solo Claude Code; Antigravity lo ignora y depende de la `description`) | `knowledge-catalog` |

## Cómo escribir cada tipo

**Orquestadora**: marcar explícitamente, paso por paso, cuáles son gate bloqueante (si falla, se detiene todo) y cuáles son advertencia no-bloqueante (si falla, se registra y se sigue).

Sin esa marca, el modelo tiene que inferir la severidad de cada paso en tiempo de ejecución — inconsistente entre corridas.

**Especialista**: un ítem del checklist = una regla comprobable, no una idea general.

Los valores de salida posibles (severidad, categoría, veredicto) se fijan en la definición de la regla misma — un enum cerrado — nunca se dejan al criterio del modelo en el momento de aplicarla.

Sin un conjunto cerrado, dos corridas de la misma skill sobre el mismo input pueden etiquetar el mismo hallazgo con palabras distintas, rompiendo cualquier comparación entre corridas.

**Conocimiento pasivo**: la `description` (si existe) debe "gritar" que nadie la activa por sí sola — ninguna frase que sugiera una acción ("usa esto para...", "aplica cuando...").

Una `description` de acción en una skill que se pensó como pasiva es la causa más común de que el modelo la dispare sin que nadie lo pida.

- En Claude Code, `disable-model-invocation: true` impide la activación automática.
- En Antigravity ese campo se ignora: la `description` es el único freno ([runtime-antigravity.md](../../2-primitivos/runtime-antigravity.md#skills)). Por eso la `description` tiene que bastar sola en los dos runtimes.

## Evolución observada en la implementación

**Equivalentes actuales de los ejemplos de la tabla:** orquestadora → `proc-pr-review`; especialista → `act-java-check-style`, `act-common-scan-security`; conocimiento pasivo → `kb-java-best-practices`.

1. **Un cuarto tipo: la instruction** (`std-java-coding`, `applyTo: "**/*.java"`): normativa obligatoria que la plataforma carga sola al tocar archivos que encajan. No es una skill ni se activa por descripción.
2. **Asignación de roles.** La orquestadora pide capacidades por *rol* (`style-check`, `security-scan`, `coverage-check`, `report`, `pr-access`) y **cada agente** dice qué skill cubre cada rol. Cambiar de stack no cambia el proceso.
3. **Contrato de la especialista.** Devuelve `execution{status, source, reason}` además de los hallazgos.

4. **Especialistas con efectos secundarios.** `act-common-github-pr` (`publish`), `act-common-deliver-change`, `act-common-apply-sarif` (`apply`) y `act-java-run-build` siguen siendo "especialistas", no un tipo nuevo. Lo que cambia es el contrato de salida: en vez de hallazgos, devuelven un **resultado más una lista cerrada de códigos de error** (`publish_disabled`, `stale_head`, `head_moved`…).

Fuente: `backend-java.agent.md` (*Role assignment*), `proc-pr-review/SKILL.md` y `findings-contract.md`.
