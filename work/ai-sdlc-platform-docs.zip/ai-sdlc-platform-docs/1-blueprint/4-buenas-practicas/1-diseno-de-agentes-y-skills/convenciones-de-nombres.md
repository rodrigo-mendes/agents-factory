# Convenciones de nombre por rol del artefacto

## Qué es

El nombre de una [skill](../../2-primitivos/skills.md), agente o rule sigue una forma según su rol, no solo kebab-case genérico (no aplica link oficial — patrón propio del repo):
- **Skill de conocimiento** (activación automática, no destructiva): gerundio-sustantivo — ej. `researching-technical-frameworks`.
- **Skill de acción / agente**: acción-sustantivo o dominio-rol — ej. `skill-creator`, `framework-researcher`.
- **Rule / regla transversal**: alcance-sustantivo — ej. `skill-frontmatter`.

## Cómo funciona

No basta con "usar kebab-case". El error típico no es de casing sino de **orden de palabras**.

Nombrar una skill de conocimiento como si fuera de acción (`technical-framework-research` en vez de `researching-technical-frameworks`) oscurece de un vistazo si el artefacto se activa solo (conocimiento) o hay que invocarlo (acción).

Cada ejemplo de nombre incorrecto debería venir con la razón exacta del error, no solo "está mal".

## Cuándo aplica

Al nombrar cualquier skill, agente o rule nuevo — antes de escribir el archivo, decidir a qué rol pertenece (conocimiento pasivo, acción, orquestador, regla transversal) y nombrarlo según esa forma, no según lo que suene bien.

## Evolución observada en la implementación

El repo codifica el rol en un **prefijo**, no en el orden de las palabras:

| Rol | Forma | Ejemplo |
|---|---|---|
| Proceso | `proc-*` | `proc-pr-review` |
| Capacidad | `act-<ámbito>-<verbo>-<objeto>` | `act-java-check-style` |
| Conocimiento | `kb-*` | `kb-java-best-practices` |
| Normativa | `std-<stack>-*` | `std-java-coding` |
| Skill de entrada | `<verbo>-<objeto>-<stack>` | `review-pr-java` |
| Agente | `<stack>[-<variante>]` | `backend-java-ci` |

La forma se **valida con linter** (`ai-sdlc-lint`) en vez de depender de la revisión humana, y el rol se lee sin interpretar el nombre.

Fuente: `ai-sdlc-platform/README.md` (*Convención de nombres*) y `CLAUDE.md` de la raíz.
