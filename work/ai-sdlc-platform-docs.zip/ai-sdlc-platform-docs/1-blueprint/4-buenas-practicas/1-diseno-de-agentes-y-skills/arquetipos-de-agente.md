# Arquetipos de agente por forma

## Qué es

En vez de una plantilla genérica única para cualquier agente, usar plantillas distintas según la "forma" del rol: un orquestador que abarca múltiples dominios de punta a punta, un asesor de solo lectura que nunca escribe código, etc. (no aplica link oficial — patrón propio del repo).

La diferencia entre arquetipos no es solo de prosa — se refleja en el frontmatter.

## Cómo funciona

El rol "solo asesor" se fuerza con `tools: Read, Grep, Glob` — sin `Write`/`Edit`/`Bash` — no solo con una instrucción en el prompt pidiendo "no escribas código".

Esto usa el mismo principio ya documentado en [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md) — "`tools:` reemplaza, no extiende" — para hacer estructuralmente imposible que un agente asesor tenga efectos secundarios, en vez de confiar en que respete una instrucción de prosa.

## Cuándo aplica

Al crear un agente cuyo rol debe ser estructuralmente imposible de violar, no solo declarado. Si el rol es "solo lee y recomienda", declararlo en `tools:` en vez de solo en el prompt elimina la clase completa de errores donde el agente termina escribiendo algo que no debía.

## Evolución observada en la implementación

El mismo paquete ofrece dos arquetipos del mismo rol: `backend-java` (interactivo, hereda el pool, límites en prosa) y `backend-java-ci` (desatendido, allowlist).

El revisor de CI es "solo asesor" pero **necesita `Bash`** para ejecutar `gh_pr.py`. En vez de quitarlo, se restringe por patrón en el workflow:

```text
--allowedTools    "Bash(git diff:*),Bash(git log:*),Bash(python3 */act-common-github-pr/scripts/gh_pr.py *)"
--disallowedTools "Edit,Write,NotebookEdit,Bash(git push:*),Bash(mvn:*)"
```

Es otra manera de hacer el rol estructuralmente imposible de violar cuando necesita una shell: **acotar la herramienta, no eliminarla**.

Fuente: `ai-sdlc-backend-java/.apm/agents/` y `ai-sdlc-platform/.github/workflows/pr-review-backend-java.yml`.

## Dos formas más: implementador acotado y orquestador con efectos vía scripts

La remediación de SARIF añade dos arquetipos, igualmente reforzados por `tools:` ([ADR 0011, actualización 2026-11-03](../../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md)):

| Arquetipo | Agente | `tools:` | Qué NO puede |
|---|---|---|---|
| Implementador acotado | `backend-java-fix` | `Read, Grep, Glob, Edit, Write` | `Bash` (ni commit ni build), `Agent` |
| Orquestador con efectos vía scripts | `backend-java-remediate` | `Read, Grep, Glob, Bash, Agent` | `Edit`/`Write`; `git`/`gh`/`claude`/`agy` directos |

En el segundo, `Bash` no se elimina sino que se **acota con los permisos del consumidor** (solo los scripts de los roles), igual que en `backend-java-ci`. Ambos llevan `model: inherit`: el modelo se fija en los puntos de invocación (ver [05-escribir-agentes.md](../../6-manual-creacion-plugin/05-escribir-agentes.md)).
