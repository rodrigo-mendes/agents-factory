# Límite de tamaño y extracción a blueprints

## Qué es

Un [`SKILL.md`](../../2-primitivos/skills.md) no debería superar aproximadamente 500 líneas (no aplica link oficial — patrón propio del repo).

Contenido que lo excede — más de 3 ejemplos largos, referencia extensa, catálogos — se extrae a archivos de soporte separados y se enlaza desde el `SKILL.md`, nunca se importa "eager" (cargado siempre, de una vez) dentro del cuerpo principal.

## Cómo funciona

Complementa la progressive disclosure ya documentada en [../../2-primitivos/skills.md](../../2-primitivos/skills.md) (los archivos de soporte se leen bajo demanda). Agrega un umbral concreto y la razón detrás.

La ventana de contexto es un recurso compartido entre todo lo que el modelo tiene cargado en un momento dado, no solo de la skill actual.

Un `SKILL.md` de 1500 líneas consume ese recurso compartido cada vez que se activa, aunque la tarea concreta solo necesite una fracción de ese contenido.

## Cuándo aplica

Cualquier skill con más de 3 ejemplos largos (>50 líneas cada uno) o contenido de referencia extenso (catálogos, tablas largas, casos de borde exhaustivos).

El umbral no es una regla rígida de conteo de líneas por sí misma — es una señal de que probablemente el contenido mezcla "lo que se necesita siempre que la skill se activa" con "lo que se necesita solo en algunos casos", y lo segundo debería vivir aparte.

## Evolución observada en la implementación

`kb-java-best-practices` aplica el umbral en **dos niveles**: secciones condensadas que siempre se cargan y guías completas (`*-detail.md`) que solo se leen *cuando la condensada no basta*, con una regla de precedencia explícita (*la guía completa gana*).

Cuando una sección condensada contradice a la completa, se corrige la condensada (caso resuelto: la nomenclatura de `gateway`).

Fuente: `ai-sdlc-kb-java/.apm/skills/kb-java-best-practices/SKILL.md`.
