# Patrón: agente router

## Qué es

Un [subagente](../../2-primitivos/subagents.md) (o skill orquestadora) cuyo único trabajo es conocer el catálogo completo de skills/agentes disponibles (vía `skills:` preload o lectura de un índice tipo `knowledge-catalog`).

También actúa como intermediario entre una entrada de texto libre y el agente/skill real que debe resolver la tarea.

No ejecuta el trabajo de dominio él mismo — decide a quién delegarlo, o si hace falta preguntar antes de delegar (no aplica link oficial — patrón propio del repo).

## Cómo funciona

Dos ramas según la confianza del matching entre la descripción del usuario y las `description` de las skills/agentes candidatos:

1. **Match claro** (score por encima de umbral / única coincidencia razonable) → delega directo a la skill/agente real, sin preguntar. Mismo comportamiento que una invocación directa sin router.
2. **Ambiguo** (2+ candidatos plausibles, ninguno claramente dominante) → el router **no ejecuta ninguno**; devuelve al usuario la lista de candidatas (nombre + descripción corta de cada una) y pide que elija o reformule.

El caso 2 es el checkpoint humano que un subagente normal no puede dar a mitad de tarea (ver [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md) — "Cuándo NO usar": *"la tarea necesita pedir confirmación humana a mitad de proceso"*).

El router lo resuelve poniéndose **antes** de la delegación, no a mitad de ella — el checkpoint es su única función, no una excepción dentro de una tarea más larga.

```mermaid
flowchart TD
    U["Usuario<br/>(texto libre)"] --> R["Agente router<br/>conoce el catálogo de skills/agentes"]
    R -- "match claro" --> D["Delega directo<br/>a la skill/agente real"]
    R -- "ambiguo (2+ candidatos)" --> P["Presenta candidatas<br/>al usuario"]
    P --> E["Usuario elige o reformula"]
    E --> D
```

## Dos variantes observadas en la práctica

**(a) Router a nivel de subagente — fan-in muchos-a-uno.**

Varias skills de entrada y peticiones convergen a un número menor de subagentes "de ruteo", cada uno con un catálogo explícito de qué petición mapea a qué skill o agente.

También hay una regla de fallback: si nada matchea, el agente rutea o declina — nunca intenta resolver la tarea inline por su cuenta ("route or decline, do not attempt to fulfill inline").

Esta es la variante que ya cubren las entradas "skill de entrada → agente" y "agente por `description`" de [../../3-modelo-operativo/modelo-ejecucion.md](../../3-modelo-operativo/modelo-ejecucion.md#3-entradas-agnósticas).

**(b) Router a nivel de skill — sin lógica propia, solo 3 salidas posibles.**

Una skill delgada, sin conocimiento de dominio, cuyo único trabajo es:

1. Match claro → invoca directo la skill hermana correspondiente.
2. Ambiguo pero acotado (2-3 candidatas razonables) → hace una pregunta de desambiguación puntual.
3. No reconoce el término → se niega a adivinar y devuelve la lista completa de hermanas + las 2 más parecidas como sugerencia.

El antipatrón explícito a evitar en esta variante: que el router mismo empiece a producir contenido de dominio en vez de delegar todo — su única salida válida es "a quién delego" o "qué pregunto", nunca una respuesta de fondo.

Ambas variantes comparten la misma regla de fondo (match claro → delega; ambiguo → pregunta antes de ejecutar); difieren en si el que rutea es un subagente con catálogo de skills/agentes, o una skill inline sin subagente propio.

## Cuándo aplica

Cualquier entrada de texto libre sin skill de entrada (ver "agente por `description`" en [../../3-modelo-operativo/modelo-ejecucion.md](../../3-modelo-operativo/modelo-ejecucion.md#32-agente-por-description)).

Aplica cuando el catálogo de skills/agentes candidatos puede crecer lo bastante para que el matching deje de ser obvio.

Con un catálogo pequeño (2-3 agentes muy distintos entre sí) el router es sobre-ingeniería; se vuelve necesario cuando el catálogo crece o varias skills cubren dominios parecidos.

Trade-off a tener en cuenta: agrega un salto extra (router → agente real) incluso en el caso feliz de match claro, salvo que el router tenga lógica de paso directo (punto 1 de arriba) — que siempre debería tener.

## Evolución observada en la implementación

`backend-java` se comporta como un router de procesos sin ser un subagente de ruteo (el índice real hoy es el de `kb-java-best-practices`, no `knowledge-catalog`):

- Su cuerpo tiene una tabla *Petición → core skill* y la regla *"si la petición no encaja con ningún proceso, dilo y no inventes uno"*: la rama *route or decline* de la variante (a).
- Las skills internas (`proc-pr-review`, `act-common-write-report`…) llevan en su `description` *"NO la invoques directamente ante peticiones en lenguaje natural"* y `user-invocable: false`.

  Ante lenguaje natural **se niegan y remiten a la skill de entrada** `/review-pr-java` (variante b).
  En Antigravity `user-invocable` se ignora: el freno es solo la `description`.

Fuente: `backend-java.agent.md` (sección *Processes*) y `proc-pr-review/SKILL.md` (`description`).
