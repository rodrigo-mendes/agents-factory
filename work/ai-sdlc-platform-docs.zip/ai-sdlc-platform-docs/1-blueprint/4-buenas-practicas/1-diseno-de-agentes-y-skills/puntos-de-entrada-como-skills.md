# Puntos de entrada como skills

> **Para quién:** quien crea un punto de entrada (`/nombre`) en un paquete.
> **Qué responde:** cómo escribirlo para que funcione en cualquier harness. Decisión: [0020](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md).

## Qué es

Todo lo que una persona teclea como `/nombre` es una **skill** (`.apm/skills/<nombre>/SKILL.md`). **Nunca un command ni un prompt** (no aplica link oficial — patrón propio del repo).

En Claude Code y en Antigravity una skill ya funciona como comando:
- aparece en el menú `/`;
- recibe el texto que sigue en `$ARGUMENTS`.

Así, un solo archivo sirve para los dos runtimes.

## Por qué no commands ni prompts

No todos los harnesses los soportan. Según la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):

| Formato | Claude Code | Antigravity | ¿Se puede usar? |
|---|---|---|---|
| `prompts` (`.apm/prompts/`) | solo convertido en command | ❌ | **No** |
| `commands` (`.claude/commands/`) | ✅ | ❌ | **No** |
| `skills` | ✅ | ✅ | **Sí** |

Un punto de entrada en `commands` o `prompts` no llega a Antigravity. Simplemente no aparece, y no hay error.

## Cómo funciona

Plantilla de una skill de entrada que debe ejecutarse dentro de un agente:

```markdown
---
name: review-pr-java
description: Reviews a backend Java Pull Request with the backend-java agent. Use it only when the user explicitly asks to review a PR (e.g. "/review-pr-java <PR> [focus]"). …
argument-hint: <PR> [focus]
context: fork                    # Claude: ejecuta la skill dentro del agente
agent: backend-java              # Claude: qué agente
disable-model-invocation: true   # Claude: el modelo no la activa solo
---

<user_request>
$ARGUMENTS
</user_request>

## If you are not already the `backend-java` agent
Delegate this whole request … to the `backend-java` subagent …
If you cannot delegate, stop and say so …

## If you are the `backend-java` agent
Run the core skill `proc-pr-review` … If <user_request> is empty, use the open PR of the current branch.
```

Las tres piezas clave:

1. **Freno a la activación automática.** Hay dos, uno por runtime:
   - `disable-model-invocation: true`, que funciona en Claude;
   - la `description` "solo cuando el usuario lo pida", que es el único freno en Antigravity.
2. **Argumentos.** `argument-hint` y `$ARGUMENTS` funcionan en los dos. Si el texto llega vacío, la skill usa un valor por defecto (el PR de la rama actual).
3. **Delegación.** Se pide en el texto ([delegación explícita](../2-orquestacion/delegacion-explicita-en-el-texto.md)), porque `context: fork` y `agent:` solo los entiende Claude.

Qué campos lee cada runtime:

| Campo | Claude Code | Antigravity |
|---|---|---|
| `name`, `description` | sí | sí |
| `argument-hint`, `$ARGUMENTS` | sí | sí (`$ARGUMENTS` comprobado) |
| `context: fork`, `agent:` | sí | se ignora |
| `user-invocable`, `disable-model-invocation` | sí | se ignora |
| `disable-slash-command` (no documentado) | se ignora | no impidió invocar con `/` en modo headless |

## Cuándo aplica

- **Aplica** siempre que un paquete ofrezca algo que una persona teclea con `/`.
- **No aplica** a las skills internas que solo usan otras skills o agentes (`proc-*`, `act-*`, `kb-*`): no son puntos de entrada.

## Evolución observada en la implementación

`ai-sdlc-backend-java` tenía dos piezas con el mismo texto:
- el prompt `.apm/prompts/review-pr-java.prompt.md`;
- el envoltorio `pr-review-java`.

Las dos se sustituyeron por `.apm/skills/review-pr-java/SKILL.md`. Lo que teclea el usuario no cambia (`/review-pr-java <PR> [foco]`); en Claude, el archivo instalado pasa de `.claude/commands/` a `.claude/skills/review-pr-java/`.
