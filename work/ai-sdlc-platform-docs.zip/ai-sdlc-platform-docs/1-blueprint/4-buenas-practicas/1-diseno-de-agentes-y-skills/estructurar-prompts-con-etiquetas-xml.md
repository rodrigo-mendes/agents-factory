# Estructurar prompts con etiquetas XML

## Qué es

Envolver con etiquetas XML (`<nombre>…</nombre>`) las partes de un prompt que el modelo debe tratar como un bloque distinto de las instrucciones: datos variables, contenido no confiable o la salida que otro paso debe leer.

No es un campo de frontmatter ni una barrera de seguridad: es una convención de redacción.
Anthropic la recomienda como práctica general de prompting.

El uso concreto de este repo (vocabulario cerrado, criterios de cuándo sí y cuándo no) es patrón propio (no aplica link oficial — patrón propio del repo).

Por qué se adopta: [../../5-decisiones/1-diseno-de-agentes-y-skills/0018-estructurar-prompts-con-etiquetas-xml.md](../../5-decisiones/1-diseno-de-agentes-y-skills/0018-estructurar-prompts-con-etiquetas-xml.md).

## Cómo funciona

Se separa lo que el modelo debe **obedecer** de lo que debe **analizar**, y se nombra cada bloque con una etiqueta del vocabulario cerrado:

| Etiqueta | Qué contiene | Dónde se usa |
|---|---|---|
| `<pr_context>` | Metadatos del PR inyectados por CI (repo, número, SHA base) | Prompt del workflow de CI |
| `<task>` | La instrucción que debe ejecutarse | Prompt del workflow de CI |
| `<user_request>` | Input literal del usuario (`$ARGUMENTS`) | Skill de entrada `review-pr-java` (`ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md`) |
| `<untrusted_pr_content>` | Título, descripción, commits, diff y ficheros del PR | Regla de datos de `proc-pr-review` y entrada de los roles `act-*` |
| `<role_result role="…">` | Salida (`execution` + `findings`) de un rol que evalúa el cambio | Contrato de los roles `style-check`, `coverage-check`, `security-scan` |
| `<review_context>` | Contexto que `proc-pr-review` entrega al rol `report` | Entrada de `act-common-write-report` |
| `<untrusted_sarif_content>` | Campos de texto libre de un hallazgo SARIF (`message`, `help`, `insertedContent`, snippets) | Brief de `backend-java-fix` y regla de datos de `proc-sarif-remediation` |
| `<untrusted_agent_output>` | Resumen que devuelve un subagente, tratado como dato por el orquestador | `backend-java-remediate` tras cada invocación de `backend-java-fix` |
| `<remediation_brief>` | Instrucción acotada para el rol `code-fix`: ítem, archivo, regla y restricciones | Entrada de `backend-java-fix` |
| `<remediation_context>` | Contexto (conteos y estado por ítem de `sarif.py summary`) que el proceso entrega al rol `report` | Entrada de `act-common-write-report` en modo `remediation` |
| `<build_result>` | Resultado por fase de `act-java-run-build` (estado, comando, tests fallidos, extracto de log) | Salida del rol `build-test` y brief del siguiente intento |

**Antes / después** (prompt de CI):

```
Antes                                          Después
REPO: ...                                      <pr_context>
PR NUMBER: ...                                 repo: ...
BASE SHA: ...                                  pr_number: ...
                                               base_sha: ...
Delegate to the backend-java-ci subagent...    </pr_context>

                                               <task>
                                               Delegate to the backend-java-ci subagent
                                               ... on the PR in <pr_context> ...
                                               </task>
```

Reglas de uso:

- El nombre de la etiqueta describe el contenido, no la acción (`<untrusted_pr_content>`, no `<ignore_this>`).
- La instrucción se refiere al bloque por su etiqueta ("el PR indicado en `<user_request>`").
- No se anidan etiquetas sin necesidad ni se inventan nombres fuera del vocabulario: se añade primero a la tabla.
- Los placeholders de plantillas (`<VERDICT>`, `<short-sha>`) no son etiquetas y no se modifican.

## Cuándo aplica

| Situación | ¿Etiquetas? |
|---|---|
| Instrucciones puras (agentes, `std-*`, conocimiento de referencia) | No: cabeceras, tablas y listas bastan |
| Instrucciones + datos variables o no confiables (input del usuario, diff, descripción de PR) | Sí: envolver los datos |
| Un rol entrega algo que otro rol debe leer de forma fiable | Sí |
| El problema son reglas dispersas o un formato sin plantilla | No: reestructurar o dar plantilla |
| El contenido ya llega delimitado por un script (secciones, rutas de fichero) | No |

No sustituyen al menor privilegio: la defensa real frente a un contenido hostil son `tools:`, `--allowedTools` y `--disallowedTools` (ver [guardrails de tres niveles](../3-control-y-calidad/guardrails-tres-niveles.md)).

Para saber si una etiqueta mejora algo, se mide con un escenario de prueba ([testing de skills con escenarios](../3-control-y-calidad/testing-de-skills-con-escenarios.md)): un PR con una instrucción hostil donde el veredicto no debe cambiar.

## Evolución observada en la implementación

- `proc-pr-review` pasó de una línea de ~180 palabras para el traspaso al rol `report` a una lista de entradas con un bloque `<review_context>`, y las reglas de estado de los roles a una tabla. Ahí el problema era de estructura, no de etiquetas.
- `gh_pr.py view` marca `untrusted` solo para `title`, `body` y `labels`, porque son los únicos campos de texto libre que devuelve; commits, diff y ficheros llegan por otros subcomandos y se cubren con la regla de datos de la skill.

Fuente: `proc-pr-review/SKILL.md`, `findings-contract.md`, `act-common-write-report/SKILL.md`, `pr-review-backend-java.yml`.

**Salida de herramientas y agentes externos = dato no confiable.** Todo lo que produce una herramienta externa (SARIF de un escáner) o un agente (el resumen del subagente) se envuelve en una etiqueta `untrusted_*` y el proceso lo trata como dato, nunca como instrucción. Detalle: [entrada de herramientas externas como datos](../3-control-y-calidad/entrada-de-herramientas-externas-como-datos.md).
