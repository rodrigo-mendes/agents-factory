# Jerarquía de capas con delegación solo hacia abajo

## Qué es

Las capas de un sistema de agentes (agente orquestador / [skill](../../2-primitivos/skills.md) de conocimiento / skill de acción / etc.) se nombran explícitamente, y cada una tiene una columna de "qué NO debe contener" además de "qué sí hace" (no aplica link oficial — patrón propio del repo).

Ejemplo: una skill no debe contener lógica de implementación; un agente no debe contener conocimiento de dominio hardcodeado en su propio prompt.

## Cómo funciona

Regla de dirección: cada capa delega hacia abajo (hacia la capa más específica/concreta), nunca hacia arriba.
Un agente orquestador delega a skills; una skill de acción no debería, a su vez, intentar reimplementar lo que un agente orquestador hace.

La columna "qué NO debe contener" es la parte que hace la regla verificable — no basta con decir "cada capa tiene su rol", hay que poder señalar cuándo una capa violó su límite.

## Cuándo aplica

Al diseñar la separación entre agente orquestador, skill de conocimiento y skill de acción para un dominio nuevo — antes de escribir el primer prompt, decidir qué capa es responsable de qué, y qué le está prohibido a cada una.

## Evolución observada en la implementación

La columna "qué NO debe contener" existe (`CLAUDE.md`, *Layer rules*) y la **comprueba el linter**:

| Capa | No debe contener |
|---|---|
| Conocimiento | dependencias; menciones a herramientas, modelos o rutas de harness; contenido procedural |
| Skills compartidas | referencias a otras skills por nombre fijo; reglas de un stack |
| Agente | reglas de lenguaje (orquesta por rol) |

La regla pasa de convención a **gate de CI** (requisito para mergear a `main`).

Fuente: `CLAUDE.md` y `ai-sdlc-platform/.github/actions/ai-sdlc-lint/`.
