# Buenas prácticas

Patrones recomendados de composición de primitivos — el **cómo**, reusable en cualquier harness compatible (Claude Code, Antigravity).
Donde un runtime se comporta distinto, la práctica lo indica.

Sin el ceremonial de ADR: aquí no se documentan alternativas descartadas ni trade-offs en disputa, solo la mecánica de un patrón y cuándo aplica.

El "por qué" de que este repo adopte alguno de estos patrones vive en [../5-decisiones/](../5-decisiones/).

## Convención

Cada archivo `titulo-kebab.md`, sin numeración, con esta forma:
- **Qué es**
- **Cómo funciona** (con diagrama si aplica)
- **Cuándo aplica**

Cada práctica puede cerrar con una sección opcional **Evolución observada en la implementación**: formas distintas de aplicar el patrón vistas en código real. No sustituye la definición.

Al añadir una práctica aquí, crear siempre su decisión pareada en [../5-decisiones/](../5-decisiones/) (y viceversa) — nunca uno sin el otro.

## Estructura de carpetas

Las prácticas se agrupan por tema en subcarpetas numeradas (el número fija el orden de lectura). Los ADR pareados de [../5-decisiones/](../5-decisiones/) usan los mismos nombres de tema.

| Carpeta | Prácticas |
|---|---|
| [1-diseno-de-agentes-y-skills/](1-diseno-de-agentes-y-skills/) | 8 — roles, nombres, capas, tamaño y puntos de entrada |
| [2-orquestacion/](2-orquestacion/) | 4 — fan-out, fases, bucles de reintento y delegación explícita |
| [3-control-y-calidad/](3-control-y-calidad/) | 8 — gates, guardrails, verificación, testing, trazabilidad y hooks portables |

## Índice

| Nombre | Resumen | Detalle |
|---|---|---|
| Agente router | Intermediario que conoce el catálogo de skills/agentes y, ante entrada ambigua, pregunta antes de delegar (2 variantes: subagente o skill) (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/agente-router.md](1-diseno-de-agentes-y-skills/agente-router.md) |
| Tipos de skill | Taxonomía de roles (orquestadora / especialista / conocimiento pasivo), con guía de cómo escribir cada uno (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/tipos-de-skill.md](1-diseno-de-agentes-y-skills/tipos-de-skill.md) |
| Trazabilidad por SHA | Todo artefacto generado por skill/agente/subagente se documenta junto al SHA que lo produjo, para detectar drift (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/trazabilidad-sha.md](3-control-y-calidad/trazabilidad-sha.md) |
| Cap de fan-out depth = 1 | Un patrón de fan-out paralelo nunca se repite dentro de sí mismo, aunque el límite técnico global sea mayor (no aplica link oficial — patrón propio del repo) | [2-orquestacion/cap-fanout-depth.md](2-orquestacion/cap-fanout-depth.md) |
| Gate antes de escribir | Checkpoint humano obligatorio con plan presentado, antes de cualquier escritura de archivo (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/gate-antes-de-escribir.md](3-control-y-calidad/gate-antes-de-escribir.md) |
| Ciclo de vida de fases | Fases nombradas con modo de fallo explícito por fase, para tareas multi-paso (no aplica link oficial — patrón propio del repo) | [2-orquestacion/ciclo-de-vida-de-fases.md](2-orquestacion/ciclo-de-vida-de-fases.md) |
| Guardrails de 3 niveles | Siempre/Preguntar primero/Nunca, con regla de ubicación estructural fija en el documento (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/guardrails-tres-niveles.md](3-control-y-calidad/guardrails-tres-niveles.md) |
| Límite de tamaño y blueprints | Umbral (~500 líneas) para extraer contenido de un SKILL.md a archivos de soporte (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md](1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md) |
| Testing de skills con escenarios | Escenarios declarados + evaluador LLM-as-judge, como tests unitarios de comportamiento, con niveles de cobertura y un directorio `scenarios/` por skill (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/testing-de-skills-con-escenarios.md](3-control-y-calidad/testing-de-skills-con-escenarios.md) |
| Jerarquía de capas | Capas con columna explícita de "qué NO debe contener", delegación solo hacia abajo (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md](1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md) |
| Arquetipos de agente | Plantillas por forma de rol (orquestador/asesor), con `tools:` como enforcement estructural (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/arquetipos-de-agente.md](1-diseno-de-agentes-y-skills/arquetipos-de-agente.md) |
| Convenciones de nombre | Forma de nombre según rol del artefacto (conocimiento/acción/regla), no solo kebab-case (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/convenciones-de-nombres.md](1-diseno-de-agentes-y-skills/convenciones-de-nombres.md) |
| Verificar, no confiar en memoria | Re-verificar conteos/estado con herramientas, nunca citar un informe previo sin comprobar (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/verificar-no-confiar-en-memoria.md](3-control-y-calidad/verificar-no-confiar-en-memoria.md) |
| Definición de hecho | Lista explícita y verificable de condiciones de "terminado", no juicio subjetivo del agente (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/definicion-de-hecho.md](3-control-y-calidad/definicion-de-hecho.md) |
| Bucle de verificación y límite de reintentos | Verificar → corregir y reintentar, acotado por un límite configurable (default: 5 fallos) (no aplica link oficial — patrón propio del repo) | [2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md](2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md) |
| Estructurar prompts con etiquetas XML | Etiquetas con vocabulario cerrado solo para datos no confiables y entregas entre roles; instrucciones puras sin etiquetas (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md](1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md) |
| Puntos de entrada como skills | Todo `/comando` es un skill: los dos runtimes lo invocan con `/` y le pasan `$ARGUMENTS`; la `description` frena la activación automática (no aplica link oficial — patrón propio del repo) | [1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md](1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md) |
| Delegación explícita en el texto | El skill pide delegar en su agente y se detiene si no puede, además de `context: fork` + `agent:`, que solo entiende Claude (no aplica link oficial — patrón propio del repo) | [2-orquestacion/delegacion-explicita-en-el-texto.md](2-orquestacion/delegacion-explicita-en-el-texto.md) |
| Hooks portables entre runtimes | Un hook detecta el runtime por la forma del evento y bloquea con su contrato (código 2 en Claude, `deny` en Antigravity) (no aplica link oficial — patrón propio del repo) | [3-control-y-calidad/hooks-portables-entre-runtimes.md](3-control-y-calidad/hooks-portables-entre-runtimes.md) |
| Entrada de herramientas externas como datos | La salida de un escáner o agente externo (p. ej. SARIF) se valida, se acota y se trata como dato no confiable; el destino lo fija el usuario, no el archivo (no aplica link oficial — patrón propio del repo). Decisión pareada: [0005](../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md), actualización 2026-11-03 | [3-control-y-calidad/entrada-de-herramientas-externas-como-datos.md](3-control-y-calidad/entrada-de-herramientas-externas-como-datos.md) |
