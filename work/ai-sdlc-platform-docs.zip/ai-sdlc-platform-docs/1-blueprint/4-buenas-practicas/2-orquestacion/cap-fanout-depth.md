# Cap de fan-out depth = 1

## Qué es

Un agente que hace fan-out a sub-agentes en paralelo nunca permite que esos sub-agentes vuelvan a hacer fan-out del mismo tipo. La profundidad de ese patrón de fan-out queda fija en 1.

Esto es independiente del límite técnico global de nesting (ver [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md) — 3 capas por defecto, `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH`).

Es un límite de diseño más estricto que el técnico, aplicado a un patrón concreto, no a toda delegación (no aplica link oficial — patrón propio del repo).

## Cómo funciona

El agente que orquesta el fan-out incluye un guard explícito en su propio prompt: "nunca spawnear un [tipo de sub-agente] desde dentro de una ejecución de ese mismo tipo".

Ejemplo real: un auditor que lanza 3 sub-agentes en paralelo (uno por lente de análisis) para llegar a un consenso, con la regla "nunca lanzar un lente de consenso desde dentro de un run de consenso" — evita que un sub-agente de lente decida, por su cuenta, volver a hacer fan-out del mismo patrón.

## Cuándo aplica

Cualquier patrón de fan-out paralelo (N sub-agentes trabajando la misma tarea desde ángulos distintos, o dividiendo un problema en partes independientes) donde cada sub-agente podría, en teoría, decidir repetir el mismo patrón.

El límite técnico de 3 capas no protege contra esto — permite perfectamente que cada uno de N sub-agentes lance sus propios N sub-agentes, multiplicando el costo sin que nadie lo pida explícitamente.

## Evolución observada en la implementación

Hoy no hay fan-out, y el límite se consigue por **estructura**, no por un guard en el prompt:

- `proc-pr-review` ejecuta los roles en serie y prohíbe arrancar otro agente para ellos.
- `backend-java-ci` **omite `Agent` de `tools`**, así que ni puede intentarlo.

Es una segunda manera, más fuerte que el guard en prosa, cuando el agente no necesita delegar nunca.

Fuente: `proc-pr-review/SKILL.md` (paso 3) y `backend-java-ci.agent.md`.
