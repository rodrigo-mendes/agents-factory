# Delegación explícita en el texto

## Qué es

Cuando un skill tiene que ejecutarse dentro de un agente concreto, pedirlo **en el texto del skill**, con una salida explícita si no se puede delegar.

Es la alternativa a confiar solo en el frontmatter (`context: fork` + `agent:`), que únicamente entiende Claude Code (no aplica link oficial — patrón propio del repo).

## Cómo funciona

El skill tiene dos ramas, escritas como secciones:

```markdown
## If you are not already the `<agente>` agent
Delegate this whole request, including <user_request> verbatim, to the `<agente>` subagent and wait for its report.
Do not run `<proceso>` yourself: only that agent knows …
If you cannot delegate, stop and say so; do not … without the agent.

## If you are the `<agente>` agent
Run `<proceso>` on …
```

```mermaid
flowchart LR
  U["/skill args"] --> R{runtime}
  R -->|Claude: context fork + agent| IN[ya dentro del agente] --> P[rama 'eres el agente' → proceso]
  R -->|Antigravity: ignora el fork| M[agente principal] --> D{¿puede delegar?}
  D -->|sí: invoke_subagent| IN
  D -->|no| S[se detiene y explica el motivo]
```

- La salida "detente y dilo" es la que evita el fallo silencioso: el proceso ejecutado sin el agente no tiene, por ejemplo, la tabla rol → skill.
- El subagente arranca con el contexto vacío, así que la petición se le pasa **literal** (`<user_request>`).

## Cuándo aplica

Cualquier skill que dependa de un agente concreto y que se despliegue en más de un runtime. Si el proceso funciona igual en cualquier agente, no hace falta delegar.

## Evolución observada en la implementación

En la auditoría de los paquetes, el envoltorio `pr-review-java` era el único que delegaba solo por frontmatter. Su sustituto, `review-pr-java`, aplica este patrón. En la prueba real en `agy` hubo dos casos:
- con el hook de prerrequisitos roto, el agente principal no pudo delegar, se detuvo y lo explicó;
- con el hook corregido, delegó con `invoke_subagent` y devolvió la revisión completa.
