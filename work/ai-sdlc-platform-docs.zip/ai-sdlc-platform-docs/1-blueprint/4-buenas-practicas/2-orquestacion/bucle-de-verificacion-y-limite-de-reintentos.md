# Bucle de verificación y límite de reintentos

## Qué es

Patrón verificar → si no cumple la [definición de hecho](../3-control-y-calidad/definicion-de-hecho.md) → corregir y reintentar.

Está acotado por un límite de reintentos configurable (valor por defecto: 5 fallos) (no aplica link oficial — patrón propio del repo). Nunca reintento infinito, nunca descarte silencioso al agotar el límite.

## Cómo funciona

Cada iteración del bucle cuenta como un intento consumido, incluso si el resultado es vacío o fallido — un intento fallido no se descarta del conteo ni se repite gratis. Al llegar al límite sin resolver:
- se reporta el estado igualmente, con severidad reducida o marcado como no resuelto, nunca se omite en silencio;
- o se escala a input humano, según lo que defina el modo de fallo de la fase (ver [ciclo-de-vida-de-fases.md](ciclo-de-vida-de-fases.md)).

El límite es un parámetro del agente/skill, no un valor hardcodeado en prosa — 5 es el default razonable, ajustable según el costo de cada intento y la criticidad de la tarea.

Precedente real ya en producción: `java-reviewer` reintenta `fetchFile` hasta 5 veces por hipótesis de hallazgo no resuelta antes de reportarla con severidad `advice`, contando un fetch vacío/fallido como uno de los 5 intentos.

Esta práctica generaliza ese patrón puntual a cualquier agente con fases de tipo "corregir y reintentar", y lo declara explícitamente configurable en vez de fijo.

## Cuándo aplica

Cualquier fase cuyo modo de fallo sea "corregir y reintentar" — verificación de hallazgos, validación de builds/tests, resolución de hipótesis ambiguas. No aplica a fases con modo de fallo "abortar" o "esperar input" directo, donde no hay ciclo de corrección que acotar.

## Evolución observada en la implementación

El precedente citado arriba (`java-reviewer`, `fetchFile` ×5) es de la primera implementación y ya no existe. La implementación actual resuelve el mismo problema —*qué hacer cuando no se puede confirmar algo*— **sin reintentar**:

- la capacidad devuelve `execution.status: partial` con un `reason` (*"sin informe JaCoCo; solo se comprobó la existencia de tests"*);
- el proceso **limita el veredicto** (`APPROVE` pasa a `COMMENT`).

Cumple las dos reglas del patrón (nunca descarte silencioso; el estado se reporta igual) por **degradación**, no por bucle. Además hay verificación posterior (`gh_pr.py verify` falla el job de CI) y topes (`--max-turns 30`, `--max-bytes`).

| Situación | Conviene |
|---|---|
| Un nuevo intento puede cambiar el resultado (una lectura que falló) | **Reintentar** con límite |
| El dato no existe (el informe no está) | **Degradar** y declararlo |

Fuente: `act-java-check-coverage/SKILL.md`, `proc-pr-review/SKILL.md` (paso 5) y el workflow de CI.

## Primer precedente implementado: remediación de SARIF

`proc-sarif-remediation` (fase 6) es el primer bucle real del patrón ([ADR 0016, actualización 2026-11-03](../../5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md)):

- `max-attempts` es parámetro, con default **3** (no 5): cada intento cuesta build + integración + una llamada a agente.
- **Todo intento cuenta**: `apply` determinista, `no_changes`, timeout y el agente que movió HEAD.
- Escalado: el intento 1 usa el fix del SARIF; si no hay fix, hay `stale_region` o el build falla, los siguientes van al rol `code-fix` con el `<build_result>` anterior en el brief.
- Al agotar: se **revierte** hasta el último commit bueno, el ítem queda `failed` con fase y motivo, y el proceso **sigue con el siguiente**. Nunca se descarta en silencio.

Fuente: [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).
