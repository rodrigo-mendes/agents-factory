# Ciclo de vida fijo de fases

## Qué es

Un agente con tarea multi-paso no trivial declara sus fases con nombre fijo y un modo de fallo explícito por fase — no un prompt libre sin estructura (no aplica link oficial — patrón propio del repo). Ejemplo de fases: Verificar → Analizar → Consultar → Proponer → Implementar → Validar.

## Cómo funciona

Cada fase tiene: qué hace, y qué pasa si falla:

- abortar la ejecución completa;
- esperar input del usuario;
- o corregir y reintentar.

Existe una excepción documentada: un agente puramente asesor (sin capacidad de escritura) reemplaza la fase "Implementar" por "Entregar" — su output final es una recomendación, no un cambio aplicado.

## Cuándo aplica

Cualquier agente cuya tarea tenga más de un paso lógico y donde sea valioso poder auditar en qué fase se detuvo o falló una ejecución. No aplica a skills de un solo paso (una consulta, una transformación simple) donde el ciclo de fases sería ceremonia sin beneficio.

## Evolución observada en la implementación

`proc-pr-review` es un caso completo, y además la excepción documentada del **asesor**: termina en "Entregar", no en "Implementar".

| Fase | Qué hace | Modo de fallo |
|---|---|---|
| 1. Obtener el cambio | `preflight` → `resolve` → `files` → `diff` | `no_gh` / `no_auth` / `no_pr` / diff vacío → **abortar** e informar; nunca inventar un diff |
| 2. Clasificar | producción / tests / configuración / dependencias | — |
| 3. Ejecutar roles | según la tabla de roles obligatorios | rol sin skill o sin `execution` → `not_executed` con motivo; **continúa** |
| 4. Consolidar | deduplica por (fichero, línea, causa) | — |
| 5. Veredicto | derivado de los hallazgos + límite por estado de rol | — |
| 6. Informe (Entregar) | `act-common-write-report`; publica solo si `publish` | publicación fallida o `publish=false` → devolver Markdown y preguntar |

Los modos de fallo son "abortar" o "continuar degradando"; no hay "corregir y reintentar".

Fuente: `proc-pr-review/SKILL.md`.

## Caso con escritura: remediación de SARIF

`proc-sarif-remediation` es el primer proceso con escritura y usa 10 fases. Aquí aparecen los tres modos de fallo, incluido "corregir y reintentar" (fase 6, ver [bucle de verificación](bucle-de-verificacion-y-limite-de-reintentos.md)).

| # | Fase | Modo de fallo |
|---|---|---|
| 1 | Parse | `invalid_sarif` / `unsupported_version` → **abortar** |
| 2 | Resolver destino (repo, base, provenance) | `missing_repo` / `ambiguous_repo` / `repo_mismatch` → **abortar** |
| 3 | Plan (gate) | en interactivo, **esperar** al usuario |
| 4 | Preparar worktree | `gh_error` / `git_error` → **abortar** |
| 5 | Baseline | `baseline_failed` → **abortar** (no se pueden atribuir fallos) |
| 6 | Remediar (bucle por ítem) | ítem `failed` → **revertir y continuar** |
| 7 | Verificar (`run.json` × git) | `state_mismatch` → no publica |
| 8 | Informe | — |
| 9 | Publicar | `publish_disabled` → termina bien sin publicar; fallo de push/PR → informe con el error y worktree conservado |
| 10 | Limpieza | aviso, no cambia el resultado |

Fuente: [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).
