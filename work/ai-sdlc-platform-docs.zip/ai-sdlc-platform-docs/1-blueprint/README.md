# Blueprint de primitivos — Claude Code, Antigravity y APM

> **Para quién:** quien diseña, implementa o revisa un paquete de la plataforma.
> **Qué responde:** qué primitivas se usan, en qué runtimes funcionan y dónde está el detalle de cada una.

## La regla

**Un paquete agnóstico se construye solo con agentes y skills** (más `instructions`, hooks y MCP). Así funciona igual en Claude Code y en Antigravity desde un único origen APM ([0019](5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).

- **Commands y prompts están prohibidos** en cualquier paquete. No todos los harnesses los soportan, según la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity) ([0020](5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)):
  - los `prompts` no se despliegan en ningún target (en Claude se convierten en commands);
  - los `commands` solo existen en Claude Code.
- Todo `/nombre` es una **skill de entrada**. Si tiene que correr dentro de un agente, pide la delegación en su texto ([0023](5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).

## Alcance

- **Primitivas agnósticas:** skills, subagentes y plugins (como concepto), documentados una vez.
- **Dos runtimes (harnesses):** Claude Code y Antigravity (`agy`). Lo específico de cada uno va en su ficha.
- **Una herramienta de terceros:** APM (Microsoft), que despliega las primitivas en cada runtime.

Los runtimes definen qué formato de archivo ejecutan; APM decide cuándo y cómo generarlo, instalarlo y distribuirlo. Los archivos canónicos llevan la URL oficial de cada afirmación; el resto enlaza a ellos, y lo que no tiene documentación oficial queda marcado "(no aplica link oficial)".

## Mapa del blueprint

| Grupo | Carpeta | Contenido |
|---|---|---|
| Conceptos | [`1-conceptos/`](1-conceptos/) | El "qué significa": 27 términos explicados desde cero ([índice](1-conceptos/README.md)) |
| Primitivas | [`2-primitivos/`](2-primitivos/) | Agnósticas: [skills.md](2-primitivos/skills.md), [subagents.md](2-primitivos/subagents.md), [plugins.md](2-primitivos/plugins.md). Fichas de runtime: [runtime-claude-code.md](2-primitivos/runtime-claude-code.md), [runtime-antigravity.md](2-primitivos/runtime-antigravity.md). [commands.md](2-primitivos/commands.md) solo redirige al formato histórico |
| Modelo operativo | [`3-modelo-operativo/`](3-modelo-operativo/) | Cómo se ejecuta y cómo se distribuye (detalle abajo) |
| Buenas prácticas | [`4-buenas-practicas/`](4-buenas-practicas/) | El "cómo" de 19 patrones recomendados ([índice](4-buenas-practicas/README.md)) |
| Decisiones | [`5-decisiones/`](5-decisiones/) | El "por qué": 23 ADRs con contexto, alternativas y consecuencias ([índice](5-decisiones/README.md)) |
| Manual de creación | [`6-manual-creacion-plugin/`](6-manual-creacion-plugin/) | La secuencia: 9 fases para crear un paquete agnóstico, enlazando a los grupos anteriores ([índice](6-manual-creacion-plugin/README.md)) |

Archivos de [`3-modelo-operativo/`](3-modelo-operativo/):

| Tema | Agnóstico | Claude Code | Antigravity |
|---|---|---|---|
| Ejecución (runtime, puntos de entrada) | [modelo-ejecucion.md](3-modelo-operativo/modelo-ejecucion.md) | [modelo-ejecucion-claude-code.md](3-modelo-operativo/modelo-ejecucion-claude-code.md) | [modelo-ejecucion-antigravity.md](3-modelo-operativo/modelo-ejecucion-antigravity.md) |
| Distribución (APM, install) | [distribucion.md](3-modelo-operativo/distribucion.md) | [distribucion-claude-code.md](3-modelo-operativo/distribucion-claude-code.md) | [distribucion-antigravity.md](3-modelo-operativo/distribucion-antigravity.md) |
| Repos reales | [topologia-repos.md](3-modelo-operativo/topologia-repos.md) | — | — |

Quien no venga de este mundo (crear o customizar agentes) empieza por [`1-conceptos/`](1-conceptos/).

## Tabla resumen de uso

| Primitiva | Objetivo | Cuándo usar | Cuándo NO usar | Runtimes | Detalle |
|---|---|---|---|---|---|
| **Skill** | Conocimiento o procedimiento reusable, activado por `description` o con `/nombre` | Checklist o guía cuyo resultado intermedio debe quedar en el contexto de quien llama; archivos de soporte; **todo punto de entrada `/nombre`** (skill de entrada) | Hace falta aislamiento fuerte de herramientas o un contexto propio → Subagente | Claude Code (`.claude/skills/`) y Antigravity (`.agents/skills/`), desplegada por APM | [skills.md](2-primitivos/skills.md) |
| **Subagente** | Ejecutar una tarea en contexto aislado y devolver solo el resultado | El proceso intermedio no debe contaminar el contexto; restricción estructural de herramientas; reuso o fan-out | El resultado intermedio es lo que quien llama necesita; hace falta confirmación humana a mitad de tarea | Claude Code (`.claude/agents/`, APM) y Antigravity (`.agents/agents/`, aprovisionador) | [subagents.md](2-primitivos/subagents.md) |
| **Plugin** | Empaquetar skills, agentes, hooks y MCP como unidad instalable versionada | Distribuir en Claude Code a través del marketplace; lo genera `apm pack` | Una sola skill o agente sin distribución; en Antigravity (se usa `apm install`) | Solo Claude Code en la plataforma (Antigravity tiene un formato propio que no se usa) | [plugins.md](2-primitivos/plugins.md) |
| **APM** (terceros) | Declarar, resolver, instalar y empaquetar dependencias de agentes | Reuso entre repos; más de un runtime; catálogo de plugins | Un solo artefacto, en un solo repo y para un solo runtime | Targets `claude` y `antigravity`, declarados en cada paquete | [distribucion.md](3-modelo-operativo/distribucion.md) |

> **Commands y prompts no son una opción.** Están prohibidos en cualquier paquete ([0020](5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)). El formato histórico de Claude y su migración a skills están en [runtime-claude-code.md](2-primitivos/runtime-claude-code.md#commands--formato-histórico-prohibido-en-paquetes-nuevos).

## Frontera runtimes vs. APM

Qué lee cada runtime:
- **Claude Code:** `SKILL.md`, `.claude/agents/*.md`, `settings.json` y, para el marketplace, `plugin.json` y `marketplace.json`.
- **Antigravity:** `SKILL.md`, `.agents/agents/*.md`, `.agents/rules/`, `.agents/hooks.json` y `mcp_config.json`.

Ningún runtime genera esos archivos desde un catálogo de dependencias ni resuelve dependencias entre repos: eso es trabajo de APM.

Lo que APM no despliega en Antigravity (agentes) y las rutas de hooks que escribe mal los cubre un aprovisionador ([0021](5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

Qué campos de frontmatter valida APM y cuáles pasa intactos: [skills.md](2-primitivos/skills.md#frontmatter-y-apm), [subagents.md](2-primitivos/subagents.md#frontmatter-y-apm) y [distribucion.md](3-modelo-operativo/distribucion.md).
