# Subagente y aislamiento de contexto

## En una frase

Un subagente es una tarea que se ejecuta en su propia "cabeza" limpia, sin ver la conversación previa, y que al terminar solo devuelve un mensaje de texto — nunca su proceso intermedio.

## Analogía

Es como encargarle un recado a alguien que no estuvo en la reunión donde se decidió por qué hace falta ese recado. Le das instrucciones puntuales, hace el trabajo por su cuenta y vuelve con el resultado.

Pero no vuelve contándote todo lo que investigó ni todos los callejones sin salida que probó por el camino. Tú solo te quedas con la respuesta.

## Explicación

Cuando se invoca un [subagente](../../2-primitivos/subagents.md), el harness le da una [ventana de contexto](../1-fundamentos-del-modelo/ventana-de-contexto.md) propia.

Esa ventana está aislada de la conversación que lo invocó. Pasa igual en los dos runtimes:
- en Claude Code, `.claude/agents/<nombre>.md`, invocado con la herramienta `Agent` o con una skill con `context: fork`;
- en Antigravity, `.agents/agents/<nombre>.md`, invocado con `invoke_subagent`.

No hereda el historial previo, ni las skills ya activadas, ni los archivos que el llamante ya había leído. Recibe:

- su system prompt (el cuerpo del agente);
- el mensaje de delegación;
- las skills que su [frontmatter](frontmatter.md) declara en `skills:`;
- en Claude, además, la jerarquía de `CLAUDE.md` y una foto del estado de git.

La consecuencia que más se pasa por alto es esta: **por esa frontera solo pasa texto.** No hay callbacks, no hay file handles, no hay estado compartido entre el subagente y quien lo llamó. Solo el mensaje de delegación que entra y el mensaje final que sale.

Cualquier diseño que asuma pasar una función invocable o una referencia viva a través de esa frontera está roto por construcción, aunque el frontmatter no avise de nada.

Hay que rediseñarlo como texto puro. Por ejemplo, un comando parametrizado que el propio subagente ejecuta, en vez de una función que el llamante le entrega.

Esto es exactamente lo que hace útil al subagente como [token firewall](token-firewall.md). Puede leer decenas de archivos, descartar hipótesis, iterar: todo ese volumen se queda dentro de su contexto y se descarta al terminar.

El llamante solo paga el prompt de entrada más el resultado final, nunca el ruido intermedio.

El aislamiento no es infinito hacia dentro. En Claude Code, un subagente puede lanzar sub-subagentes solo hasta 3 capas por debajo de la conversación principal (configurable con `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH`).

Es un límite técnico, no de diseño. El blueprint de este repo puede (y debería, según [ADR 0010](../../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md)) fijar un tope de diseño más estricto que ese techo.

## Cómo lo aplicamos aquí

`backend-java` es el subagente en el que delega la skill de entrada `/review-pr-java`. Arranca **sin el historial del usuario** y recibe solo el texto de delegación (PR, foco, `publish`) más las skills que declara.

Lo que vuelve es **solo texto**: el informe y la pregunta de publicar.

El caso que ilustra la frontera de texto es el del patch. En vez de pasar un callback o un handle, `gh_pr.py` escribe el diff en una ruta calculada a partir del PR y del commit. Cualquier rol que conozca el `sha` la reconstruye con `patch --expect-sha`.

Nada vivo cruza la frontera: el estado compartido es un fichero direccionable de forma determinista.

En la remediación de SARIF, `backend-java-fix` recibe solo un `<remediation_brief>` y la ruta absoluta del worktree, y devuelve un resumen corto que el orquestador trata como dato. Como no puede preguntar a mitad, el flujo interactivo se parte en pasos con el estado en `run.json` ([sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md)).

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Delegación | `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` | Delega en el subagente con la petición literal (`<user_request>`) como único texto; `publish=false` salvo petición expresa |
| Agente | `ai-sdlc-backend-java/.apm/agents/backend-java.agent.md` | Arranca sin el historial del usuario; su contrato de entrada/salida es explícito porque no hay otra manera de comunicarse con él |
| Patch por SHA | `act-common-github-pr/SKILL.md` | Sustituye el callback por una ruta derivada del commit |

## ADR relacionados

- [0010 — Jerarquía de capas con prohibiciones explícitas](../../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md)
- [0021 — Aprovisionador post-install para Antigravity](../../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md): genera los subagentes en `.agents/agents/`.
- [0023 — Delegación explícita en el texto](../../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)

## Ver también

- [primitivos/subagents.md](../../2-primitivos/subagents.md)
- [buenas-practicas/cap-fanout-depth.md](../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md)
- [buenas-practicas/jerarquia-de-capas-responsabilidad.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md)
- [token-firewall.md](token-firewall.md)
- [frontmatter.md](frontmatter.md)
