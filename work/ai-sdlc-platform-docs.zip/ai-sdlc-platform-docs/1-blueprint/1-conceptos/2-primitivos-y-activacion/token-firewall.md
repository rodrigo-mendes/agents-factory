# Token firewall

## En una frase

Es usar un [subagente](subagente-y-aislamiento-de-contexto.md) precisamente para que todo el material voluminoso que lee (archivos, diffs, logs) se quede encerrado en su propio contexto y nunca llegue a inflar la conversación de quien lo invocó.

## Analogía

Es como pedirle a alguien que revise una caja llena de papeles y te traiga solo la conclusión en una nota de una línea. No te trae la caja de vuelta.

Si tuvieras que revisar tú mismo esos papeles, tu escritorio (tu atención, tu memoria de corto plazo) acabaría lleno de hojas que ya no necesitas para la decisión que sigue.

## Explicación

"Token firewall" no es un mecanismo propio de ningún harness. Es el nombre que este repo le da al efecto que produce el [aislamiento de contexto de un subagente](subagente-y-aislamiento-de-contexto.md).

Ese efecto aparece cuando el aislamiento se usa deliberadamente para controlar coste de [tokens](../1-fundamentos-del-modelo/token-y-coste.md), y no solo para restringir herramientas.

La idea es simple: una tarea necesita leer mucho material desechable para llegar a una conclusión corta. Si se delega a un subagente, ese material nunca entra en la [ventana de contexto](../1-fundamentos-del-modelo/ventana-de-contexto.md) de quien delega. Solo entra el resultado final.

El caso de referencia en este repo es `backend-java`. La skill de entrada `/review-pr-java` delega en él (con `context: fork` en Claude, con `invoke_subagent` en Antigravity):

- El diff completo y las reglas de los tres roles (estilo, seguridad, cobertura) se quedan en **su** contexto.
- A la conversación principal solo vuelve el informe (resumen, comentarios inline y veredicto).

Si `proc-pr-review` corriera inline en la conversación del developer, el patch y las checklists de los tres roles ocuparían la ventana el resto de la sesión. Y lo harían justo cuando hay que consolidar y decidir el veredicto, con el contexto ya degradado.

El cortafuegos no es gratis. Cuesta dos cosas:

- Un contrato de entrada/salida explícito: todo lo que cruza la frontera es texto, nunca una función ni un estado compartido.
- Un round-trip.

Se paga solo cuando el volumen de material desechable es alto. Para tareas pequeñas con un único llamante, ese coste puede no justificarse frente a mantener todo inline como skill.

## Cómo lo aplicamos aquí

El cortafuegos tiene un segundo nivel, **en el propio acceso a datos**:

| Mecanismo | Qué hace |
|---|---|
| `gh_pr.py diff` | Escribe el patch en `$TMPDIR/ai-sdlc-pr-<uid>/…-<sha12>.patch`; no lo imprime |
| Lectura por rangos | El agente lee el fichero por trozos, sin pegar el patch entero en la conversación |
| `--max-bytes` (200 000 por defecto) | Trunca el patch; el `.json` de metadatos marca `truncated: true` y lista los ficheros, y el informe debe decir cuáles no se leyeron |

En la remediación de SARIF el segundo nivel tiene dos mecanismos más:

| Mecanismo | Qué hace |
|---|---|
| `run.json` | El estado de la ejecución (ítems, intentos, fases, commits) vive en un fichero que escribe `sarif.py state`; el modelo lo consulta con `show` y `summary` en vez de acumularlo en la conversación |
| `<build_result>` con `log_excerpt` (4 KB) + `log_path` | `java_build.py` devuelve solo el extracto relevante del log y la ruta del log completo, que se lee por rangos solo si hace falta |

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Skill de entrada | `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` | Delega en `backend-java`: el diff y las reglas no entran en la conversación principal |
| Patch en fichero y tope | `act-common-github-pr/SKILL.md` (fase A) y `gh_pr.py` (`cmd_diff`) | Escribe el diff en disco, lo lee por rangos y lo trunca con aviso |
| `2-primitivos/subagents.md` | [`subagents.md`](../../2-primitivos/subagents.md) | Nombra explícitamente "Aislamiento de contexto (token firewall)" como razón de ser del subagente |

## ADR relacionados

Ninguno — vocabulario base.

## Ver también

- [primitivos/subagents.md](../../2-primitivos/subagents.md)
- [subagente-y-aislamiento-de-contexto.md](subagente-y-aislamiento-de-contexto.md)
