# Frontmatter

## En una frase

El frontmatter es el bloque de configuración al principio de un archivo (entre dos líneas `---`) que le dice al harness (Claude Code o Antigravity) cómo debe tratar ese archivo, antes de que nadie lea una sola palabra de su contenido.

## Analogía

Es como la ficha técnica pegada en la puerta de una sala de reuniones: quién puede entrar, cuántas personas caben, qué equipo hay dentro. No necesitas entrar a la sala para saber si te sirve — la ficha ya te lo dice desde fuera.

## Explicación

Un archivo de skill o de subagente tiene dos partes:

- el frontmatter (metadatos en formato YAML);
- el cuerpo (las instrucciones en prosa que sigue el modelo).

La diferencia importante no es de formato, es de quién hace cumplir cada parte.

- **El cuerpo** es texto que el modelo *interpreta*. Puede malinterpretarlo, olvidarlo a mitad de una tarea larga, o simplemente decidir ignorarlo si el prompt se corrompe.
- **El frontmatter**, en cambio, lo aplica el [harness](harness-de-agente.md) como plataforma antes de que el modelo razone nada. Es *enforcement estructural*, no una sugerencia en prosa.

El ejemplo más claro es `tools:` en un [subagente](subagente-y-aislamiento-de-contexto.md). Si un agente declara `tools: Bash`, ese agente **no puede** usar `Write` ni `Edit`.

Da igual que su propio prompt diga "genera un informe y guárdalo en un archivo": la herramienta simplemente no existe para él.

Ninguna instrucción en el cuerpo puede revertir esa restricción.

En Claude Code pasa lo mismo con `disable-model-invocation: true`. La [description](description-matching.md) de esa skill ni siquiera entra en la [ventana de contexto](../1-fundamentos-del-modelo/ventana-de-contexto.md) del modelo, así que no puede elegirla.

Distintos tipos de archivo aceptan distintos campos, y poner el campo equivocado no da error: el dato queda silenciosamente ignorado.

- Una skill usa `allowed-tools` (restringe sobre el pool heredado).
- Un subagente usa `tools` (sustituye el pool heredado por completo).

Confundir los dos no rompe nada visible. Simplemente no hace lo que se esperaba.

Además, **cada harness lee su propio subconjunto**. Lo común a los dos runtimes es poco: `name`, `description` y, en agentes, `tools` (traducido en Antigravity), `model: inherit` y `skills`.

Campos como `context: fork`, `agent:`, `disable-model-invocation` y `user-invocable` son **solo de Claude**: Antigravity los ignora sin avisar.

Las tablas completas están en [runtime-claude-code.md](../../2-primitivos/runtime-claude-code.md) y [runtime-antigravity.md](../../2-primitivos/runtime-antigravity.md).

## Cómo lo aplicamos aquí

Tres campos reales que la plataforma hace cumplir, con efectos que ninguna instrucción puede revertir:

| Campo | Dónde | Efecto |
|---|---|---|
| `tools: Read, Grep, Glob, Bash` | `backend-java-ci` | Sin `Write`/`Edit` no puede modificar lo que revisa, diga lo que diga el PR. Al ser una allowlist que sustituye el pool, tampoco tiene `Agent` ni `Skill`. En Antigravity el aprovisionador la traduce (`view_file`, `grep_search`, `find_by_name`, `run_command`) |
| `skills: [proc-pr-review, act-java-check-style, …]` | `backend-java-ci` | Por no tener `Skill`, precarga las siete que necesita. Si faltara una, el cuerpo describiría un rol que no puede cargar y nada avisaría. En Antigravity precarga, pero no limita |
| `user-invocable: false` y `applyTo: "**/*.java"` | skills internas y `std-java-coding` | En Claude, las skills internas no aparecen en el menú (Antigravity ignora `user-invocable` y las muestra). La instruction Java se carga sola en los dos runtimes (en Antigravity, como regla con `globs`) |

`backend-java`, en cambio, **no declara `tools`** y hereda el pool: es la elección deliberada del agente interactivo, mientras que el de CI se restringe.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Agente de CI | `ai-sdlc-backend-java/.apm/agents/backend-java-ci.agent.md` | Allowlist de `tools` y `skills:` precargadas |
| Agente interactivo | `ai-sdlc-backend-java/.apm/agents/backend-java.agent.md` | Sin `tools`: hereda el pool (en Antigravity, el aprovisionador le da todas) |
| Skill de entrada | `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` | `context: fork` + `agent:` + `disable-model-invocation: true`, solo efectivos en Claude; la delegación también se pide en el texto |
| Normativa Java | `ai-sdlc-kb-java/.apm/instructions/std-java-coding.instructions.md` | `applyTo` carga la normativa sola |

## ADR relacionados

- [0011 — Arquetipos de agente por forma](../../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md)
- [0012 — Mantener commands/ como formato separado de skills/](../../5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md) — **Reemplazada** por [0020](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md).
- [0020 — Puntos de entrada como skills](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md): qué campos lee cada runtime.

## Ver también

- [primitivos/skills.md](../../2-primitivos/skills.md)
- [primitivos/subagents.md](../../2-primitivos/subagents.md)
- [description-matching.md](description-matching.md)
- [subagente-y-aislamiento-de-contexto.md](subagente-y-aislamiento-de-contexto.md)
