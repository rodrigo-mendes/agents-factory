# Progressive disclosure

## En una frase

Es cargar solo lo mínimo de una skill por defecto (su descripción) y dejar el resto de su contenido — el cuerpo completo, los archivos de soporte — para cargarlo únicamente cuando de verdad haga falta.

## Analogía

Es como un manual de instrucciones con índice: al abrirlo no lees las 200 páginas, lees el índice de una línea por capítulo, y solo pasas a la página 47 cuando de verdad necesitas el procedimiento que está ahí. El resto del manual sigue existiendo, pero no ocupa tu escritorio hasta que lo pides.

## Explicación

Una skill vive en un directorio: `.claude/skills/<nombre>/SKILL.md` en Claude Code, `.agents/skills/<nombre>/SKILL.md` en Antigravity. Junto al `SKILL.md` puede tener archivos de soporte adicionales: plantillas, catálogos, sub-documentos.

La carga es escalonada en tres niveles:

- **Siempre:** en cada sesión, lo único presente en la [ventana de contexto](../1-fundamentos-del-modelo/ventana-de-contexto.md) del modelo es la `description` de cada skill instalada. Son unas pocas decenas de [tokens](../1-fundamentos-del-modelo/token-y-coste.md).
- **Al activarse:** el cuerpo completo del `SKILL.md` (cientos o miles de tokens) solo se carga cuando esa skill se activa. Da igual si es por [description matching](description-matching.md) o porque alguien la invocó por nombre.
- **Bajo demanda:** los archivos de soporte ni siquiera se cargan al activarse la skill. Solo se cargan cuando el propio cuerpo del `SKILL.md` manda leerlos por ruta explícita.

Este mecanismo escalonado es lo que permite tener decenas de skills instaladas sin pagar su coste completo por adelantado.

Sin progressive disclosure, cada skill instalada costaría tokens todo el tiempo, activa o no. Con ella, el coste permanente es solo el de la description, y el coste grande solo aparece cuando de verdad se usa.

El ejemplo más claro en este repo es `kb-java-best-practices`. Su `SKILL.md` es solo un índice corto. El conocimiento largo vive en `references/`: guías condensadas y cuatro guías completas que se leen *cuando la condensada no basta*.

`proc-pr-review` hace lo mismo con `references/findings-contract.md`: el proceso se carga entero, el contrato solo cuando hace falta.

El caso extremo, **solo en Claude Code**, es `disable-model-invocation: true` en el [frontmatter](frontmatter.md): ni siquiera la description entra en contexto, y el coste es cero hasta que alguien teclea el nombre. Antigravity ignora el campo: siempre anuncia nombre y `description`.

## Cómo lo aplicamos aquí

El propio blueprint de este repo sigue esta idea en su propio diseño de tamaño.

Hay un umbral concreto (~500 líneas) para cuándo un contenido debe salir del `SKILL.md` principal y convertirse en archivo de soporte cargado on-demand. Así no crece sin control dentro del archivo que siempre se carga entero al activarse.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| `2-primitivos/skills.md` | [`skills.md`](../../2-primitivos/skills.md) (sección "Por qué así") | Declara progressive disclosure como la razón de ser de los archivos de soporte junto a `SKILL.md` |
| `kb-java-best-practices` | `ai-sdlc-kb-java/.apm/skills/kb-java-best-practices/SKILL.md` | Índice corto; las guías extensas viven en `references/` y se leen solo cuando la condensada no basta |
| `proc-pr-review` | `ai-sdlc-shared-skills/.apm/skills/proc-pr-review/references/findings-contract.md` | El contrato de hallazgos se carga bajo demanda, no con el proceso |

## ADR relacionados

- [0008 — Límite de tamaño concreto para SKILL.md](../../5-decisiones/1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md)

## Ver también

- [primitivos/skills.md](../../2-primitivos/skills.md)
- [buenas-practicas/limite-de-tamano-y-blueprints.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md)
- [description-matching.md](description-matching.md)
