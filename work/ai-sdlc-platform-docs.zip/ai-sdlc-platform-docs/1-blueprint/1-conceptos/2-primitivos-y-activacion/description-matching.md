# Description matching

## En una frase

Es el mecanismo por el cual el modelo decide, sin que nadie lo teclee, qué skill o agente activar — comparando lo que el usuario pide contra el resumen corto que cada skill declaró de sí misma.

## Analogía

Es como un recepcionista que no ha leído ningún expediente, solo la etiqueta de la carpeta. Cuando alguien llega con un problema, mira los rótulos de todas las carpetas disponibles y elige la que suena más parecida — sin abrir ninguna hasta haber elegido.

## Explicación

Cada skill declara un campo `description` en su [frontmatter](frontmatter.md). Ese texto (y solo ese texto, no el cuerpo completo de la skill) está siempre presente en la [ventana de contexto](../1-fundamentos-del-modelo/ventana-de-contexto.md) del modelo.

Allí convive con las descriptions de todas las demás skills instaladas. Cuando el usuario escribe algo en lenguaje natural, el modelo compara semánticamente esa petición contra el catálogo de descriptions. Y elige sin haber cargado todavía el cuerpo de ninguna skill.

Esto es lo que permite tener decenas de skills instaladas sin pagar su costo completo de [tokens](../1-fundamentos-del-modelo/token-y-coste.md) por adelantado. El mecanismo completo está en [progressive-disclosure.md](progressive-disclosure.md).

Este matching es la activación *por defecto*, y en los dos runtimes funciona igual. Lo que cambia es cómo se frena:

| Runtime | Cómo se frena la activación automática |
|---|---|
| Claude Code | `disable-model-invocation: true` saca la `description` del contexto: la skill solo se activa si alguien la teclea. `user-invocable: false` hace lo contrario: oculta la skill del menú `/` y la deja para el modelo. Los dos campos son **solo de Claude** |
| Antigravity | No hay campo equivalente. El único freno es la propia `description` ("úsalo solo cuando el usuario lo pida") |

Por eso una skill de entrada lleva los dos frenos ([0020](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).

El riesgo práctico de este mecanismo es el solapamiento. Si dos skills tienen descriptions parecidas, cuál se activa es, en la práctica, una moneda al aire. Es el bug más difícil de diagnosticar: no hay ningún error visible, solo una activación "equivocada" ocasional.

Por eso una buena description dice *cuándo* usarse (y cuándo no), no solo *qué* hace.

Este [no determinismo](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) de la elección es justamente el problema que resuelve el patrón de agente router.

Cuando la petición del usuario es ambigua entre dos o más candidatas, no se deja que el modelo elija a ciegas. Un componente intermedio detecta la ambigüedad y pregunta antes de ejecutar nada.

## Cómo lo aplicamos aquí

La entrada agnóstica **agente por `description`** del [modelo de ejecución](../../3-modelo-operativo/modelo-ejecucion.md) usa este matching para elegir el subagente cuando nadie teclea una skill de entrada. Funciona en los dos runtimes: en Antigravity lo decide el planificador del agente principal.

El modelo asume que el matching resuelve un candidato claro; el caso ambiguo está resuelto solo como decisión de diseño ([ADR 0001](../../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md)), sin implementar todavía.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Modelo de ejecución (entradas agnósticas) | [`modelo-ejecucion.md`](../../3-modelo-operativo/modelo-ejecucion.md) | La entrada "agente por `description`": selección automática del subagente, sin skill de entrada |
| Skill de entrada `review-pr-java` | `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` | `disable-model-invocation: true` (Claude) y una `description` "úsalo solo cuando el usuario lo pida" (Antigravity) |

## ADR relacionados

- [0001 — Agente router para entrada ambigua](../../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md)
- [0012 — Mantener commands/ como formato separado de skills/](../../5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md) — **Reemplazada** por [0020](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md).
- [0020 — Puntos de entrada como skills](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md): la `description` como freno en Antigravity.

## Ver también

- [primitivos/skills.md](../../2-primitivos/skills.md)
- [buenas-practicas/agente-router.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md)
- [frontmatter.md](frontmatter.md)
- [progressive-disclosure.md](progressive-disclosure.md)
