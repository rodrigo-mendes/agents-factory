# Harness de agente

## En una frase

El harness es el programa host que arranca al modelo, le entrega system prompt y tools, aplica el frontmatter, gestiona la ventana de contexto y decide qué puede o no hacer — el modelo nunca corre solo.

## Analogía

El modelo es el actor; el harness es el teatro entero — escenario, guion que le entregan antes de salir, micrófono, y el equipo que decide qué puede tocar y qué no. El actor improvisa sus líneas, pero no construyó el escenario ni decide si puede salir del edificio.

## Explicación

Un LLM por sí solo solo predice texto: no lee archivos, no ejecuta comandos, no recuerda entre llamadas. El harness es la capa de software que lo rodea y lo convierte en agente. En este repo hay dos: **Claude Code** y **Antigravity (`agy`)**.

El harness es quien:
- carga el [frontmatter](frontmatter.md) de un agente (`.claude/agents/*.md` o `.agents/agents/*.md`) y decide qué `tools:` inyectar;
- recorta y gestiona la [ventana de contexto](../1-fundamentos-del-modelo/ventana-de-contexto.md);
- arranca un [subagente](subagente-y-aislamiento-de-contexto.md) con el contexto limpio;
- aplica permisos, hooks y límites de profundidad de fan-out.

El [prompt y system prompt](../1-fundamentos-del-modelo/prompt-y-system-prompt.md) es lo que el harness le entrega al modelo en cada turno; el harness decide cuándo y con qué.

La distinción importa porque el frontmatter no es prosa decorativa: es la única superficie que el harness valida mecánicamente.

Si el cuerpo de un agente dice "delega en otro subagente" pero su `tools:` no incluye la herramienta de delegación (`Agent` en Claude, `invoke_subagent` en Antigravity), el harness no la ofrece. El harness no lee intenciones: aplica reglas sobre el frontmatter.

"Multi-harness" en este repo (ver [modelo-operativo/distribucion.md](../../3-modelo-operativo/distribucion.md)) significa que APM puede generar el mismo agente/skill para más de un harness (hoy Claude Code y Antigravity).

El harness es la variable que cambia entre destinos. El contenido declarado en `apm.yml` es el que se mantiene fijo.

Cada harness lee su propio subconjunto del frontmatter y tiene su propio contrato de hooks y de permisos. Por eso el mismo archivo puede comportarse distinto:

- Antigravity ignora `context: fork` y `agent:`.
- Antigravity bloquea con `{"decision":"deny"}` donde Claude Code usa el código de salida 2 ([0022](../../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)).

## Cómo lo aplicamos aquí

`backend-java` corre en dos harnesses desde el mismo origen APM ([0019](../../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)):
- **Claude Code**, en dos modos:
  - interactivo (skill de entrada `/review-pr-java`, con `context: fork`);
  - sin supervisión en CI (`claude-code-action`, con `--allowedTools` y `--disallowedTools`).

  Es el mismo harness aplicando permisos distintos. `backend-java-ci` declara `tools: Read, Grep, Glob, Bash` y el workflow deniega `Edit`, `Write` y `git push`. Así que es el harness, no un revisor humano, quien impone ese límite.
- **Antigravity (`agy`)**, interactivo o `agy -p`:
  - el agente lo genera el aprovisionador ([0021](../../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md));
  - la skill de entrada `/review-pr-java` pide la delegación en su texto, y el agente principal la resuelve con `invoke_subagent`;
  - los permisos de comandos solo se fijan a nivel global (`~/.gemini/antigravity-cli/settings.json`).

Ver [subagente-y-aislamiento-de-contexto](subagente-y-aislamiento-de-contexto.md).

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Claude Code | primer harness (`.claude/`) — ver [runtime-claude-code.md](../../2-primitivos/runtime-claude-code.md) | Lee todo el frontmatter (incluido `context: fork`), inyecta tools, gestiona contexto, arranca subagentes; bloquea hooks con código 2 |
| Antigravity (`agy`) | segundo harness (`.agents/`) — ver [runtime-antigravity.md](../../2-primitivos/runtime-antigravity.md) y [distribucion-antigravity.md](../../3-modelo-operativo/distribucion-antigravity.md) | Lee `name`/`description`, delega con `invoke_subagent`, aplica hooks `PreToolUse` con decisión `allow`/`deny`/`ask` |
| APM | [modelo-operativo/distribucion.md](../../3-modelo-operativo/distribucion.md) | Declara agentes/skills en `apm.yml` de forma independiente del harness destino ("multi-harness") |

## ADR relacionados

- [0019](../../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md) — soporte de dos harnesses desde un único origen.
- [0022](../../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md) — contrato de hooks de cada harness.

## Ver también

- [../../2-primitivos/runtime-claude-code.md](../../2-primitivos/runtime-claude-code.md)
- [../../2-primitivos/runtime-antigravity.md](../../2-primitivos/runtime-antigravity.md)
- [frontmatter.md](frontmatter.md)
- [subagente-y-aislamiento-de-contexto.md](subagente-y-aislamiento-de-contexto.md)
- [../1-fundamentos-del-modelo/ventana-de-contexto.md](../1-fundamentos-del-modelo/ventana-de-contexto.md)
- [../1-fundamentos-del-modelo/prompt-y-system-prompt.md](../1-fundamentos-del-modelo/prompt-y-system-prompt.md)
