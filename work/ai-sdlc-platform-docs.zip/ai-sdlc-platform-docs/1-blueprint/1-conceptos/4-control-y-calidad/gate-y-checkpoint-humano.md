# Gate y checkpoint humano

## En una frase

Es una parada obligatoria en la que un humano tiene que aprobar algo explícitamente antes de que el agente continúe — distinto de una puerta automática que un script verifica solo, sin que ningún humano intervenga.

## Analogía

Es como la diferencia entre un peaje con barrera que solo se levanta si el guardia revisa el pase (checkpoint humano) y un sensor automático que deja pasar el coche si la matrícula está en la lista permitida (puerta automática). Ambos frenan el tráfico, pero solo uno necesita a alguien mirando.

## Explicación

En este repo "gate" tiene dos usos que conviene no confundir.

El primero es el **gate antes de escribir**, un checkpoint humano real:

- el agente entra en modo de solo-lectura;
- presenta un plan concreto;
- solo empieza a escribir cuando el usuario lo aprueba explícitamente — nunca una confirmación genérica de "¿seguro?" sin mostrar el plan.

Un [subagente](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) no puede pedir esta confirmación a mitad de tarea porque no tiene ese canal. Por eso el gate se ubica siempre antes de delegar, no dentro de la delegación.

El segundo uso son las **puertas automáticas** del flujo de revisión de PRs. Son verificaciones deterministas que un script corre solas y que abortan o degradan según reglas fijas, sin ningún punto de aprobación intermedio.

Además hay una **traba de plataforma** que el modelo no puede mover, para el caso en que el modelo ignore la instrucción de no publicar.

## Cómo lo aplicamos aquí

El gate antes de escribir (checkpoint humano) está descrito en [`../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md`](../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md).

Se decidió en [`../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md`](../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md) — **Estado: Propuesta**.

Se exige como regla dura repetida en cada agente que aplica, pero no hay una plataforma que lo fuerce por sí sola. Depende de que quien escriba el prompt lo incluya.

Las puertas del flujo de revisión de PRs son estas. Tres son automáticas, una es humana y una es de plataforma:

| Puerta | Tipo | Qué comprueba y qué pasa |
|---|---|---|
| `preflight` | automática | `gh` instalado, autenticado y repositorio visible. Falla con `no_gh` o `no_auth`; el proceso devuelve Markdown y no publica |
| `resolve` | automática | Fija el PR y su `sha`. Sin PR en la rama: `no_pr` y **la revisión se detiene**; nunca se inventa un diff |
| Roles obligatorios | automática | `style-check` si cambia producción o tests; `security-scan` siempre; `coverage-check` si cambia producción. Un rol obligatorio que no termina en `full` convierte un `APPROVE` en `COMMENT` |
| `--expect-sha` | automática | Cada rol y `publish` exigen que el head siga siendo el analizado; si se movió: `stale_head` y no se publica |
| `publish=false` + pregunta del informe | **humana** | El informe termina con "¿publicar?" y vuelve a la conversación principal; publicar es una segunda orden |
| `GH_PR_PUBLISH=0` | plataforma | `gh_pr.py` rechaza `publish`, `comment` y `review-inline` (`publish_disabled`) aunque el agente lo intente. En Claude va en `env` de `.claude/settings.json`; en Antigravity se exporta en la shell, porque `agy` no lee `env` del proyecto |

**Remediación de SARIF (escribe código).** Mismo patrón, con una puerta automática más y el gate partido en pasos ([0005, actualización 2026-11-03](../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md)):

| Puerta | Tipo | Qué comprueba y qué pasa |
|---|---|---|
| Paso `plan` | **humana** | Tabla de ítems sin escribir nada; `apply` y `publish` son invocaciones posteriores, porque un subagente no puede preguntar a mitad |
| Baseline | automática | Build y tests antes de tocar nada; en rojo, `baseline_failed` y aborta |
| `verify` | automática | `run.json` × `git log base..HEAD` × HEAD; divergencia → `state_mismatch`, no publica |
| `GIT_CHANGE_PUBLISH=1` (+ `publish=true`) | plataforma | Sin la variable, `push` devuelve `publish_disabled` (interruptor invertido respecto a `GH_PR_PUBLISH`) |
| PR draft | plataforma | `pr-create` no tiene flag para quitar el draft |

En modo autónomo, "preguntar" se convierte en fallo con código. Detalle: [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).

**Lo que no existe:**

- No hay pre-flight sobre los metadatos del PR (ticket, coherencia título–diff, tamaño). `resolve` devuelve `draft` y `state`, pero el proceso no los usa.
- El único filtro de draft y de forks es del workflow de CI (`draft == false` y misma repo).
- El único límite de tamaño es `diff --max-bytes`, que **trunca y lo declara** (`truncated: true`), no bloquea.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Gate antes de escribir (checkpoint humano) | [`../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md`](../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md) | Define el plan-antes-de-escribir con aprobación explícita |
| `preflight`, `resolve`, `--expect-sha` | `act-common-github-pr/scripts/gh_pr.py` | Puertas automáticas |
| Roles obligatorios y límite del veredicto | `proc-pr-review/SKILL.md`, paso 3 y paso 5 | Tabla de roles y degradación de `APPROVE` |
| Pregunta de publicar | `act-common-write-report/SKILL.md` y `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` | `publish=false` por defecto; el informe pregunta |
| Traba de publicación | `gh_pr.py` (`GH_PR_PUBLISH`) | Rechaza escrituras aunque el modelo lo intente |
| Permisos de solo lectura | `.claude/settings.json` (Claude); hook `PreToolUse` con `ask` o regla global (Antigravity) | Ver [runtime-antigravity.md](../../2-primitivos/runtime-antigravity.md#permisos-y-variables-de-entorno) |
| Filtro de draft y forks | `ai-sdlc-platform/.github/workflows/pr-review-backend-java.yml` | Condición `if:` del job |

## ADR relacionados

- [0005 — Gate antes de escribir, exigido uniformemente](../../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md) — Estado: **Propuesta**.

## Ver también

- [../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md](../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md)
- [../3-orquestacion/bucle-de-verificacion-y-reintentos.md](../3-orquestacion/bucle-de-verificacion-y-reintentos.md)
- [../3-orquestacion/contrato-de-entrada-salida.md](../3-orquestacion/contrato-de-entrada-salida.md)
