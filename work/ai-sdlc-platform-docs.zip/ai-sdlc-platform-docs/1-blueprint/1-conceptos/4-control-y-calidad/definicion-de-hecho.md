# Definición de hecho

## En una frase

Es la lista explícita y verificable con herramienta de las condiciones que deben cumplirse para considerar una tarea o fase terminada. Se declara *antes* de implementar y no es el juicio subjetivo del agente sobre si "ya está bien".

## Analogía

Es como una lista de chequeo de despegue de avión. No se decide que el avión "está listo" porque el piloto lo sienta así.

Se decide porque cada ítem de la lista — combustible, flaps, presión de cabina — se comprobó uno por uno, con instrumento, antes de rodar a la pista. Sin la lista, "listo" es solo una impresión.

## Explicación

Un agente con tarea multi-paso decide por sí mismo, en cada ejecución, cuándo algo está "terminado". Sin una lista declarada de antemano, ese criterio queda implícito en su juicio del momento:

- variable entre corridas;
- no auditable después;
- con riesgo real de marcar como completado algo que en verdad no cumple todas las condiciones (el ejemplo típico: tests pasan pero el build está roto).

La definición de hecho (no aplica link oficial — patrón propio del repo) cierra ese hueco. Exige que la lista se declare como parte del plan presentado en el [gate antes de escribir](gate-y-checkpoint-humano.md): antes de que empiece la implementación, no después.

La fase de validación se mide contra esa lista, comprobada con herramienta en el momento (ver [verificación objetiva vs. memoria](verificacion-objetiva-vs-memoria.md)). No se mide contra memoria ni contra la impresión de que "ya funciona".

Si alguna condición no se cumple, la fase entra en modo de fallo "corregir y reintentar". Ese modo está acotado por el [bucle de verificación y reintentos](../3-orquestacion/bucle-de-verificacion-y-reintentos.md).

El bucle necesita precisamente un criterio objetivo — esta lista — contra el que verificar cada intento.

## Cómo lo aplicamos aquí

La mecánica está en [`../../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md`](../../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md).

Se decidió en [`../../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md`](../../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md) — **Estado: Propuesta**.

La exigencia de declarar la lista antes de implementar está decidida en el blueprint. Pero no hay hoy un mecanismo que la fuerce automáticamente en cada agente del repo: depende de que se declare en el gate previo a escribir de cada uno.

El caso de uso concreto es la fase 7 del manual de creación de plugins ([`../../6-manual-creacion-plugin/07-probar.md`](../../6-manual-creacion-plugin/07-probar.md)). Esa fase:

- mide condición por condición contra la definición de hecho declarada en la fase 1, con evidencia al lado;
- exige declarar explícitamente cualquier condición no cumplida, en vez de pasar a la fase de publicación con pendientes ocultos.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Práctica de mecánica | [`../../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md`](../../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md) | Define la lista de condiciones verificables y su punto de declaración (gate previo a escribir) |
| ADR de adopción | [`../../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md`](../../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md) | Decide exigir la lista explícita en vez de juicio subjetivo — Estado: Propuesta |
| Fase 7 del manual | [`../../6-manual-creacion-plugin/07-probar.md`](../../6-manual-creacion-plugin/07-probar.md) | Mide, condición por condición y con herramienta, la definición de hecho declarada en la fase 1 |

## ADR relacionados

- [0015 — Exigir definición de hecho explícita en vez de juicio subjetivo](../../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md) — Estado: **Propuesta**.

## Ver también

- [gate-y-checkpoint-humano.md](gate-y-checkpoint-humano.md)
- [verificacion-objetiva-vs-memoria.md](verificacion-objetiva-vs-memoria.md)
- [../3-orquestacion/bucle-de-verificacion-y-reintentos.md](../3-orquestacion/bucle-de-verificacion-y-reintentos.md)
- [../../6-manual-creacion-plugin/07-probar.md](../../6-manual-creacion-plugin/07-probar.md)
