# Guardrails

## En una frase

Son las reglas de comportamiento riesgoso o ambiguo de un agente/skill, agrupadas siempre en tres niveles fijos — Siempre hacer / Preguntar primero / Nunca hacer — y ubicadas siempre en el mismo lugar del documento, para que un lector no tenga que leerlo entero para encontrarlas.

## Analogía

Es como las etiquetas de seguridad de un electrodoméstico: no están dispersas en el manual de 40 páginas, están todas juntas en una página al principio, con el mismo formato en todos los manuales de la marca — así uno sabe exactamente dónde mirar "qué no debo hacer con esto" sin buscar.

## Explicación

Sin una convención fija, cada autor de skill o agente dispersa sus reglas de comportamiento riesgoso donde le parece natural en el momento. A veces quedan al final, a veces mezcladas dentro de un paso del procedimiento.

Guardrails de tres niveles (no aplica link oficial — patrón propio del repo) resuelve esto con una regla de *ubicación*, no de contenido. La sección va después de cualquier navegación rápida (índice) y antes de cualquier contenido largo, nunca escondida dentro de una subsección.

El contenido de cada nivel tiene su propio requisito:

- **"Siempre hacer"** debe incluir código o pasos ejecutables, no solo intención declarada en prosa.
- **"Nunca hacer"** exige un ejemplo ❌ y uno ✅ lado a lado con la razón. No basta con prohibir algo: hay que mostrar el contraste para que quede claro por qué una forma está mal y la otra está bien.

La prosa, sin embargo, solo es una convención de lectura. No impide que el modelo la ignore a mitad de una tarea larga.

Cuando el enforcement necesita ser duro de verdad, no depende de esta sección, sino del [frontmatter](../2-primitivos-y-activacion/frontmatter.md). Omitir una herramienta de `tools:` hace que la acción prohibida sea estructuralmente imposible, no solo desaconsejada en texto.

## Cómo lo aplicamos aquí

La mecánica de los tres niveles y su ubicación fija están descritas en [`../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md`](../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md).

Se decidió en [`../../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md`](../../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md) — **Estado: Propuesta**.

La convención existe en el blueprint, pero no hay hoy una verificación mecánica de que cada `SKILL.md`/`*.agent.md` del repo la siga. Depende de que cada autor la aplique al escribir.

El complemento duro que sí es estructural — no de prosa — es `frontmatter.md`. Un agente con `tools: Bash` no puede escribir archivos aunque su prompt lo describa, sin importar qué diga ninguna sección de guardrails.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Práctica de mecánica | [`../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md`](../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md) | Define los 3 niveles, su ubicación fija y los requisitos de contenido por nivel |
| ADR de adopción | [`../../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md`](../../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md) | Decide adoptar el patrón de 3 niveles con ubicación fija — Estado: Propuesta |
| Enforcement duro complementario | [`../2-primitivos-y-activacion/frontmatter.md`](../2-primitivos-y-activacion/frontmatter.md) | Explica por qué `tools:` hace cumplir una prohibición estructuralmente, sin depender de prosa |

## ADR relacionados

- [0007 — Guardrails de tres niveles con ubicación fija](../../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md) — Estado: **Propuesta**.

## Ver también

- [../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md](../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md)
- [../2-primitivos-y-activacion/frontmatter.md](../2-primitivos-y-activacion/frontmatter.md)
- [gate-y-checkpoint-humano.md](gate-y-checkpoint-humano.md)
