# Verificación objetiva vs. memoria

## En una frase

Un agente que reporta conteos, métricas o estado de un repositorio debe re-verificarlos con herramientas (`ls`, `wc`, `grep`, `find`) en el momento de reportar. Nunca debe citar el conteo de un informe anterior asumiendo que sigue siendo correcto.

## Analogía

Es como confirmar cuánto dinero hay en una caja contando los billetes ahora mismo, en vez de repetir la cifra que alguien apuntó en un cuaderno la semana pasada.

El cuaderno pudo estar mal desde el principio, o la caja pudo cambiar — y si cada informe siguiente solo copia el anterior, el error se propaga sin que nadie lo note.

## Explicación

Un [LLM](../1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md) puede "recordar" mal una cifra o un estado por la misma razón por la que genera texto de forma probabilística. No tiene una fuente de verdad interna infalible: tiene una tendencia estadística a producir algo plausible.

Citar un informe previo sin comprobarlo es apostar por esa plausibilidad en vez de por un hecho verificado.

El riesgo no es teórico. Hay un caso real documentado en este repo:

- Un informe reportó "26 rules / 10 sin `paths`".
- La cifra real, re-verificada con herramienta, era "24, todas con `paths`".
- El error no vino de una mala lectura inicial. Vino de que un informe posterior citó el conteo del anterior en vez de volver a contar.

La corrección estructural es simple pero exige disciplina. Hay que volver a correr siempre `ls`/`wc`/`grep`/`find` (o el equivalente) en el momento de reportar. Vale incluso cuando ya existe un resumen previo que parece una fuente más rápida y válida.

- **Costo de re-verificar** cuando el informe anterior ya era correcto: bajo, algunas llamadas redundantes.
- **Costo de propagar un dato falso** sin corrección: alto, porque queda como base para decisiones posteriores.

## Cómo lo aplicamos aquí

La mecánica y el caso real están en [`../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md`](../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md).

Se decidió en [`../../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md`](../../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md) — **Estado: Propuesta**.

Es una regla exigida a todo agente que audite o reporte estado de un repo. No hay un mecanismo de plataforma que la fuerce: depende de que el agente la aplique al reportar.

El caso real aplicado en el flujo de revisión de PRs es el tratamiento del `sha`. Ningún paso cita un resultado anterior: cada uno vuelve a preguntar a la fuente.

| Paso | Qué re-verifica |
|---|---|
| `resolve` | Fija el commit analizado |
| `patch --expect-sha` (cada rol) | Falla con `stale_head` si el head ya se movió |
| `publish --expect-sha` | Vuelve a leer el head antes de escribir |
| Marcador `<!-- ai-sdlc-review sha=… -->` | Deja constancia del commit en el propio informe |
| `verify --expect-sha` | Pregunta a GitHub, no al agente, si existe el resumen de ese commit |

La demo aplica lo mismo **fuera del agente**. `05-validate-local.sh` compara:

- el SHA del marcador con el head real;
- el patch analizado con `gh pr diff`;
- el `git status` con el snapshot previo, para comprobar que la revisión no escribió nada en el repositorio revisado.

La fase 7 del manual ([`../../6-manual-creacion-plugin/07-probar.md`](../../6-manual-creacion-plugin/07-probar.md)) aplica el mismo principio. Instala en un consumidor de prueba y verifica lo desplegado con `ls`, en vez de suponer que el install fue correcto porque salió verde.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Práctica de mecánica | [`../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md`](../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md) | Documenta el caso real ("26/10" falso vs. "24/24" real) y la regla de re-verificar con herramienta |
| ADR de adopción | [`../../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md`](../../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md) | Decide exigir re-verificación objetiva en vez de citar informes previos — Estado: Propuesta |
| `patch`, `publish`, `verify` | `act-common-github-pr/scripts/gh_pr.py` | Re-leen el head de GitHub en cada paso |
| Marcador con SHA | `act-common-write-report/references/review-summary-template.md` | Constancia del commit analizado en el informe |
| Validación local | `scripts/05-validate-local.sh` de las dos demos: [Claude Code](../../../../out-git/demo-pr-review/README.es.md) y [Antigravity](../../../../out-git/demo-pr-review-agy/README.es.md) (paso 6) | Compara marcador, head, patch y `git status` |
| Fase 7 del manual | [`../../6-manual-creacion-plugin/07-probar.md`](../../6-manual-creacion-plugin/07-probar.md) | Verifica lo desplegado con `ls` en un consumidor de prueba, no de memoria |

## ADR relacionados

- [0014 — Exigir re-verificación objetiva en vez de citar informes previos](../../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md) — Estado: **Propuesta**.

## Ver también

- [../1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md](../1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md)
- [definicion-de-hecho.md](definicion-de-hecho.md)
- [../../6-manual-creacion-plugin/07-probar.md](../../6-manual-creacion-plugin/07-probar.md)
