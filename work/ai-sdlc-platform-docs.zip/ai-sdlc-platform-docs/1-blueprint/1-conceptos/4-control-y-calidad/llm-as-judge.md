# LLM-as-judge

## En una frase

Es usar un modelo para evaluar el output de otro modelo (o de sí mismo en otra corrida) contra criterios declarados de antemano, devolviendo un veredicto con evidencia citada — nunca una impresión de "se ve bien".

## Analogía

Es como un corrector de examen que no puede simplemente escribir "aprobado" — tiene una rúbrica con puntos concretos, y por cada punto tiene que señalar en qué frase del examen se cumple o no. Si el corrector solo pusiera una nota sin señalar dónde, nadie podría auditar si corrigió bien.

## Explicación

El problema de fondo es que un [LLM](../1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md) genera texto libre y [no-determinista](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md).

Pedirle a un humano que lea cada output y decida si "está bien" no escala. Además depende de que alguien se acuerde de revisar cada vez que algo cambia.

LLM-as-judge (no aplica link oficial — patrón propio del repo) reemplaza esa revisión manual por un evaluador dedicado. Ese evaluador:

- ejecuta escenarios de prueba declarados (query de ejemplo + comportamiento esperado + criterios explícitos);
- emite un veredicto cerrado — PASS/PARTIAL/FAIL — acompañado de evidencia citada del output real.

Esto no es una garantía formal de corrección: el evaluador es también un LLM, y puede fallar en juzgar bien casos sutiles. Es una red de seguridad repetible, no una prueba matemática.

Su valor está en que da un mecanismo para detectar que una edición posterior rompió un comportamiento que antes funcionaba, sin depender de que alguien lo note leyendo a ojo.

## Cómo lo aplicamos aquí

El mecanismo está descrito en [`../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md`](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md):

- cada skill de acción declara al menos 3 escenarios;
- un subagente evaluador los ejecuta secuencialmente (nunca en paralelo, para que cada corrida sea independiente);
- el evaluador juzga cada uno contra sus criterios con evidencia citada.

La decisión de adoptarlo está en [`../../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md`](../../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) — **Estado: Propuesta**.

Es decir, está decidido en papel pero sin implementación verificada en el repo hoy.

El ADR ya deja explícito el límite: el evaluador mismo puede fallar en casos sutiles, no es una garantía formal.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Práctica de mecánica | [`../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md`](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md) | Define escenarios + evaluador + veredicto PASS/PARTIAL/FAIL con evidencia citada |
| Fase de prueba del manual | [`../../6-manual-creacion-plugin/07-probar.md`](../../6-manual-creacion-plugin/07-probar.md) | Exige correr los escenarios de cada skill de acción de forma secuencial antes de cerrar la fase |
| ADR de adopción | [`../../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md`](../../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) | Decide adoptar el mecanismo para toda skill de acción — Estado: Propuesta |

## ADR relacionados

- [0009 — Testing de skills con escenarios declarados](../../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) — Estado: **Propuesta**.

## Ver también

- [../1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md](../1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md)
- [../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md)
- [../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md)
