# Contrato de entrada/salida

## En una frase

Es la especificación exacta y fija de qué recibe un agente o skill para trabajar, y qué forma tiene obligatoriamente lo que devuelve.

Sin ese contrato explícito, cada llamante tendría que adivinar qué mandar y cada consumidor tendría que adivinar qué esperar de vuelta.

## Analogía

Es como el formulario de admisión de un laboratorio de análisis clínicos. El laboratorio especifica exactamente:

- Qué muestra necesita: tipo, cantidad, cómo etiquetarla.
- Qué formato tendrá el informe de resultados: qué campos, qué unidades, qué escala de valores.

Da igual qué médico envíe la muestra o qué paciente sea: el laboratorio no necesita saber nada de eso. Solo necesita que la entrada cumpla el formulario, y el médico solo necesita saber que el informe siempre tendrá esos mismos campos.

## Explicación

Un contrato de entrada/salida es lo que le permite a un [subagente](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) o skill ser invocado por múltiples llamantes distintos. Ninguno de ellos necesita conocer los detalles internos del otro.

Es, junto al fan-out paralelo, una de las razones documentadas para usar contexto aparte en vez de una skill inline: "contrato reutilizable — varios llamantes distintos (CI, IDE, otro agente)".

El contrato define dos mitades independientes:

- Qué campos exactos entran, y cuáles son opcionales.
- Qué forma exacta tiene la salida. Esta mitad suele apoyarse en [no-determinismo y conjuntos cerrados](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) para que los valores de campos como severidad o categoría no varíen de ejecución en ejecución.

Que el contrato sea explícito no es automático. Depende de que quien escribe el agente lo declare en su propio prompt, no en el [frontmatter](../2-primitivos-y-activacion/frontmatter.md), que no tiene un campo dedicado a esto.

Un agente sin contrato declarado obliga a cada llamante a inferir, leyendo el prompt entero, qué puede mandarle y qué puede esperar de vuelta. Eso rompe la promesa de reusabilidad entre llamantes distintos.

## Cómo lo aplicamos aquí

`proc-pr-review` es el ejemplo real del concepto. **Entrada** (sección *Input* de su `SKILL.md`):

| Campo | Obligatorio | Valor |
|---|---|---|
| PR | no | URL o número; si falta, se usa el PR abierto de la rama actual |
| Foco | no | `security`, `style` o `tests`; ese rol corre primero y con más profundidad |
| `publish` | no | por defecto `true`; la skill de entrada `review-pr-java` lo fija a `false` salvo petición expresa |

A cada rol se le pasa la referencia al PR y el `sha` analizado, nunca rutas: el rol obtiene el patch por sí mismo (`gh_pr.py patch --expect-sha`).

**Salida** de cada rol (`references/findings-contract.md`):

```yaml
<role_result role="coverage-check">
execution:
  status: full | partial | not_executed
  source: jacoco.xml          # informe, herramienta o "diff"
  reason: motivo              # obligatorio si status != full
findings:
  - severity: blocker | warning | suggestion
    file: src/main/java/.../Class.java
    line: 42                  # opcional
    rule: rule-id
    rule_url: https://…       # opcional
    message: qué pasa y por qué importa
    fix: propuesta concreta   # opcional
</role_result>
```

El bloque va delimitado por `<role_result role="…">`. Así `proc-pr-review` distingue la salida de un rol del resto de la conversación y puede registrar `not_executed` si falta (ver [ADR 0018](../../5-decisiones/1-diseno-de-agentes-y-skills/0018-estructurar-prompts-con-etiquetas-xml.md)).

Solo lo devuelven los roles que evalúan el cambio (`style-check`, `coverage-check`, `security-scan`); `report` y `pr-access` tienen contrato propio.

Un rol no conoce a su llamante, y el contrato vive en `findings-contract.md`, no en el frontmatter del agente. Lo que sí es parte del contrato es lo que **no** se pasa: ni callbacks ni rutas de fichero entre roles.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Entrada | `proc-pr-review/SKILL.md`, sección *Input* y paso 3 | Fija PR, foco, `publish`, y qué recibe cada rol |
| Salida | `proc-pr-review/references/findings-contract.md` | Fija `execution` y la forma exacta del hallazgo |
| Consumo | `act-common-write-report/SKILL.md` | Recibe hallazgos, veredicto y contexto y genera el informe |

## ADR relacionados

- [0006 — Ciclo de vida fijo de fases para agentes multi-paso](../../5-decisiones/2-orquestacion/0006-ciclo-de-vida-fijo.md) — Estado: **Propuesta**.
  - El contrato de `proc-pr-review` (entrada y `findings-contract.md`) ya existe con independencia de este ADR.
  - Lo que sigue en propuesta es formalizar fases nombradas con modo de fallo explícito alrededor de ese contrato.

## Ver también

- [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md)
- [../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md)
- [delegacion-y-jerarquia-de-capas.md](delegacion-y-jerarquia-de-capas.md)
- [bucle-de-verificacion-y-reintentos.md](bucle-de-verificacion-y-reintentos.md)
