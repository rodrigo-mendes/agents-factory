# Bucle de verificación y reintentos

## En una frase

Cuando un agente no puede confirmar de entrada si algo es un problema real, no lo reporta a ciegas ni lo descarta sin más: entra en un bucle acotado de "buscar más evidencia → reevaluar".

Si agota su presupuesto de intentos sin resolverlo, lo reporta igual pero marcado como no confirmado. Nunca lo descarta en silencio ni reintenta sin límite.

## Analogía

Es como un médico que tiene una sospecha diagnóstica pero no suficiente evidencia todavía. No dice "no es nada" sin más pruebas, ni pide pruebas indefinidamente.

Pide un número acotado de pruebas adicionales, las más relevantes para confirmar o descartar esa sospecha concreta. En cuanto tiene evidencia suficiente para decidir, para.

Si agota ese presupuesto de pruebas sin llegar a una conclusión clara, lo anota igual en el informe — pero como "sospecha sin confirmar", nunca lo omite del informe ni sigue pidiendo pruebas sin fin.

## Explicación

Este patrón combina dos ideas:

- Un bucle de verificación: comprobar si algo cumple una condición, y si no, corregir y reintentar.
- Un límite de reintentos configurable que corta ese bucle antes de que se vuelva costoso sin límite.

Es distinto de simplemente "reintentar hasta que funcione". Cada intento fallido cuenta contra el presupuesto, incluso si el resultado fue vacío o no dio información nueva. Al agotar el límite, el resultado se reporta igual: nunca se descarta en silencio ni se escala indefinidamente.

Este patrón depende de que exista una hipótesis concreta que verificar, no una búsqueda abierta. Por eso no vive dentro de la fase de orquestación general.

Normalmente vive dentro de un [subagente](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) o skill especialista (ver [orquestador vs. especialista](orquestador-vs-especialista.md)). Ese especialista ya tiene un candidato de hallazgo y solo necesita confirmarlo o descartarlo.

El resultado final de cada intento del bucle también respeta la idea de [no-determinismo y conjuntos cerrados](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md).

Al agotar el límite sin confirmar, el hallazgo no se reporta con una severidad inventada libremente. Se reporta con un valor fijo y predecible del enum de severidades ya existente.

## Cómo lo aplicamos aquí

Hoy **no hay bucle de reintentos** en la revisión de PRs: ningún rol repite una comprobación que falló. Existen tres controles acotados de otra naturaleza:

| Control | Qué hace | Dónde |
|---|---|---|
| Verificación posterior | `gh_pr.py verify --expect-sha` comprueba tras publicar que existe el resumen del commit analizado y **falla el job** si no (`no_review_comment`). Verifica; no corrige ni reintenta | Último paso del workflow de CI |
| Tope de turnos | El agente de CI corre con `--max-turns 30` | Workflow de CI |
| Tope de bytes | El diff se lee con `--max-bytes` (200 000 por defecto) | `gh_pr.py diff` |

Cuando un dato no existe (por ejemplo, `coverage-check` sin `jacoco.xml`) el rol no reintenta. Devuelve `execution.status: partial` con su motivo y el proceso limita el veredicto.

El patrón completo (verificar → corregir → reintentar con límite configurable) **sigue siendo una propuesta (ADR 0016) sin precedente implementado**.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Verificación y tope de turnos | `ai-sdlc-platform/.github/workflows/pr-review-backend-java.yml` | `verify` al final y `--max-turns 30` |
| `verify` y `diff` | `act-common-github-pr/scripts/gh_pr.py` (`cmd_verify`, `cmd_diff`) | Comprobación posterior y tope de bytes |
| Degradación en vez de reintento | `act-java-check-coverage/SKILL.md` | `partial` con `reason` cuando falta el informe |

## ADR relacionados

- [0016 — Generalizar el límite de reintentos y hacerlo configurable](../../5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md) — Estado: **Propuesta**.
  - El bucle concreto que lo motivó (`java-reviewer`) ya no existe y hoy no hay precedente implementado.
  - La propuesta de generalizarlo como práctica reusable con el límite parametrizado sigue abierta.

## Ver también

- [../../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md](../../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md)
- [../../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md](../../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md)
- [contrato-de-entrada-salida.md](contrato-de-entrada-salida.md)
- [../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md)
