# Fan-out y profundidad de anidamiento

## En una frase

"Fan-out" es un agente que reparte una tarea en varios sub-agentes que trabajan en paralelo sobre partes independientes. "Profundidad de anidamiento" es cuántas capas de sub-agentes-dentro-de-sub-agentes se permite antes de cortar.

Este repo distingue un límite técnico (más permisivo) de un límite de diseño (más estricto, específico para fan-out).

## Analogía

Imagina que un jefe de obra puede subcontratar hasta 3 niveles por debajo suyo (contratista → subcontratista → sub-subcontratista) sin que la ley lo prohíba. Ese es el límite técnico.

Pero la política interna de la empresa añade una regla más estricta: "si pides 3 presupuestos independientes para una partida, ninguno de esos 3 proveedores puede a su vez pedir 3 presupuestos independientes para su parte".

Si lo hicieran, el coste se multiplicaría sin que nadie lo autorizara explícitamente. La ley permite las 3 capas; la política de la empresa corta ese patrón concreto en la primera repetición.

## Explicación

El límite técnico vive en el primitivo [subagente](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md).

Por defecto, un subagente puede spawnear sub-subagentes hasta 3 capas por debajo de la conversación principal, configurable con la variable de entorno `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH`.

Este límite protege contra recursión descontrolada en general, pero no contra un caso concreto. Un agente hace fan-out paralelo a N sub-agentes, y cada uno de esos N decide, por su cuenta, repetir el mismo patrón de fan-out hacia sus propios N sub-agentes.

El límite de 3 capas permite perfectamente ese caso — solo cuenta profundidad, no cuánto se multiplica el trabajo dentro de cada capa.

El fan-out paralelo es uno de los criterios que justifica usar contexto aparte ([subagente](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) o skill con `context: fork`) en vez de una skill inline: "N unidades independientes, sin estado compartido entre ellas".

El límite de diseño que este repo propone — cap de fan-out depth en 1 — no reemplaza el límite técnico de 3 capas.

Lo complementa con una regla más estricta aplicada solo a ese patrón concreto: un agente que hace fan-out nunca permite que sus propios sub-agentes vuelvan a hacer fan-out del mismo tipo.

Se implementa como un guard explícito en el prompt del agente orquestador, no como parámetro de configuración.

## Cómo lo aplicamos aquí

Hoy no hay fan-out, y es una decisión de diseño, no una deuda:

- `proc-pr-review` ejecuta los roles **uno tras otro** en la misma conversación y prohíbe arrancar otro agente para ellos.
- En la revisión de PRs la profundidad real es **1** (skill de entrada → `backend-java`). En la remediación de SARIF es **2**: `remediate-sarif-java` → `backend-java-remediate` → `backend-java-fix`, secuencial, sin fan-out y dentro del límite técnico de 3.
- `backend-java-ci` **omite `Agent`** de `tools`, así que no puede spawnear nada; igual `backend-java-fix`, el nivel más profundo de la remediación.

El cap de fan-out depth = 1 sigue sin caso de aplicación, ahora porque no hace falta: si algún día se paraleliza un rol, ese será el momento de fijar el guard.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Buena práctica | [`../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md`](../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md) | Mecánica del guard explícito de profundidad 1 |

## ADR relacionados

- [0004 — Cap de fan-out depth en 1](../../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md) — Estado: **Propuesta**.

## Ver también

- [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md)
- [../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md](../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md)
- [../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md)
- [delegacion-y-jerarquia-de-capas.md](delegacion-y-jerarquia-de-capas.md)
