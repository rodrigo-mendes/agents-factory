# Delegación y jerarquía de capas

## En una frase

Cuando un sistema tiene varias capas (agente orquestador, skill de conocimiento, skill de acción), la delegación va siempre hacia abajo — hacia la capa más específica — y cada capa tiene, además de lo que sí hace, una lista explícita de lo que **no** debe contener.

## Analogía

Piensa en la cadena de mando de una empresa: un director delega en un jefe de departamento, que delega en un especialista.

El director no debería ponerse a hacer el trabajo técnico del especialista, y el especialista no debería ponerse a decidir la estrategia del director. Cada uno tiene, además de sus funciones, una lista clara de qué decisiones NO le corresponden.

Si el organigrama solo dice "quién hace qué" pero nunca "qué no debe tocar cada puesto", con el tiempo los puestos se mezclan: el especialista empieza a opinar de estrategia y el director empieza a meterse en el detalle técnico.

## Explicación

Esta práctica nombra explícitamente las capas de un sistema de [skills](../../2-primitivos/skills.md) y [subagentes](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md). A cada una le añade una columna de "qué NO debe contener" junto a "qué sí hace".

La columna prohibitiva es la parte que hace la regla verificable. No basta con decir "cada capa tiene su rol": hace falta poder señalar el momento exacto en que una capa violó su límite. Por ejemplo:

- Una skill de acción que empieza a acumular conocimiento de dominio que debería vivir en una skill de conocimiento pasivo.
- Un agente que hardcodea reglas de negocio en su propio prompt en vez de delegarlas.

La regla de dirección es simple de enunciar y fácil de violar en la práctica: cada capa delega hacia abajo, nunca hacia arriba.

Un agente orquestador delega a skills especialistas (ver [orquestador vs. especialista](orquestador-vs-especialista.md)). Una skill de acción no debería, a su vez, intentar reimplementar lo que le corresponde al agente que la invoca.

Esto se conecta directamente con el [contrato de entrada/salida](contrato-de-entrada-salida.md) entre capas: si la delegación fuera bidireccional o ambigua, el contrato entre capas dejaría de ser estable.

Un matiz importante que suele pasarse por alto: que la jerarquía esté bien descrita en prosa no garantiza que esté wireada estructuralmente.

Describir "el agente A delega en el agente B" no sirve de nada si el [frontmatter](../2-primitivos-y-activacion/frontmatter.md) de A no permite delegar: `Agent` en `tools:` (en Antigravity, `invoke_subagent` tras el aprovisionador).

Ningún harness valida que el cuerpo del prompt coincida con `tools:`.

El caso inverso también existe: una skill de entrada que delega **solo** por frontmatter (`context: fork` + `agent:`) funciona en Claude, pero en Antigravity se ejecuta sin el agente y sin avisar.

Por eso la delegación se pide también en el texto ([0023](../../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).

## Cómo lo aplicamos aquí

La jerarquía real sigue la regla de capas del repo, y la comprueba el linter (`ai-sdlc-lint`):

| Capa | Pieza | Regla |
|---|---|---|
| Agente | `backend-java` | Orquesta por rol; no contiene reglas de lenguaje |
| Core skill | `proc-pr-review` | Orden y criterios; sin reglas de stack |
| Skills de capacidad | `act-*` (compartidas y de stack) | Atómicas; las compartidas no se referencian por nombre fijo |
| Conocimiento | `kb-*`, `std-*` | Sin dependencias; declarativo; sin herramientas, modelos ni rutas de harness |

**En la revisión de PRs el único salto de delegación es skill de entrada `review-pr-java` → `backend-java`.** Los roles son skills que `proc-pr-review` ejecuta en el contexto del agente, y el propio proceso prohíbe arrancar otro agente para ellos.

**La remediación de SARIF añade un segundo salto:** `remediate-sarif-java` → `backend-java-remediate` → `backend-java-fix` (profundidad 2). Solo el rol `code-fix` es subagente; el resto de roles son scripts o skills. El proceso (`proc-sarif-remediation`, en la capa core) no cita skills de Java: las referencias de corrección llegan por el agente `-fix`. Ver [sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md).

El matiz sobre prosa y frontmatter sigue vigente, ahora con un caso bien cableado: `backend-java-ci` no tiene `Skill`, así que **declara en `skills:` las siete que necesita**.

Sin esa línea, su cuerpo describiría roles que no podría cargar y nada avisaría. Es además lo único portable: el tool `Skill` no tiene traducción en Antigravity ([subagents.md](../../2-primitivos/subagents.md#delegar-desde-un-agente-agent-y-skill)).

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Reglas de capa | `CLAUDE.md` de la raíz (*Layer rules*) | Dice qué contiene y qué no cada capa |
| Validación | `ai-sdlc-platform/.github/actions/ai-sdlc-lint/` | Comprueba nombres, capas y dependencias |
| Agente de CI | `ai-sdlc-backend-java/.apm/agents/backend-java-ci.agent.md` | Declara en `skills:` lo que no puede cargar por sí mismo |
| Proceso | `proc-pr-review/SKILL.md`, paso 3 | Ejecuta los roles sin arrancar otro agente |
| Skill de entrada | `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` | Pide en el texto la delegación en `backend-java` y se detiene si no puede |

## ADR relacionados

- [0010 — Jerarquía de capas con prohibiciones explícitas](../../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md) — Estado: **Propuesta**.
- [0023 — La delegación se pide en el texto](../../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md) — Estado: **Propuesta**.

## Ver también

- [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md)
- [orquestador-vs-especialista.md](orquestador-vs-especialista.md)
- [contrato-de-entrada-salida.md](contrato-de-entrada-salida.md)
- [../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md)
- [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md)
