# Orquestador vs. especialista

## En una frase

En un sistema de varios agentes o skills, unos deciden **qué hacer y en qué orden** (orquestadores) y otros solo saben **aplicar un procedimiento fijo** sobre lo que les llega (especialistas).

Mezclar ambos roles en el mismo artefacto es lo que vuelve un sistema difícil de mantener.

## Analogía

Es la diferencia entre un jefe de cocina y un cocinero de partida.

- El jefe de cocina no corta verdura ni emplata: decide qué platos salen, en qué orden, y a qué cocinero de partida le pasa cada comanda.
- El cocinero de partida no decide el menú ni el orden de los platos. Solo sabe ejecutar su receta con la materia prima que le entregan, y devuelve el plato terminado.

Si el jefe de cocina empieza a cocinar él mismo, o el cocinero de partida empieza a decidir el menú, la cocina entera pierde la separación que la hace escalable.

## Explicación

Esta distinción es una de las tres formas que puede tomar una [skill](../../2-primitivos/skills.md) según su taxonomía de roles:

- **Orquestadora/coordinadora.** Es la única con lógica de "siguiente paso": decide a quién delega y en qué orden. Normalmente se ejecuta como [subagente](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) o skill con contexto aislado.
- **Especialista (checklist de dominio).** Aplica un conjunto fijo de reglas verificables sobre un input concreto. Nunca decide flujo.
  - Devuelve hallazgos con severidad/categoría de un conjunto cerrado (ver [no-determinismo y conjuntos cerrados](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md)).
- **Conocimiento pasivo.** Nunca se activa solo: otras skills o agentes lo leen por ruta.
  - Por eso su [frontmatter](../2-primitivos-y-activacion/frontmatter.md) normalmente evita cualquier `description` que sugiera [description matching](../2-primitivos-y-activacion/description-matching.md) de activación automática.

Hay dos formas comunes de romper esta separación:

- La más común: un especialista empieza a acumular lógica de "si pasa esto, entonces llama a aquello". Eso ya es trabajo de orquestador colándose donde no debería.
- La segunda: un orquestador empieza a hardcodear reglas de dominio en su propio prompt en vez de delegarlas a una skill especialista. Entonces el conocimiento queda duplicado y sin dueño claro.

## Cómo lo aplicamos aquí

El flujo de revisión de PRs tiene un ejemplo real y limpio de la separación.

`proc-pr-review` dice de sí mismo que no contiene reglas de ningún lenguaje: llegan por las skills asignadas a cada rol, de modo que cambiar de stack es cambiar la tabla de roles del agente, no el proceso.

## Dónde se aplica

| Pieza | Rol | Qué hace |
|---|---|---|
| `backend-java` + `proc-pr-review` | Orquestación | Decide el orden, qué roles son obligatorios, consolida y fija el veredicto. Sin reglas de lenguaje |
| `act-java-check-style`, `act-java-check-coverage`, `act-common-scan-security` | Especialistas | Aplican sus reglas y devuelven `execution` + `findings`; no deciden flujo |
| `act-common-github-pr`, `act-common-write-report` | Capacidades de entrada y de salida | Leer el PR; generar y publicar el informe |
| `kb-java-best-practices` | Conocimiento pasivo | *"It defines no processes and no actions"*: solo lo consultan otras skills |

## ADR relacionados

- [0002 — Taxonomía de tipos de skill](../../5-decisiones/1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md) — Estado: **Aceptada**.
- [0011 — Arquetipos de agente por forma](../../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md) — Estado: **Propuesta**.
  - El enforcement de rol vía `tools:` que describe este ADR está aplicado en `backend-java-ci` (allowlist de solo lectura) y no en `backend-java`, que hereda el pool.
- [0013 — Convenciones de nombre por rol](../../5-decisiones/1-diseno-de-agentes-y-skills/0013-convenciones-de-nombres-por-rol.md) — Estado: **Propuesta**.

## Ver también

- [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md)
- [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md)
- [../../2-primitivos/skills.md](../../2-primitivos/skills.md)
- [../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md](../2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md)
- [delegacion-y-jerarquia-de-capas.md](delegacion-y-jerarquia-de-capas.md)
