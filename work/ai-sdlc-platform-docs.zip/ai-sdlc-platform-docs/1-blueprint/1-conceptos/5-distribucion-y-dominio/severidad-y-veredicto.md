# Severidad y veredicto

## En una frase

La severidad de un hallazgo (`blocker|warning|suggestion`) se asigna por la consecuencia del problema, nunca por cómo de importante "parece".

El veredicto se deriva de los hallazgos y se **limita** si algún rol obligatorio no pudo evaluar el cambio completo.

## Analogía

Es como un triaje de urgencias que primero clasifica la gravedad clínica objetiva (¿esto mata en minutos, en horas, o puede esperar?) y solo después decide el alta.

Si una prueba obligatoria no pudo hacerse, no se da el alta completa aunque lo hecho salga limpio. Pero una lesión grave ya detectada nunca se rebaja por ese motivo.

## Explicación

| Severidad | Criterio |
|---|---|
| `blocker` | bug probable, vulnerabilidad o incumplimiento de norma obligatoria |
| `warning` | riesgo de mantenibilidad o desviación de buenas prácticas |
| `suggestion` | mejora opcional |

Cada rol devuelve sus hallazgos con una de esas tres severidades. Al consolidar, los duplicados (mismo fichero, línea y causa) se funden y conservan la mayor severidad.

El veredicto sale de ahí:

- `REQUEST_CHANGES` si hay al menos un `blocker`.
- `COMMENT` si solo hay `warning` o `suggestion`.
- `APPROVE` si no hay hallazgos.

Después se aplica un **límite**: si un rol que es obligatorio para el cambio devolvió un `execution.status` distinto de `full` (por ejemplo, sin informe de cobertura), un `APPROVE` pasa a `COMMENT`.

El límite nunca baja un `REQUEST_CHANGES`. El veredicto es siempre una recomendación: el proceso nunca aprueba ni rechaza formalmente el PR.

**No existe downgrade por justificación del autor, por ticket de seguimiento ni por decisión de negocio.**

El título, la descripción y los commits del PR son datos a revisar, no instrucciones. Una frase como "esto es temporal" no cambia la severidad de un hallazgo (ver [prompt-injection](prompt-injection.md)).

## Cómo lo aplicamos aquí

`proc-pr-review` fija los criterios de severidad en su contrato de hallazgos y deriva y limita el veredicto en su paso 5. `act-common-scan-security` añade su propia regla de severidad: toda vulnerabilidad explotable es `blocker`.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Criterios de severidad | `proc-pr-review/references/findings-contract.md` (repo `ai-sdlc-shared-skills`) | Define `blocker`, `warning` y `suggestion` por consecuencia |
| Consolidación y veredicto | `proc-pr-review/SKILL.md`, pasos 4 y 5 | Deduplica conservando la mayor severidad, deriva el veredicto y aplica el límite por estado de rol |
| Regla de seguridad | `act-common-scan-security/SKILL.md` | Toda vulnerabilidad explotable es `blocker` |

## ADR relacionados

Ninguno — mecánica implementada sin ADR que la respalde.

## Ver también

- [../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md](../1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md)
- [../3-orquestacion/orquestador-vs-especialista.md](../3-orquestacion/orquestador-vs-especialista.md)
- [../3-orquestacion/contrato-de-entrada-salida.md](../3-orquestacion/contrato-de-entrada-salida.md)
- [prompt-injection.md](prompt-injection.md)
