# MCP (Model Context Protocol)

## En una frase

MCP es un estándar abierto que define cómo un modelo obtiene herramientas y datos de un servidor externo, independiente de qué modelo o qué harness lo consuma.

## Analogía

Es como USB para periféricos: antes de un estándar común, cada fabricante de impresora o teclado tenía su propio conector.

MCP hace lo mismo para herramientas de un modelo. Un servidor MCP expone sus capacidades de una forma que cualquier cliente compatible (Claude Code, otro harness) sabe consumir sin un adaptador a medida.

## Explicación

MCP no es una invención de este repo ni de Anthropic en exclusiva. Es un protocolo abierto documentado en [modelcontextprotocol.io](https://modelcontextprotocol.io).

Un servidor MCP expone herramientas (funciones invocables) y/o recursos (datos) que un agente puede usar. El agente se declara cliente de ese servidor listando qué servidores están disponibles para él.

En la práctica de un agente concreto, MCP suele ser una opción más entre varias, no una obligación. Declarar un servidor MCP no significa que el flujo lo use. Y cada servidor declarado añade superficie de ataque, coste de contexto y una aprobación que Claude Code pide al usuario.

## Cómo lo aplicamos aquí

`ai-sdlc-backend-java/apm.yml` declara dos servidores MCP, `github` y `context7`, y la revisión de PRs **no usa ninguno**:

| MCP | Para qué existe | Por qué no se usa en la revisión |
|---|---|---|
| `github` | Acceso a GitHub | El acceso al PR es solo `gh_pr.py` (el agente lo exige y prohíbe ejecutar `gh` directamente para ello) |
| `context7` | Documentación de librerías en la versión del `pom.xml` | Los sandboxes de la demo no tienen `pom.xml` |

Por eso la demo instala con `--only apm`: sin MCPs no se genera `.mcp.json`, y APM no puede grabar un token en un fichero versionado ni Claude Code pide aprobar servidores. La publicación en GitHub tampoco tiene fallback por MCP: si `gh_pr.py` falla, el proceso devuelve el informe en Markdown.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Declaración de MCPs | `ai-sdlc-backend-java/apm.yml` (bloque `mcp`) | Declara `github` y `context7` |
| Acceso al PR sin MCP | `backend-java.agent.md` (Limits) y `act-common-github-pr/SKILL.md` | Solo `gh_pr.py`; nunca `gh` directo |
| Instalación sin MCPs | [`demo-pr-review/README.es.md`](../../../../out-git/demo-pr-review/README.es.md) y [`demo-pr-review-agy/README.es.md`](../../../../out-git/demo-pr-review-agy/README.es.md), paso 3 | `--only apm` instala solo los paquetes, sin los MCPs del `apm.yml`, en los dos runtimes (`--target claude` y `--target antigravity`) |
| Frontmatter de subagente | [`../../2-primitivos/subagents.md`](../../2-primitivos/subagents.md) | Documenta el campo `mcpServers` que declara qué servidores MCP están disponibles para un subagente |

## ADR relacionados

Ninguno — vocabulario base.

## Ver también

- [../2-primitivos-y-activacion/frontmatter.md](../2-primitivos-y-activacion/frontmatter.md)
- [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md)
- [../3-orquestacion/contrato-de-entrada-salida.md](../3-orquestacion/contrato-de-entrada-salida.md)
