# Knowledge resolution y matchers

## En una frase

Es decidir qué conocimiento interno aplica a cada cambio sin que el modelo lo adivine: o bien lo carga la plataforma por un matcher de ruta, o bien lo enruta un índice que dice cuándo leer cada guía.

## Analogía

Es como un despacho de correos que enruta cada paquete a un departamento. Algunos paquetes van por una regla mecánica (el código postal empieza por X, va al departamento Y). Para el resto hay una tabla que dice qué departamento atiende cada tipo de envío.

En ningún caso el empleado "interpreta" el paquete para decidir.

## Explicación

En este repo hay tres mecanismos, de más a menos automático:

1. **Matcher de plataforma.** La instruction `std-java-coding` declara `applyTo: "**/*.java"`: el harness la carga sola cuando se edita o revisa un fichero Java.
   - En Claude Code es una regla de `.claude/rules/`; en Antigravity, APM la despliega en `.agents/rules/` con `trigger: glob` + `globs`.
   - No hay nada que evaluar a mano ni nada que el modelo pueda olvidar.
2. **Índice con rutas de lectura.** `kb-java-best-practices` es un índice corto.
   - Cada fila de su tabla dice cuándo leer su guía (por ejemplo, *"Read when the PR adds or moves classes or packages"*).
   - La skill de estilo (`act-java-check-style`) nombra qué secciones consulta.
   - El conocimiento largo vive en `references/` y se lee solo cuando hace falta.
3. **Precedencia declarada.** Cuando una sección condensada y su guía completa discrepan, la regla está escrita: *"the full guide prevails"*. Así un conflicto no se resuelve por azar.
   - Un caso ya resuelto con este criterio es la nomenclatura de los `gateway` (el `Adapter` por proveedor es lo canónico; `GatewayImpl` queda como fachada multi-proveedor).

## Cómo lo aplicamos aquí

Para el stack Java, la normativa obligatoria entra por el matcher de `applyTo` y el conocimiento de apoyo entra por el índice, consultado por las skills de estilo y de seguridad. El proceso de revisión no contiene reglas de lenguaje: las recibe por estas dos vías.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Matcher por glob | `std-java-coding.instructions.md` (repo `ai-sdlc-kb-java`), campo `applyTo` | Carga la normativa Java sola al tocar `**/*.java` |
| Índice y precedencia | `kb-java-best-practices/SKILL.md` | Dice cuándo leer cada guía y cuál gana si discrepan |
| Consulta por sección | `act-java-check-style/SKILL.md` | Nombra las secciones del conocimiento que evalúa |

## ADR relacionados

Ninguno — mecánica implementada sin ADR que la respalde.

## Ver también

- [../3-orquestacion/contrato-de-entrada-salida.md](../3-orquestacion/contrato-de-entrada-salida.md)
- [severidad-y-veredicto.md](severidad-y-veredicto.md)
- [../2-primitivos-y-activacion/progressive-disclosure.md](../2-primitivos-y-activacion/progressive-disclosure.md)
