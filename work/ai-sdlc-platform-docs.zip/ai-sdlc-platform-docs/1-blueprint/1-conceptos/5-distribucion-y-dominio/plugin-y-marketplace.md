# Plugin y marketplace

## En una frase

Un plugin es un bundle instalable versionado (skills, agentes, hooks, MCP) descrito por un `plugin.json`. Un marketplace es el catálogo que lista qué plugins existen y dónde encontrarlos, descrito por un `marketplace.json`.

## Analogía

El plugin es la app empaquetada (el `.apk`, el `.dmg`); el marketplace es la tienda de apps que lista qué apps existen, con qué versión, y de dónde descargarlas. La tienda no contiene el código de la app — solo el catálogo que apunta a él.

## Explicación

En este repo, plugin y marketplace son **solo de Claude Code**. Claude Code lee dos formatos fijos: `plugin.json` (manifest de un plugin) y `marketplace.json` (catálogo).

Ninguno se escribe a mano: los produce [APM](apm-gestion-de-paquetes-de-agentes.md) a partir de `apm.yml`, que es la fuente editable.

Antigravity tiene su propio formato de plugin, incompatible con el de Claude, y un único marketplace oficial; no documenta marketplaces de terceros. Por eso allí los paquetes se instalan con `apm install` ([plugins.md](../../2-primitivos/plugins.md)).

La distinción importante es de responsabilidad:

- Un plugin define **cómo se estructura en disco** un bundle de primitivos en un formato que Claude Code sabe instalar.
- No define cómo se descubre, se resuelve como dependencia transitiva, se versiona o se publica frente a un catálogo. Eso es trabajo del gestor de paquetes (APM), no de Claude Code.

El repo agregador (`ai-sdlc-platform`) es un caso particular. No contiene ningún plugin propio: solo declara qué paquetes reales existen (hoy `ai-sdlc-backend-java`) y los cataloga vía el bloque `marketplace:` de su `apm.yml`.

## Cómo lo aplicamos aquí

`apm.yml` declara el bloque `marketplace` con un único plugin, `backend-java`, cuyo `ref` es `claude-plugin`. Es la rama que publica la action `ai-sdlc-publish-plugin` en cada merge a `main` del repo del agente (`apm install` + `apm pack --format claude-plugin`).

El catálogo `.claude-plugin/marketplace.json` apunta a esa rama, que es lo que Claude Code lee para descubrir el plugin.

Hoy el catálogo está declarado dos veces (en `apm.yml` y en `marketplace.json`; ver la mejora #14 de [`../../../2-architecture/mejoras-pendientes.md`](../../../2-architecture/mejoras-pendientes.md)).

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Catálogo | `ai-sdlc-platform/.claude-plugin/marketplace.json` | Lista `backend-java` con `source.ref: claude-plugin` |
| Manifest fuente | `ai-sdlc-platform/apm.yml` (bloque `marketplace:`) | Declara el mismo plugin |
| Publicación | `ai-sdlc-platform/.github/actions/ai-sdlc-publish-plugin/` | Empaqueta y publica en la rama `claude-plugin` |
| Documento canónico | [`../../2-primitivos/plugins.md`](../../2-primitivos/plugins.md) | Qué es un plugin, Claude frente a Antigravity, y por qué `plugin.json` no se escribe a mano |

## ADR relacionados

- [0003 — Repositorio APM agregador sin código propio](../../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md) — Estado: **Aceptada**.
- [0019 — Soporte multi-runtime](../../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md): el marketplace sigue siendo solo de Claude Code.

## Ver también

- [../../2-primitivos/plugins.md](../../2-primitivos/plugins.md)
- [../../2-primitivos/runtime-claude-code.md](../../2-primitivos/runtime-claude-code.md#plugin-y-marketplace)
- [apm-gestion-de-paquetes-de-agentes.md](apm-gestion-de-paquetes-de-agentes.md)
- [../../3-modelo-operativo/distribucion.md](../../3-modelo-operativo/distribucion.md)
