# APM (Agent Package Manager)

## En una frase

APM es un gestor de dependencias de terceros (Microsoft, no Anthropic) que resuelve `apm.yml` en `apm_modules/` y despliega el resultado en cada runtime (`.claude/` para Claude Code, `.agents/` para Antigravity).

Es el mecanismo con el que este repo distribuye e instala `ai-sdlc-backend-java` y sus dependencias.

## Analogía

Es como `npm` para agentes:

- Un `package.json` (aquí `apm.yml`) declara dependencias.
- `npm install` (aquí `apm install`) las resuelve de forma transitiva y las descarga a `node_modules` (aquí `apm_modules/`).
- Un `package-lock.json` (aquí `apm.lock.yaml`) fija exactamente qué versión quedó instalada para que la instalación sea reproducible.

## Explicación

Punto que confunde a cualquier recién llegado: APM **no es un primitivo de Claude Code ni un producto de Anthropic**. Es un proyecto de Microsoft, independiente, que no aparece documentado en `code.claude.com/docs`.

Se documenta aquí porque este repo lo usa como capa de distribución: despliega las primitivas en cada runtime y, solo para Claude Code, produce el `plugin.json` y el `marketplace.json`.

El manifest es `apm.yml`. Declara:

- `dependencies.apm`: qué paquetes consume este repo.
- Opcionalmente, un bloque `marketplace:`: qué paquetes este repo cataloga para que otros los descubran.

`apm install` resuelve esas dependencias de forma transitiva — igual que `npm` o `pip` — y las materializa en `apm_modules/`. Es un árbol análogo a `node_modules`: contenido generado, no versionado a mano.

`apm.lock.yaml` es el lockfile que fija los hashes resueltos.

Un detalle de seguridad de la cadena de suministro: las dependencias se pueden pinear por SHA de commit (`owner/repo#<sha completo>`) en vez de por rama (`owner/repo#main`).

Este repo pinea por SHA — una referencia móvil como `#main` puede cambiar de contenido entre una instalación y la siguiente sin que nadie lo note.

APM es multi-harness: el mismo manifest despliega en varios targets. Este repo usa dos, `claude` y `antigravity`, y **cada paquete** los declara en `targets:`. APM se salta un paquete sin el target activo.

Lo que APM no despliega para Antigravity (agentes) lo cubre un aprovisionador en el `lifecycle post-install` de quien instala ([0021](../../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

## Cómo lo aplicamos aquí

`apm.yml` de `ai-sdlc-platform` declara `dependencies.apm: [myinvestor-core/ai-sdlc-backend-java#main]`. `ai-sdlc-shared-skills` y `ai-sdlc-kb-java` llegan como dependencias transitivas.

`apm.lock.yaml` fija cada una por `resolved_commit`, y `apm audit` es el gate del CI. Todavía **no hay tags** de versión: las dependencias van contra `#main`.

`apm install` despliega el resultado en:

- `.claude/`: agentes, reglas, skills y hooks.
- `.agents/`, con `targets: [claude, antigravity]`: reglas, skills y hooks; los agentes los genera el aprovisionador.

Ningún paquete despliega commands ni prompts ([0020](../../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).

El repo agregador no contiene código propio, solo el manifest y el catálogo.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Manifest | `ai-sdlc-platform/apm.yml` | Declara `dependencies.apm` contra `#main` y el bloque `marketplace:` |
| Lockfile | `apm.lock.yaml` de cada consumidor | Fija cada paquete por `resolved_commit` |
| Documento canónico | [`../../3-modelo-operativo/distribucion.md`](../../3-modelo-operativo/distribucion.md) | Explica la mecánica completa de APM y enlaza la documentación oficial de Microsoft |

## ADR relacionados

- [0003 — Repositorio APM agregador sin código propio](../../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md) — Estado: **Aceptada**.
- [0019 — Soporte multi-runtime](../../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md) — Estado: **Propuesta**.
- [0021 — Aprovisionador post-install para Antigravity](../../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md) — Estado: **Propuesta**.

## Ver también

- [../../3-modelo-operativo/distribucion.md](../../3-modelo-operativo/distribucion.md)
- [plugin-y-marketplace.md](plugin-y-marketplace.md)
- [../2-primitivos-y-activacion/frontmatter.md](../2-primitivos-y-activacion/frontmatter.md)
