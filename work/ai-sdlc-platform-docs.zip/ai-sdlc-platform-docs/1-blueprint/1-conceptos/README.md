# Conceptos

Vocabulario de base para quien lee un ADR o una buena práctica y se topa con `LLM-as-judge`, `token firewall` o `description matching` sin saber qué significan.

Está pensado para alguien que nunca ha creado ni customizado un agente o una skill. No asume que ya conoces Claude Code, APM, ni la jerga del blueprint.

Esta carpeta se lee **antes** del resto del blueprint, no después. En particular, antes de abrir cualquier ADR de [../5-decisiones/](../5-decisiones/) o cualquier práctica de [../4-buenas-practicas/](../4-buenas-practicas/).

Ambas asumen que ya sabes qué es un subagente, qué es un token firewall o qué significa "conjunto cerrado", y no vuelven a explicarlo.

## Regla de no-duplicación

Cuatro carpetas hablan de patrones parecidos desde ángulos distintos. Esta tabla existe para que no se solapen:

| Capa | Responde | No contiene |
|---|---|---|
| `2-primitivos/` | Qué es el primitivo oficial y cómo se implementa | Patrones propios del repo |
| `4-buenas-practicas/` | El **cómo** mecánico del patrón | El por qué de adoptarlo |
| `5-decisiones/` | El **por qué** + alternativas descartadas | La mecánica |
| `1-conceptos/` | **Qué significa el término**, para quien no lo conoce | La mecánica paso a paso (enlaza a la práctica) |

Si buscas la mecánica completa de un patrón, sigue el link "Práctica" de la tabla maestra más abajo. Si buscas por qué este repo decidió adoptarlo (o no), sigue el link "ADR".

## Estructura de carpetas

Los bloques de lectura existen también como subcarpetas, numeradas en el orden en que se leen:

| Carpeta | Bloque |
|---|---|
| [1-fundamentos-del-modelo/](1-fundamentos-del-modelo/) | 1 · Fundamentos del modelo |
| [2-primitivos-y-activacion/](2-primitivos-y-activacion/) | 2 · Primitivos y activación |
| [3-orquestacion/](3-orquestacion/) | 3 · Orquestación |
| [4-control-y-calidad/](4-control-y-calidad/) | 4 · Control y calidad |
| [5-distribucion-y-dominio/](5-distribucion-y-dominio/) | 5 · Distribución y dominio de review |

## Orden de lectura

Los bloques 1 y 2 se leen **antes** de abrir cualquier ADR: sin ellos, los ADR de capas 3 y 4 no se entienden.

Los bloques 3, 4 y 5 se leen en el orden en que aparecen los problemas que resuelven:

1. primero, cómo se organizan los agentes entre sí;
2. luego, cómo se controla su calidad;
3. por último, cómo se distribuyen y dónde aparece el riesgo de dominio.

- **Bloque 1 · Fundamentos del modelo**
  - [llm-y-generacion-probabilistica](1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md)
  - [token-y-coste](1-fundamentos-del-modelo/token-y-coste.md)
  - [ventana-de-contexto](1-fundamentos-del-modelo/ventana-de-contexto.md)
  - [prompt-y-system-prompt](1-fundamentos-del-modelo/prompt-y-system-prompt.md)
  - [no-determinismo-y-conjuntos-cerrados](1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md)
- **Bloque 2 · Primitivos y activación**
  - [harness-de-agente](2-primitivos-y-activacion/harness-de-agente.md)
  - [frontmatter](2-primitivos-y-activacion/frontmatter.md)
  - [description-matching](2-primitivos-y-activacion/description-matching.md)
  - [subagente-y-aislamiento-de-contexto](2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md)
  - [token-firewall](2-primitivos-y-activacion/token-firewall.md)
  - [progressive-disclosure](2-primitivos-y-activacion/progressive-disclosure.md)
- **Bloque 3 · Orquestación**
  - [orquestador-vs-especialista](3-orquestacion/orquestador-vs-especialista.md)
  - [fan-out-y-profundidad-de-anidamiento](3-orquestacion/fan-out-y-profundidad-de-anidamiento.md)
  - [delegacion-y-jerarquia-de-capas](3-orquestacion/delegacion-y-jerarquia-de-capas.md)
  - [contrato-de-entrada-salida](3-orquestacion/contrato-de-entrada-salida.md)
  - [bucle-de-verificacion-y-reintentos](3-orquestacion/bucle-de-verificacion-y-reintentos.md)
- **Bloque 4 · Control y calidad**
  - [llm-as-judge](4-control-y-calidad/llm-as-judge.md)
  - [gate-y-checkpoint-humano](4-control-y-calidad/gate-y-checkpoint-humano.md)
  - [guardrails](4-control-y-calidad/guardrails.md)
  - [definicion-de-hecho](4-control-y-calidad/definicion-de-hecho.md)
  - [verificacion-objetiva-vs-memoria](4-control-y-calidad/verificacion-objetiva-vs-memoria.md)
- **Bloque 5 · Distribución y dominio de review**
  - [apm-gestion-de-paquetes-de-agentes](5-distribucion-y-dominio/apm-gestion-de-paquetes-de-agentes.md)
  - [plugin-y-marketplace](5-distribucion-y-dominio/plugin-y-marketplace.md)
  - [mcp](5-distribucion-y-dominio/mcp.md)
  - [knowledge-resolution-y-matchers](5-distribucion-y-dominio/knowledge-resolution-y-matchers.md)
  - [severidad-y-veredicto](5-distribucion-y-dominio/severidad-y-veredicto.md)
  - [prompt-injection](5-distribucion-y-dominio/prompt-injection.md)

## Tabla maestra

| Concepto | Bloque | ADR | Práctica | Dónde se aplica |
|---|---|---|---|---|
| [llm-y-generacion-probabilistica](1-fundamentos-del-modelo/llm-y-generacion-probabilistica.md) | 1 | — | — | concepto base, sin implementación propia en el repo |
| [token-y-coste](1-fundamentos-del-modelo/token-y-coste.md) | 1 | [0004 (Propuesta)](../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md) | [cap-fanout-depth.md](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md) | skill de entrada `review-pr-java` → `backend-java`, profundidad 1; los roles corren en serie, sin fan-out (sin guard explícito; ADR en Propuesta) |
| [ventana-de-contexto](1-fundamentos-del-modelo/ventana-de-contexto.md) | 1 | [0008 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md) | [limite-de-tamano-y-blueprints.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md) | todo `SKILL.md` del repo se mantiene bajo el umbral de tamaño |
| [prompt-y-system-prompt](1-fundamentos-del-modelo/prompt-y-system-prompt.md) | 1 | — | — | `SKILL.md` y los agentes (`.claude/agents/*.md`, `.agents/agents/*.md`) actúan como system prompt de skill/agente |
| [no-determinismo-y-conjuntos-cerrados](1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) | 1 | [0014 (Propuesta)](../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md), [0009 (Propuesta)](../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) | [testing-de-skills-con-escenarios.md](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md) | `severity` y `execution.status` cerrados + desempate determinista (fichero, línea, causa → mayor severidad) |
| [harness-de-agente](2-primitivos-y-activacion/harness-de-agente.md) | 2 | [0019 (Aceptada)](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md), [0022 (Aceptada)](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md) | [hooks-portables-entre-runtimes.md](../4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md) | Claude Code y Antigravity (`agy`) ejecutan `backend-java` desde el mismo origen APM; ver "Target antigravity" en [modelo-operativo/distribucion.md](../3-modelo-operativo/distribucion.md) |
| [frontmatter](2-primitivos-y-activacion/frontmatter.md) | 2 | [0011 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md), [0012 (Reemplazada)](../5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md), [0020 (Aceptada)](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md) | [arquetipos-de-agente.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md) | `backend-java-ci`: `tools: Read, Grep, Glob, Bash` + `skills:` precargadas; `applyTo` en `std-java-coding` (enforcement estructural, no de prosa) |
| [description-matching](2-primitivos-y-activacion/description-matching.md) | 2 | [0001 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md), [0012 (Reemplazada)](../5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md), [0020 (Aceptada)](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md) | [agente-router.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md) | [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md), entrada agnóstica "agente por `description`"; la `description` de la skill de entrada es el único freno en Antigravity |
| [subagente-y-aislamiento-de-contexto](2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) | 2 | [0010 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md), [0021 (Aceptada)](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md) | [jerarquia-de-capas-responsabilidad.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md) | `backend-java` arranca sin ver el historial del usuario; el patch viaja por ruta derivada del SHA, no por callback |
| [token-firewall](2-primitivos-y-activacion/token-firewall.md) | 2 | — | — | `backend-java` aísla el diff y las reglas de los roles; el diff va a fichero y se lee por rangos (`--max-bytes`) |
| [progressive-disclosure](2-primitivos-y-activacion/progressive-disclosure.md) | 2 | [0008 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md) | [limite-de-tamano-y-blueprints.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md) | `kb-java-best-practices`: índice corto + `references/` leídas solo cuando hace falta |
| [orquestador-vs-especialista](3-orquestacion/orquestador-vs-especialista.md) | 3 | [0002 (Aceptada)](../5-decisiones/1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md), [0011 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md), [0013 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0013-convenciones-de-nombres-por-rol.md) | [tipos-de-skill.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md) | `backend-java` + `proc-pr-review` orquestan; `act-java-check-*` y `act-common-scan-security` son especialistas |
| [fan-out-y-profundidad-de-anidamiento](3-orquestacion/fan-out-y-profundidad-de-anidamiento.md) | 3 | [0004 (Propuesta)](../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md) | [cap-fanout-depth.md](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md) | aún no se aplica (ADR en Propuesta) — solo referenciado en docs de arquitectura |
| [delegacion-y-jerarquia-de-capas](3-orquestacion/delegacion-y-jerarquia-de-capas.md) | 3 | [0010 (Propuesta)](../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md), [0023 (Aceptada)](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md) | [jerarquia-de-capas-responsabilidad.md](../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md), [delegacion-explicita-en-el-texto.md](../4-buenas-practicas/2-orquestacion/delegacion-explicita-en-el-texto.md) | agente → `proc-pr-review` → skills de capacidad → `kb-*`, validado por linter; los roles no son subagentes |
| [contrato-de-entrada-salida](3-orquestacion/contrato-de-entrada-salida.md) | 3 | [0006 (Propuesta)](../5-decisiones/2-orquestacion/0006-ciclo-de-vida-fijo.md) | [ciclo-de-vida-de-fases.md](../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md) | `proc-pr-review`: entrada PR + foco + `publish` / salida `execution` + `findings` (`findings-contract.md`) |
| [bucle-de-verificacion-y-reintentos](3-orquestacion/bucle-de-verificacion-y-reintentos.md) | 3 | [0016 (Propuesta)](../5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md) | [bucle-de-verificacion-y-limite-de-reintentos.md](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md) | `proc-sarif-remediation`: bucle por ítem con `max-attempts` (default 3), revert y continuar; la revisión de PRs sigue sin bucle (degrada) y usa verificación posterior (`verify`) y topes (`--max-turns`, `--max-bytes`) |
| [llm-as-judge](4-control-y-calidad/llm-as-judge.md) | 4 | [0009 (Propuesta)](../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) | [testing-de-skills-con-escenarios.md](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md) | aún no se aplica (ADR en Propuesta) — solo descrito en la buena práctica |
| [gate-y-checkpoint-humano](4-control-y-calidad/gate-y-checkpoint-humano.md) | 4 | [0005 (Propuesta)](../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md) | [gate-antes-de-escribir.md](../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md) | `preflight`, `resolve`, `--expect-sha`, roles obligatorios, `publish=false` + pregunta del informe y `GH_PR_PUBLISH=0` (gates automáticos reales y checkpoint humano parcial); en la remediación de SARIF, gate en pasos (`plan`/`apply`/`publish`), `GIT_CHANGE_PUBLISH=1` y PR draft |
| [guardrails](4-control-y-calidad/guardrails.md) | 4 | [0007 (Propuesta)](../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md), [0022 (Aceptada)](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md) | [guardrails-tres-niveles.md](../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md) | tres niveles aún sin aplicar (0007 en Propuesta); el hook `github-pr-preflight` es un guardrail "Nunca" aplicado por la plataforma en los dos runtimes |
| [definicion-de-hecho](4-control-y-calidad/definicion-de-hecho.md) | 4 | [0015 (Propuesta)](../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md) | [definicion-de-hecho.md](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md) | manual-creacion-plugin, fase 7: mide condición por condición con herramienta |
| [verificacion-objetiva-vs-memoria](4-control-y-calidad/verificacion-objetiva-vs-memoria.md) | 4 | [0014 (Propuesta)](../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md) | [verificar-no-confiar-en-memoria.md](../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md) | `--expect-sha`, `publish` y `verify` re-leen el head de GitHub en cada paso; `05-validate-local.sh` lo comprueba desde fuera |
| [apm-gestion-de-paquetes-de-agentes](5-distribucion-y-dominio/apm-gestion-de-paquetes-de-agentes.md) | 5 | [0003 (Aceptada)](../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md), [0019 (Aceptada)](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md), [0021 (Aceptada)](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md) | — | `apm.yml`: `dependencies.apm` pineadas por SHA completo + bloque `marketplace:`; `targets: [claude, antigravity]` por paquete; `lifecycle post-install` del consumidor |
| [plugin-y-marketplace](5-distribucion-y-dominio/plugin-y-marketplace.md) | 5 | [0003 (Aceptada)](../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md) | — | `.claude-plugin/marketplace.json` generado desde `apm.yml` vía `apm pack` (solo Claude Code; en Antigravity, `apm install`) |
| [mcp](5-distribucion-y-dominio/mcp.md) | 5 | — | — | MCPs `github` y `context7` declarados en `apm.yml` y no usados en la revisión (`--only apm`) |
| [knowledge-resolution-y-matchers](5-distribucion-y-dominio/knowledge-resolution-y-matchers.md) | 5 | — | — | `applyTo: "**/*.java"` en `std-java-coding` + índice `kb-java-best-practices` con regla de precedencia |
| [severidad-y-veredicto](5-distribucion-y-dominio/severidad-y-veredicto.md) | 5 | — | — | `proc-pr-review`: `blocker/warning/suggestion` + veredicto derivado y limitado por el estado de los roles |
| [prompt-injection](5-distribucion-y-dominio/prompt-injection.md) | 5 | — | — | mitigado en prosa y estructura: el contenido del PR y el SARIF son datos, no instrucciones (el SARIF no decide el repo destino); sin prueba que lo verifique |

## Documentado pero no implementado

15 de los 23 ADR de [../5-decisiones/](../5-decisiones/) están en estado **Propuesta**. 0002, 0003 y 0019–0023 están **Aceptada**, y 0012 está **Reemplazada** por 0020.

La tabla recoge las Propuestas cuyo patrón está decidido en papel pero no existe (o existe solo en parte) en el flujo de revisión actual (`backend-java` + `proc-pr-review`). Quedan fuera:
- 0017 y 0018, que no figuran en la tabla maestra;
- 0019–0023, que ya están **Aceptada** (implementadas, ensayadas y en `main`).

Conceptos que caen del lado "Propuesta", con la matización real de cada uno:

| ADR (Propuesta) | Concepto(s) asociados | Estado real en código |
|---|---|---|
| [0001](../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md) | [description-matching](2-primitivos-y-activacion/description-matching.md) | El matching automático de `description` ya ocurre; el agente router explícito para desambiguar no existe |
| [0004](../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md) | [fan-out-y-profundidad-de-anidamiento](3-orquestacion/fan-out-y-profundidad-de-anidamiento.md), [token-y-coste](1-fundamentos-del-modelo/token-y-coste.md) | La revisión de PRs tiene un nivel de delegación (`review-pr-java` → `backend-java`); la remediación de SARIF, dos (`remediate-sarif-java` → `backend-java-remediate` → `backend-java-fix`), secuenciales y sin fan-out. No hay guard explícito, y `backend-java-ci` y `backend-java-fix` omiten `Agent` por estructura |
| [0005](../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md) | [gate-y-checkpoint-humano](4-control-y-calidad/gate-y-checkpoint-humano.md) | Existen gates automáticos (`preflight`, `--expect-sha`) y un checkpoint humano parcial (el informe pregunta si publicar), pero no el plan+aprobación previo a escribir que pide la ADR |
| [0006](../5-decisiones/2-orquestacion/0006-ciclo-de-vida-fijo.md) | [contrato-de-entrada-salida](3-orquestacion/contrato-de-entrada-salida.md) | `proc-pr-review` tiene pasos numerados y `findings-contract.md`; el modo de fallo explícito por fase solo existe parcialmente |
| [0007](../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md) | [guardrails](4-control-y-calidad/guardrails.md) | Sin aplicación real; el patrón de 3 niveles solo está descrito en la buena práctica |
| [0008](../5-decisiones/1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md) | [ventana-de-contexto](1-fundamentos-del-modelo/ventana-de-contexto.md), [progressive-disclosure](2-primitivos-y-activacion/progressive-disclosure.md) | El hábito de mantener `SKILL.md` corto ya se sigue de facto; el umbral de ~500 líneas no está formalizado como regla |
| [0009](../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) | [llm-as-judge](4-control-y-calidad/llm-as-judge.md), [no-determinismo-y-conjuntos-cerrados](1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) | La suite `evals/` de `ai-shared` declara escenarios y graders para `local-review`; ninguna skill de la revisión de PRs Java los tiene |
| [0010](../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md) | [delegacion-y-jerarquia-de-capas](3-orquestacion/delegacion-y-jerarquia-de-capas.md), [subagente-y-aislamiento-de-contexto](2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) | La jerarquía real (agente → `proc-pr-review` → skills → `kb-*`) existe y las reglas de capa están en `CLAUDE.md` y las valida el linter; el ADR como tal sigue en propuesta |
| [0011](../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md) | [frontmatter](2-primitivos-y-activacion/frontmatter.md), [orquestador-vs-especialista](3-orquestacion/orquestador-vs-especialista.md) | El enforcement por `tools:` está aplicado en `backend-java-ci` (allowlist de solo lectura), `backend-java-fix` (implementador acotado, sin `Bash`) y `backend-java-remediate` (sin `Edit`/`Write`), y no en `backend-java`, que hereda el pool |
| [0013](../5-decisiones/1-diseno-de-agentes-y-skills/0013-convenciones-de-nombres-por-rol.md) | [orquestador-vs-especialista](3-orquestacion/orquestador-vs-especialista.md) | Hay una convención por prefijo de rol (`proc-`, `act-`, `kb-`, `std-`) validada por linter; la forma que propone el ADR (orden de palabras) no se ha adoptado tal cual |
| [0014](../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md) | [verificacion-objetiva-vs-memoria](4-control-y-calidad/verificacion-objetiva-vs-memoria.md), [no-determinismo-y-conjuntos-cerrados](1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) | `--expect-sha` y `verify` ya reconcilian en vivo; generalizar la regla a todo agente no está hecho |
| [0015](../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md) | [definicion-de-hecho](4-control-y-calidad/definicion-de-hecho.md) | Aplicado en la fase 7 del manual de creación de plugin; no exigido todavía como regla general para cualquier tarea |
| [0016](../5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md) | [bucle-de-verificacion-y-reintentos](3-orquestacion/bucle-de-verificacion-y-reintentos.md) | El bucle de `java-reviewer` ya no existe; el primer precedente implementado es `proc-sarif-remediation` (default 3, todo intento cuenta, revert y continuar). Generalizarlo como práctica reusable para cualquier agente no está hecho |

## Huecos sin decisión registrada

Estos conceptos describen mecánica real o riesgo real que ya existe en el repo, sin que ningún ADR lo respalde:

- **[knowledge-resolution-y-matchers](5-distribucion-y-dominio/knowledge-resolution-y-matchers.md)** — mecánica implementada (`applyTo` en la instruction Java, índice `kb-java-best-practices` con regla de precedencia), sin ADR que la respalde.
- **[severidad-y-veredicto](5-distribucion-y-dominio/severidad-y-veredicto.md)** — mecánica implementada (rúbrica `blocker/warning/suggestion` y límite del veredicto en `proc-pr-review`), sin ADR que la respalde.
- **[mcp](5-distribucion-y-dominio/mcp.md)** — vocabulario base: `apm.yml` declara MCPs (`github`, `context7`) que la revisión no usa, y el frontmatter de subagente puede declararlos; el repo no ha decidido nada al respecto.
- **[prompt-injection](5-distribucion-y-dominio/prompt-injection.md)** — **mitigado en prosa y estructura, sin ADR ni prueba**: el contenido del PR son datos, no instrucciones; falta un escenario de prueba que lo verifique.

Además, el flujo de publicación ya tiene comportamiento de **idempotencia**, que no tiene nombre ni ficha propia:

- el resumen se actualiza en sitio por su marcador `<!-- ai-sdlc-review sha=… -->`;
- los comentarios inline ya publicados no se repiten si coinciden en fichero, línea y texto exacto.

Queda pendiente: no se le creó archivo de concepto.
