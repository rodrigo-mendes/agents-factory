# No-determinismo y conjuntos cerrados

## En una frase

Un LLM puede dar respuestas distintas ante la misma entrada. Por eso, cuando un campo de salida necesita ser comparable y estable entre ejecuciones, se le restringe a una lista fija de valores posibles en vez de dejarlo en texto libre.

## Analogía

Es como un formulario con casillas para marcar en vez de una casilla en blanco para escribir. Si a mil personas se les pide "describe el problema en tus palabras", cada una lo describe distinto y nadie puede contarlas por categoría.

Si en cambio se les da una lista cerrada de categorías para elegir una, todas las respuestas caen en el mismo vocabulario y se pueden comparar, agrupar y detectar duplicados.

## Explicación

El no-determinismo es consecuencia directa de la naturaleza del [LLM](llm-y-generacion-probabilistica.md). Al generar texto libre, dos ejecuciones con el mismo [prompt](prompt-y-system-prompt.md) pueden producir frases distintas para describir el mismo hecho.

"Problema de rendimiento", "operación lenta" o "ineficiencia" pueden referirse a la misma causa raíz, pero no son la misma cadena de texto. Un sistema que intente comparar o deduplicar findings entre ejecuciones se rompe si depende de comparar texto libre.

La mitigación estructural es forzar un conjunto cerrado. En vez de dejar que el modelo describa el tipo de problema con sus propias palabras, se le da:

- Una lista fija de valores válidos.
- La instrucción explícita de mapear cualquier término fuera de esa lista al valor más cercano dentro de ella, nunca inventar uno nuevo.

Esto no elimina el no-determinismo del modelo, pero acota su efecto. La variabilidad queda confinada a los campos de texto libre (como la descripción), mientras que los campos que se usan para agrupar, comparar o filtrar quedan en un vocabulario estable.

Cuando además el mismo problema puede anclarse a más de una ubicación válida (por ejemplo, una causa raíz que afecta a varios archivos), hace falta una regla de desempate explícita y determinista.

No se debe dejar que el modelo elija libremente cuál usar en cada corrida, porque eso también introduce variabilidad entre ejecuciones aunque el conjunto de valores ya esté cerrado.

## Cómo lo aplicamos aquí

Los conjuntos cerrados reales son `severity` (`blocker|warning|suggestion`) y `execution.status` (`full|partial|not_executed`).

El desempate determinista es la regla de consolidación (*mismo fichero, línea y causa → se conserva la mayor severidad*), y el veredicto **se deriva** de los hallazgos en lugar de dejarlo al criterio del modelo.

Aun así, la demo documenta que con los mismos campos cerrados el modelo puede clasificar la inyección por campo como `warning` y devolver `COMMENT` donde se esperaba `REQUEST_CHANGES`. El conjunto cerrado acota el vocabulario, no el juicio: por eso la demo recomienda ensayar antes de una sesión.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Valores cerrados | `proc-pr-review/references/findings-contract.md` | Fija `severity` y `execution.status` |
| Desempate y veredicto | `proc-pr-review/SKILL.md`, pasos 4 y 5 | Deduplica por (fichero, línea, causa) y deriva el veredicto |
| Variabilidad observada | [`demo-pr-review/README.es.md`](../../../../out-git/demo-pr-review/README.es.md) ("Problemas comunes") y [`demo-pr-review-agy/README.es.md`](../../../../out-git/demo-pr-review-agy/README.es.md) ("Puntos de atención") | Documentan que el resultado del modelo no es determinista; en Antigravity el modelo es otro y el resultado puede diferir del de Claude Code |

## ADR relacionados

- [0014 — Exigir re-verificación objetiva en vez de citar informes previos](../../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md)
- [0009 — Testing de skills con escenarios declarados](../../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md)

## Ver también

- [LLM y generación probabilística](llm-y-generacion-probabilistica.md)
- [Prompt y system prompt](prompt-y-system-prompt.md)
- [Testing de skills con escenarios](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md)
- [Verificar, no confiar en memoria](../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md)
