# Ventana de contexto

## En una frase

La ventana de contexto es la cantidad máxima de texto (medida en [tokens](token-y-coste.md)) que un modelo puede tener "a la vista" en un momento dado — todo lo que no entra ahí, el modelo simplemente no lo ve.

## Analogía

"La mesa de trabajo": todo lo que el asistente usa ahora mismo está encima de una mesa de tamaño limitado, y cuando se llena, lo que hay al fondo (a menudo las instrucciones iniciales) se cae.

## Explicación

Cada interacción con un LLM ocurre dentro de un límite fijo de tokens. El [prompt](prompt-y-system-prompt.md), el [system prompt](prompt-y-system-prompt.md), el historial de la conversación y cualquier documento cargado compiten todos por ese mismo espacio finito.

Cuando el límite se alcanza, el contenido más antiguo puede perderse o truncarse. De ahí que decisiones de diseño como "qué carga una skill" o "qué le entrega un sub-agente a su llamador" no sean detalles menores, sino la diferencia entre que el modelo mantenga o pierda el hilo de la tarea.

Esta es precisamente la distinción de fondo entre una [skill](../../2-primitivos/skills.md) y un [subagente](../../2-primitivos/subagents.md):

- Con una skill, todo el material que se abre para completar la tarea se queda en la misma ventana de contexto del que llamó.
- Con un subagente, ese material vive en su propia ventana aislada y solo el resultado final vuelve a la ventana del llamador.

Por eso la pregunta que decide entre uno y otro es "¿el material de trabajo hace falta después, o solo hace falta el resultado?".

El tamaño de la ventana también es la razón detrás de umbrales concretos, como cuándo un archivo de skill debe dividirse en archivos de soporte cargados on-demand en vez de vivir todo en un único documento que ocupa espacio en cada activación.

## Cómo lo aplicamos aquí

El caso más directo es el límite de tamaño para `SKILL.md`: un umbral concreto (~500 líneas) que señala cuándo el contenido debe extraerse a archivos de soporte, precisamente para que una activación de la skill no ocupe más ventana de contexto de la que la tarea concreta necesita.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Cualquier `SKILL.md` del repo | `.apm/skills/*/SKILL.md` (fuente en `apm_modules/`) | Se mantiene bajo el umbral de tamaño para no consumir ventana de contexto innecesaria en cada activación. |

## ADR relacionados

- [0008 — Límite de tamaño concreto para SKILL.md](../../5-decisiones/1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md)

## Ver también

- [Límite de tamaño y blueprints](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md)
- [Token y coste](token-y-coste.md)
- [Skills](../../2-primitivos/skills.md)
- [Subagents](../../2-primitivos/subagents.md)
