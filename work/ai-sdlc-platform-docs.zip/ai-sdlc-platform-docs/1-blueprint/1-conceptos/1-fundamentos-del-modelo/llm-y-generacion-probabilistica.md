# LLM y generación probabilística

## En una frase

Un LLM (modelo de lenguaje grande) no "sabe" la respuesta: calcula, palabra por palabra, cuál es la más probable dada todo lo que ha leído hasta ese punto.

## Analogía

Es como el autocompletado del teclado del móvil, pero mucho más potente. Cuando escribes "voy a llegar tarde a la...", el teclado sugiere "reunión" porque esa palabra suele seguir a ese contexto en millones de mensajes parecidos.

Un LLM hace lo mismo, pero encadenando esa predicción miles de veces seguidas. Y considera párrafos enteros de contexto, no solo las últimas palabras.

## Explicación

Un LLM (Large Language Model) es un modelo estadístico entrenado sobre enormes cantidades de texto. No contiene una base de datos de hechos ni ejecuta lógica determinista. Dado un fragmento de texto de entrada:

1. Produce una distribución de probabilidad sobre cuál debería ser el siguiente [token](token-y-coste.md).
2. Elige uno y lo añade al texto.
3. Repite el proceso.

Esa naturaleza probabilística es la raíz de por qué el mismo [prompt](prompt-y-system-prompt.md) puede producir respuestas distintas en dos ejecuciones — ver [no-determinismo y conjuntos cerrados](no-determinismo-y-conjuntos-cerrados.md).

Esto tiene una consecuencia práctica directa para quien diseña agentes o skills: no se puede asumir que el modelo "entiende" una instrucción de la misma forma que una persona la leería.

El modelo responde bien cuando el texto de entrada guía fuertemente la distribución de probabilidad hacia la respuesta deseada. Las instrucciones ambiguas, contradictorias o mal estructuradas amplían el espacio de respuestas plausibles y aumentan la variabilidad del resultado.

Todo lo que un LLM "ve" en un momento dado — la instrucción, los documentos cargados, la conversación previa — vive dentro de su [ventana de contexto](ventana-de-contexto.md), que tiene un tamaño finito.

Cuanto más largo y disperso es ese contexto, más difícil es para el modelo mantener coherencia con instrucciones que quedaron lejos en el texto.

## Cómo lo aplicamos aquí

Este concepto es la base teórica sobre la que se apoyan todas las decisiones del blueprint relacionadas con diseño de prompts, skills y agentes.

Pero no tiene una implementación propia en este repo: es vocabulario de fondo, no un mecanismo que el repo configure o active.

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| — | — | No aplica todavía: es concepto de base, sin implementación propia en el repo. |

## ADR relacionados

Ninguno — vocabulario base.

## Ver también

- [Token y coste](token-y-coste.md)
- [Ventana de contexto](ventana-de-contexto.md)
- [Prompt y system prompt](prompt-y-system-prompt.md)
- [No-determinismo y conjuntos cerrados](no-determinismo-y-conjuntos-cerrados.md)
