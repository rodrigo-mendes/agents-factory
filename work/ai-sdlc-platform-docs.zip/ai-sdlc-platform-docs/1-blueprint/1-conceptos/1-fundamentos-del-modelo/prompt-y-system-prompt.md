# Prompt y system prompt

## En una frase

El prompt es lo que se le pide al modelo en un momento dado; el system prompt es la instrucción de fondo, fijada de antemano, que condiciona cómo el modelo responde a todos los prompts que vengan después.

## Analogía

Es como un empleado nuevo:

- El system prompt es el manual de la empresa que le entregan el primer día (tono, límites, qué puede y qué no puede hacer) y que sigue vigente durante todo su turno.
- El prompt es cada petición concreta que un cliente le hace durante ese turno.

El manual no cambia entre un cliente y el siguiente; la petición sí.

## Explicación

Un prompt es cualquier texto de entrada que se le da a un [LLM](llm-y-generacion-probabilistica.md) para obtener una respuesta — puede ser una pregunta suelta, una instrucción, o una tarea compleja con contexto adjunto.

El system prompt es un tipo particular de prompt que se coloca antes de la interacción del usuario. Típicamente define el rol del modelo, sus límites, su tono y las reglas que debe seguir de forma persistente durante toda la sesión, no solo para el primer turno.

Esta distinción es la base de cómo se escriben las skills y los agentes en este repo. El contenido de un `SKILL.md` o de un `*.agent.md` funciona, en la práctica, como un system prompt especializado que se activa cuando corresponde.

Define el rol, las reglas y los límites que el modelo debe respetar mientras esa skill o ese agente está en uso, independientemente de qué pregunta concreta (prompt) traiga el usuario en ese momento.

Ambos, prompt y system prompt, compiten por el mismo espacio finito dentro de la [ventana de contexto](ventana-de-contexto.md), y ambos se miden y se cobran en [tokens](token-y-coste.md).

Un system prompt mal escrito (ambiguo, contradictorio, o que delega demasiado criterio al modelo sin darle una regla concreta) es una causa directa del tipo de variabilidad de respuesta que se discute en [no-determinismo y conjuntos cerrados](no-determinismo-y-conjuntos-cerrados.md).

## Cómo lo aplicamos aquí

Todo `SKILL.md` y todo `*.agent.md` de este repo funciona como el system prompt de esa skill o agente: fija el rol, las reglas y los límites de forma persistente para cada activación.

El contenido detallado va en archivos de soporte cuando el `SKILL.md` principal excede el umbral de tamaño — ver [ventana de contexto](ventana-de-contexto.md).

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| Cualquier skill del repo | `.apm/skills/*/SKILL.md` (fuente en `apm_modules/`; instalada en `.claude/skills/` o `.agents/skills/`) | Actúa como system prompt especializado: fija rol y reglas persistentes de la skill. |
| Cualquier agente del repo | `.apm/agents/*.agent.md` (fuente); `.claude/agents/*.md` o `.agents/agents/*.md` (instalado) | Actúa como system prompt del agente: define su rol, límites y formato de salida. |

## ADR relacionados

Ninguno — vocabulario base.

## Ver también

- [LLM y generación probabilística](llm-y-generacion-probabilistica.md)
- [Ventana de contexto](ventana-de-contexto.md)
- [No-determinismo y conjuntos cerrados](no-determinismo-y-conjuntos-cerrados.md)
- [Skills](../../2-primitivos/skills.md)
- [Subagents](../../2-primitivos/subagents.md)
