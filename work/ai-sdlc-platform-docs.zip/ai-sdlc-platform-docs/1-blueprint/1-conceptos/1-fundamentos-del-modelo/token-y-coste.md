# Token y coste

## En una frase

Un token es el fragmento de texto (a veces una palabra, a veces parte de una) que el modelo procesa y cobra como unidad. Cuanto más texto entra y sale, más tokens se consumen y más cuesta la ejecución.

## Analogía

Es como pagar un taxi por kilómetro recorrido, no por viaje: no importa si el destino es simple, si el trayecto es largo (mucho contexto, mucha respuesta) el contador sigue subiendo.

Un prompt corto con una respuesta corta es un trayecto barato; cargar 30 documentos para responder una pregunta es un rodeo caro aunque la respuesta final sea una frase.

## Explicación

Los proveedores de LLM no cobran por "pregunta", cobran por token. Los tokens son las unidades de texto en las que se descompone:

- Lo que se envía al modelo: el [prompt](prompt-y-system-prompt.md), el [system prompt](prompt-y-system-prompt.md), el historial de conversación, cualquier archivo cargado.
- Lo que el modelo genera de vuelta.

Un token no es exactamente una palabra: puede ser una palabra completa, una sílaba o un signo de puntuación. Pero para razonar sobre coste basta con pensar "más texto procesado = más tokens = más coste y más tiempo de respuesta".

Esto conecta directamente con la [ventana de contexto](ventana-de-contexto.md): todo lo que ocupa esa ventana en un momento dado son tokens que ya se pagaron o se están pagando por mantener.

Y conecta con el diseño de arquitecturas multi-agente. Si un agente orquestador delega en varios sub-agentes en paralelo (fan-out), cada uno de esos sub-agentes vuelve a pagar tokens por su propio contexto.

El coste no crece linealmente, crece con el número de ramas y la profundidad de la delegación.

Ese es exactamente el riesgo que este repo decidió acotar de forma explícita, no dejarlo a que cada prompt lo gestione por su cuenta.

## Cómo lo aplicamos aquí

El caso concreto es el cap de fan-out en profundidad 1. Un patrón de fan-out paralelo (un orquestador que reparte trabajo entre varios sub-agentes) nunca puede repetirse dentro de sí mismo, aunque el límite técnico general de anidamiento sea mayor.

Sin ese guard, N sub-agentes que a su vez hacen fan-out a N cada uno multiplican el coste en tokens de forma combinatoria (N×N×N...) en lugar de lineal.

Hoy el flujo de revisión no hace fan-out: `proc-pr-review` ejecuta los roles uno tras otro, así que el guard no tiene caso de aplicación. El coste lo acotan, en cambio:

- El contexto aislado de `backend-java`.
- El tope de bytes del diff (`--max-bytes`).
- El tope de turnos del agente de CI (`--max-turns 30`).

## Dónde se aplica

| Artefacto | Archivo | Qué hace con este concepto |
|---|---|---|
| `backend-java` (agente) | `ai-sdlc-backend-java/.apm/agents/backend-java.agent.md` | Aísla el diff y las reglas de los roles en su propio contexto; los roles corren en serie, sin fan-out. |
| Topes de coste | `gh_pr.py diff --max-bytes` y workflow de CI (`--max-turns 30`) | Acotan lo que se lee y las vueltas del agente de CI. |

## ADR relacionados

- [0004 — Cap de fan-out depth en 1](../../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md)

## Ver también

- [Ventana de contexto](ventana-de-contexto.md)
- [LLM y generación probabilística](llm-y-generacion-probabilistica.md)
- [Cap de fan-out depth = 1](../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md)
