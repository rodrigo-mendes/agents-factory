# 0005 — Gate antes de escribir, exigido uniformemente

## Estado

Propuesta.

## Contexto

Un subagente no puede pedir confirmación humana a mitad de tarea (ver [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md) — "Cuándo NO usar"). Eso resuelve el caso de tareas cortas, pero no dice nada sobre cómo un agente con capacidad de escritura y decisiones de diseño no triviales debe comportarse — sin una convención explícita, cada agente decide por su cuenta si presenta un plan antes de escribir o escribe directo, y el resultado es inconsistente entre agentes del mismo proyecto.

## Decisión

Exigir el gate antes de escribir (no aplica link oficial — patrón propio del repo) (mecánica en [../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md](../../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md)) de forma uniforme para todo agente con capacidad de escritura y decisiones de diseño no triviales — no como buena intención sino como regla dura repetida en cada agente que aplica.

## Consecuencias

- **Positivas**: el usuario nunca se encuentra con cambios de diseño ya escritos que no pidió; el punto de revisión es predecible (siempre antes de escribir, no a mitad).
- **Negativas / trade-off**: agrega un paso y una espera incluso cuando el plan es obvio o de bajo riesgo; exige que quien escribe el prompt del agente recuerde incluir la regla explícitamente — no hay enforcement de plataforma que lo obligue por sí solo.

## Alternativas descartadas

- **Dejarlo a criterio de cada agente/prompt individual**: descartado por la inconsistencia observada — algunos agentes preguntan, otros escriben directo, sin razón visible para la diferencia.
- **Confirmación genérica de "¿seguro?" sin mostrar el plan concreto**: descartado, no da al usuario información real para decidir — aprobar a ciegas no es un checkpoint útil.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Gate y checkpoint humano](../../1-conceptos/4-control-y-calidad/gate-y-checkpoint-humano.md) — distingue este checkpoint humano real de las puertas automáticas que un script verifica solo.

## Actualización (2026-11-03)

La regla dura sigue vigente. Se amplía la excepción "En CI…" (ejecución sin humano) a la **ejecución autónoma** de un proceso que escribe código, el primer caso es la remediación de hallazgos SARIF ([../../../2-architecture/sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md)). Condiciones, todas obligatorias:

- **Escritura solo en un worktree aislado fuera del proyecto del consumidor.** Nunca se escribe en el checkout del usuario ni en la rama base.
- **Publicación opt-in con dos llaves**: `publish=true` **y** la variable de entorno `GIT_CHANGE_PUBLISH=1`. Sin ambas, los commits quedan en el worktree y se devuelve el informe. El interruptor está invertido respecto a `GH_PR_PUBLISH`: sin la variable, no se publica, porque un push escribe código y no comentarios.
- **PR siempre en borrador (draft)**, fijado en el script (`deliver_change.py pr-create` no tiene flag para cambiarlo), no en la prosa.
- **Verificación posterior a la ejecución**: `deliver_change.py verify` contrasta `run.json` con `git log base..HEAD` y con HEAD antes de publicar; si hay divergencia, no se publica (`state_mismatch`).
- **"Preguntar primero" en modo autónomo = fallo con código de error** (`missing_repo`, `ambiguous_repo`, `baseline_failed`…), con una pista de cómo corregirlo. No se queda esperando respuesta.

**Flujo interactivo en pasos.** Un subagente no puede pedir confirmación a mitad de la ejecución (ver Contexto), así que el gate se coloca **entre invocaciones**, con el estado persistido en `run.json`: (1) *plan*: tabla de ítems y acción prevista, sin escribir nada; (2) *apply*: escribe solo en el worktree aislado y devuelve el informe preguntando "¿publicar?"; (3) *publish*: verifica el estado contra git, hace push y crea la PR draft. Cada paso termina y devuelve el control al usuario.

Relacionado: [../../../2-architecture/mejoras-pendientes.md](../../../2-architecture/mejoras-pendientes.md) (ítem #9). La decisión sigue en estado **Propuesta**.
