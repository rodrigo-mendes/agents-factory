# 0015 — Exigir definición de hecho explícita en vez de juicio subjetivo

## Estado

Propuesta.

## Contexto

Un agente con tarea multi-paso decide por sí mismo cuándo una fase está "terminada". Sin una lista de condiciones declarada de antemano, ese criterio queda implícito en el juicio del agente en el momento — variable entre ejecuciones, no auditable, y con riesgo de marcar como completado algo que no cumple todas las condiciones reales (tests pasan pero build roto, por ejemplo). El ciclo de vida de fases (ver [../../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md](../../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md)) ya exige una fase de validación explícita, pero no fija contra qué se valida.

## Decisión

Exigir que, antes de la fase de implementación, se declare una lista explícita y verificable con herramienta de las condiciones de "hecho" (no aplica link oficial — patrón propio del repo) — como parte del plan presentado en el gate previo a escribir. La fase de validación se mide contra esa lista, no contra la impresión del agente.

## Consecuencias

- **Positivas**: criterio de salida auditable y reproducible; reduce falsos "completado"; se integra directamente con el bucle de verificación y límite de reintentos (ver [../../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md](../../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md)), que necesita un criterio objetivo contra el que verificar cada intento.
- **Negativas / trade-off**: agrega un paso de declaración explícita antes de implementar, que en tareas simples puede sentirse como ceremonia.

## Alternativas descartadas

- **Juicio subjetivo del agente sobre cuándo terminar**: descartado por el riesgo de falsos "completado" y por la falta de auditabilidad — sin lista declarada, no hay forma de comprobar después contra qué se validó.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Definición de hecho](../../1-conceptos/4-control-y-calidad/definicion-de-hecho.md) — la lista explícita y verificable con herramienta que esta decisión exige declarar antes de implementar.
