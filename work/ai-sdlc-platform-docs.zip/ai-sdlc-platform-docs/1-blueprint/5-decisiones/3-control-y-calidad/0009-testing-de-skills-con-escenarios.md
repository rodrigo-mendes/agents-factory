# 0009 — Testing de skills con escenarios declarados

## Estado

Propuesta.

## Contexto

No existe en este blueprint ninguna convención de cómo validar que una [skill](../../2-primitivos/skills.md) funciona antes de considerarla lista, ni cómo detectar que una edición posterior rompió un comportamiento que antes era correcto. La única validación disponible hoy es la revisión manual de quien escribe o edita la skill, sin ningún registro repetible de qué se probó.

## Decisión

Adoptar el mecanismo de escenarios declarados + evaluador LLM-as-judge (no aplica link oficial — patrón propio del repo) (mecánica en [../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md)) para toda skill de acción.

Cada skill declara sus escenarios en un directorio `scenarios/` junto a su `SKILL.md`, con el [formato de la práctica](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md#formato-de-un-escenario). El nivel de cobertura se deriva de su exposición ([criterio](../../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md#qué-nivel-exige-cada-skill)), no se negocia skill por skill:

- **Bueno** (8-10+ escenarios, con hostiles): skill de entrada que consume contenido de terceros y tiene efectos hacia fuera.
- **Aceptable** (5-6): skill interna que cumple una de las dos condiciones.
- **Mínimo** (3): skill interna que solo analiza u orquesta.
- Las skills pasivas están exentas.

## Consecuencias

- **Positivas**: da un mecanismo repetible para detectar regresiones al editar una skill; obliga a declarar de antemano qué comportamiento se espera, no solo a confiar en que "se ve bien" al leerla.
- **Negativas / trade-off**: escribir escenarios de prueba y ejecutarlos tiene un costo (tiempo de autoría + tokens de ejecución del evaluador) que una skill trivial puede no justificar; el evaluador mismo puede fallar en juzgar correctamente casos sutiles — no es una garantía formal, es una red de seguridad. El nivel Bueno multiplica el costo de autoría, sobre todo por los escenarios hostiles. Además, los escenarios quedan declarados pero **sin ejecutor** hasta que se elija uno (ver [N13](../../../2-architecture/mejoras-pendientes.md#n13-ejecutor-de-escenarios)).

## Alternativas descartadas

- **Confiar en revisión humana ad-hoc**: descartado por no ser repetible ni detectar regresiones automáticamente al editar una skill — depende de que alguien recuerde volver a revisar manualmente cada vez.
- **Un mínimo fijo de 3 escenarios para todas las skills**: descartado porque no distingue una skill que publica en un repositorio ajeno de otra que solo analiza; ambas tendrían la misma exigencia.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [LLM-as-judge](../../1-conceptos/4-control-y-calidad/llm-as-judge.md) — qué es un evaluador automático y por qué su veredicto no es una garantía formal.
- [No determinismo y conjuntos cerrados](../../1-conceptos/1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) — por qué la misma skill puede responder distinto en dos corridas.
