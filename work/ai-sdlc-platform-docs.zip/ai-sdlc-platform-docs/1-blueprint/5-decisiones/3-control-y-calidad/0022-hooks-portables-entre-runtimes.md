# 0022 — Hooks portables: el script detecta el runtime por la forma del evento

## Estado

Aceptada. Implementada en `ai-sdlc-shared-skills/.apm/hooks/scripts/check_prereqs.py`; en `main` desde el 2026-10-28.

## Contexto

El hook de prerrequisitos (`github-pr-preflight`, `PreToolUse`) bloquea dos situaciones: un `apm install` con un token exportado y `gh_pr.py` sin `gh` autenticado. APM lo despliega en los dos runtimes ([0019](../4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)), pero los contratos son distintos:

| | Claude Code | Antigravity (`agy` 1.4.8) |
|---|---|---|
| Comando en el evento | `tool_input.command` | `toolCall.args.CommandLine` |
| Cómo se bloquea | código de salida 2 + motivo en stderr | `{"decision":"deny","reason":…}` en stdout, código 0 |
| Código 2 | bloqueo normal | bloquea, pero lo muestra como "hook failed" |
| Hook que falla | se informa del error | **bloquea todas las herramientas** |

Antes del cambio, el script no encontraba el comando en el evento de Antigravity y dejaba pasar todo sin avisar.

## Decisión

- Los hooks de los paquetes aceptan **los dos formatos de evento**. Detectan el runtime por la forma del evento (`toolCall` presente → Antigravity) y responden en su contrato:
  - Claude: código 2 + stderr;
  - Antigravity: `deny` en stdout + código 0.
- Un error interno del hook nunca bloquea: el script sale con 0.
- Los tests incluyen eventos de los dos runtimes.

## Consecuencias

- **Positivas:**
  - Un solo script de hook.
  - En `agy` el bloqueo aparece limpio: `tool call denied by pre-tool hook: ✖ GITHUB_TOKEN exportada(s)…` (comprobado).
- **Negativas / trade-off:**
  - Cada hook nuevo tiene que implementar los dos contratos y probarse en los dos runtimes.
  - Un hook mal desplegado en Antigravity deja la sesión inutilizable, porque bloquea todas las herramientas. Por eso el aprovisionador corrige las rutas ([0021](../4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

## Alternativas descartadas

- **Un script de hook por runtime**: duplica la lógica de los prerrequisitos.
- **Usar solo el código 2 en los dos**: funciona, pero en `agy` el usuario ve un "hook failed" en lugar del motivo.

## Conceptos

- [Guardrails](../../1-conceptos/4-control-y-calidad/guardrails.md): el hook es un guardrail de nivel "Nunca" aplicado por la plataforma.
- [Harness de agente](../../1-conceptos/2-primitivos-y-activacion/harness-de-agente.md): cada harness define su propio contrato de hooks.
