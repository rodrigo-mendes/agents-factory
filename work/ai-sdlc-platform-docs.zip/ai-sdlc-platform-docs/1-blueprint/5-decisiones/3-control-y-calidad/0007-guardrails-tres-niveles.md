# 0007 — Guardrails de tres niveles con ubicación fija

## Estado

Propuesta.

## Contexto

Sin una convención de dónde y cómo escribir reglas de comportamiento riesgoso, cada autor de skill/agente las dispersa en la prosa donde le parece natural en el momento — a veces al final, a veces mezcladas dentro de una sección de procedimiento. Un lector que necesita saber rápido "¿qué no debo hacer con esto?" tiene que leer el documento completo para encontrarlo.

## Decisión

Adoptar 3 niveles fijos (Siempre/Preguntar primero/Nunca) (no aplica link oficial — patrón propio del repo) con ubicación estructural fija — después de la navegación rápida, antes del contenido largo, nunca dentro de una subsección — mecánica completa en [../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md](../../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md).

## Consecuencias

- **Positivas**: un lector sabe dónde buscar los guardrails sin tener que leer todo el documento; el requisito de ejemplo ❌/✅ obliga a explicitar la razón, no solo la prohibición.
- **Negativas / trade-off**: escribir el ejemplo ❌/✅ con su razón toma más esfuerzo que una prohibición en una línea; para skills muy simples, la ceremonia de 3 niveles puede ser desproporcionada.

## Alternativas descartadas

- **Guardrails dispersos en prosa, sin ubicación fija**: descartado porque dificulta que un lector los encuentre rápido — es exactamente el problema que esta decisión busca resolver.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Guardrails](../../1-conceptos/4-control-y-calidad/guardrails.md) — define los tres niveles (Siempre/Preguntar primero/Nunca) y su ubicación fija que esta decisión adopta.
