# 0014 — Exigir re-verificación objetiva en vez de citar informes previos

## Estado

Propuesta.

## Contexto

Un agente que audita o reporta sobre un repositorio puede tener acceso a un informe anterior sobre el mismo repositorio. Citar ese informe es más rápido que volver a contar con herramientas, pero propaga cualquier error que ya contuviera — sin ninguna corrección hasta que alguien haga la verificación real. Existe un caso documentado donde esto pasó exactamente así (ver [../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md](../../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md)) (no aplica link oficial — patrón propio del repo).

## Decisión

Exigir que todo agente que reporte conteos/métricas/estado de un repo los re-verifique con `ls`/`wc`/`grep`/`find` en el momento, incluso si ya existe un informe anterior disponible.

## Consecuencias

- **Positivas**: elimina la clase de error donde un dato falso se propaga de informe a informe sin que nadie lo note; el costo de re-verificar con herramientas es bajo comparado con el costo de un dato incorrecto usado para tomar una decisión.
- **Negativas / trade-off**: agrega llamadas a herramientas que, si el informe anterior era correcto, resultan redundantes — hay un costo de tokens/tiempo pagado incluso cuando no había error que corregir.

## Alternativas descartadas

- **Confiar en el último informe/resumen disponible**: descartado por el caso real documentado donde ese hábito propagó un dato falso ("26/10" en vez del real "24/24") sin que nadie lo notara hasta una verificación explícita.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [No determinismo y conjuntos cerrados](../../1-conceptos/1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) — por qué un LLM puede "recordar" mal una cifra en vez de tener una fuente de verdad infalible.
- [Verificación objetiva vs. memoria](../../1-conceptos/4-control-y-calidad/verificacion-objetiva-vs-memoria.md) — la regla exacta (re-verificar con herramienta, nunca citar un informe previo) que decide este ADR.
