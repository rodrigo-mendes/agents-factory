# Decisiones (ADRs)

Decisiones de diseño con alternativas descartadas y trade-offs explícitos — no cubiertas por la spec oficial de Claude Code ni de APM (eso vive en [../2-primitivos/](../2-primitivos/)). El "cómo" de la mecánica que cada decisión adopta vive en [../4-buenas-practicas/](../4-buenas-practicas/); aquí solo el "por qué" de adoptarla en este proyecto.

## Convención

Cada archivo `NNNN-titulo-kebab.md`, formato ADR (Nygard):
- **Estado**: Propuesta / Aceptada / Reemplazada
- **Contexto**
- **Decisión**
- **Consecuencias**
- **Alternativas descartadas**
- **Conceptos**: todo ADR enlaza al menos un concepto de [../1-conceptos/](../1-conceptos/)

Al añadir una decisión aquí, crear siempre su práctica pareada en [../4-buenas-practicas/](../4-buenas-practicas/) (y viceversa) — nunca uno sin el otro, salvo las decisiones estructurales del repo que no describen un patrón reusable (0003, 0012, 0019 y 0021, en `4-estructura-del-repo/`).

## Estructura de carpetas

Los ADR se agrupan por tema en subcarpetas numeradas (el número fija el orden). El número `NNNN` del ADR es global y no cambia con la carpeta. Los temas coinciden con los de [../4-buenas-practicas/](../4-buenas-practicas/).

| Carpeta | ADR |
|---|---|
| [1-diseno-de-agentes-y-skills/](1-diseno-de-agentes-y-skills/) | 0001, 0002, 0008, 0010, 0011, 0013, 0018, 0020 |
| [2-orquestacion/](2-orquestacion/) | 0004, 0006, 0016, 0023 |
| [3-control-y-calidad/](3-control-y-calidad/) | 0005, 0007, 0009, 0014, 0015, 0022 |
| [4-estructura-del-repo/](4-estructura-del-repo/) | 0003, 0012, 0017, 0019, 0021 — decisiones estructurales sin práctica pareada |

## Índice

| Nº | Título | Estado | Resumen |
|---|---|---|---|
| 0001 | [Agente router para entrada ambigua](1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md) | Propuesta | Agente router para la entrada agnóstica «agente por `description`» cuando hay varios candidatos plausibles, en cualquier runtime |
| 0002 | [Taxonomía de tipos de skill](1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md) | Aceptada | Formalizar 3 roles de skill (orquestadora/especialista/conocimiento pasivo) como vocabulario compartido del blueprint |
| 0003 | [Repositorio APM agregador sin código propio](4-estructura-del-repo/0003-repositorio-apm-agregador.md) | Aceptada | Usar un repo dedicado (`ai-sdlc-platform`) que solo declara dependencias APM, en vez de monorepo o dependencias directas por consumidor |
| 0004 | [Cap de fan-out depth en 1](2-orquestacion/0004-cap-fanout-depth-uno.md) | Propuesta | Fijar el cap en 1 para patrones de fan-out paralelo, en vez de confiar solo en el límite técnico de 3 capas |
| 0005 | [Gate antes de escribir, exigido uniformemente](3-control-y-calidad/0005-gate-antes-de-escribir.md) | Propuesta | Exigir plan presentado + aprobación explícita antes de escribir, para todo agente con capacidad de escritura |
| 0006 | [Ciclo de vida fijo de fases](2-orquestacion/0006-ciclo-de-vida-fijo.md) | Propuesta | Adoptar fases nombradas con modo de fallo explícito, en vez de prompt libre sin estructura |
| 0007 | [Guardrails de tres niveles con ubicación fija](3-control-y-calidad/0007-guardrails-tres-niveles.md) | Propuesta | 3 niveles (Siempre/Preguntar/Nunca) con ubicación estructural fija en el documento |
| 0008 | [Límite de tamaño concreto para SKILL.md](1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md) | Propuesta | Umbral de ~500 líneas como señal para extraer contenido a archivos de soporte |
| 0009 | [Testing de skills con escenarios declarados](3-control-y-calidad/0009-testing-de-skills-con-escenarios.md) | Propuesta | Escenarios + evaluador LLM-as-judge en vez de solo revisión manual, con cobertura graduada por exposición |
| 0010 | [Jerarquía de capas con prohibiciones explícitas](1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md) | Propuesta | Formalizar qué NO debe contener cada capa, delegación solo hacia abajo |
| 0011 | [Arquetipos de agente con enforcement por `tools:`](1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md) | Propuesta | Forzar el rol "asesor" omitiendo `Write`/`Edit`/`Bash`, no solo con prosa |
| 0012 | [Mantener commands/ como formato separado](4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md) | Reemplazada por 0020 | No fusionar commands y skills en un solo directorio por frontmatter, a diferencia de agents-factory |
| 0013 | [Convenciones de nombre por rol](1-diseno-de-agentes-y-skills/0013-convenciones-de-nombres-por-rol.md) | Propuesta | Nombre según rol del artefacto (conocimiento/acción/regla), no solo kebab-case genérico |
| 0014 | [Verificación objetiva de hechos](3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md) | Propuesta | Re-verificar conteos/estado con herramientas, nunca citar un informe previo sin comprobar |
| 0015 | [Exigir definición de hecho explícita en vez de juicio subjetivo](3-control-y-calidad/0015-definicion-de-hecho.md) | Propuesta | Declarar lista verificable de condiciones de "terminado" antes de implementar, en vez de juicio subjetivo del agente |
| 0016 | [Generalizar el límite de reintentos y hacerlo configurable](2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md) | Propuesta | Generalizar un bucle de reintentos con límite configurable como práctica reusable; primer precedente implementado: `proc-sarif-remediation` (default 3, todo intento cuenta, revertir y continuar) |
| 0017 | [Python como lenguaje único para scripts y hooks](4-estructura-del-repo/0017-python-para-scripts-y-hooks.md) | Propuesta | Escribir todo script y hook nuevo en Python 3 (stdlib, `uv`, `pytest`); migración oportunista de Bash; el tooling Node de `ai-shared` queda fuera |
| 0018 | [Estructurar prompts con etiquetas XML solo donde hay datos no confiables o entregas entre roles](1-diseno-de-agentes-y-skills/0018-estructurar-prompts-con-etiquetas-xml.md) | Propuesta | Etiquetas XML con vocabulario cerrado para datos no confiables y salidas de roles; instrucciones puras sin etiquetas; no son una medida de seguridad |
| 0019 | [Soporte multi-runtime: Claude Code y Antigravity desde un único origen APM](4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md) | Aceptada | Paquetes con `targets: [claude, antigravity]`; primitivas escritas una vez en `.apm/`; marketplace y CI siguen solo en Claude |
| 0020 | [Puntos de entrada como skills: sin commands ni prompts](1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md) | Aceptada | Prohibidos commands y prompts (no todos los harnesses los soportan); todo `/comando` es una skill. Reemplaza a 0012 |
| 0021 | [Aprovisionador post-install para los huecos del target antigravity de APM](4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md) | Aceptada | Script Python en el `lifecycle` del consumidor: genera `.agents/agents/` y corrige las rutas de los hooks. Temporal hasta que APM lo cubra |
| 0022 | [Hooks portables: el script detecta el runtime por la forma del evento](3-control-y-calidad/0022-hooks-portables-entre-runtimes.md) | Aceptada | Un hook acepta los dos formatos de evento y bloquea con el contrato de cada runtime (código 2 en Claude, `deny` en Antigravity) |
| 0023 | [La delegación en subagentes se pide en el texto, no solo en el frontmatter](2-orquestacion/0023-delegacion-explicita-en-el-texto.md) | Aceptada | El skill pide delegar en su agente y se detiene si no puede; `context: fork` + `agent:` solo los entiende Claude |

## Fuera de alcance (evaluados y descartados)

Patrones observados en `agents-factory` (proyecto externo) que no se incorporan a este blueprint:
- **Ledger de paridad multi-runtime mantenido a mano** (`.claude/` vs `.github/`, con tabla de equivalencia y drift documentado). La plataforma ya es multi-runtime ([0019](4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)), pero la paridad no se mantiene a mano: APM despliega cada runtime desde un único origen, y los huecos los cubre el aprovisionador ([0021](4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)). La tabla de equivalencias vive en [../3-modelo-operativo/distribucion.md](../3-modelo-operativo/distribucion.md).
- **Modelo de permisos en `settings.json`** (tiers allow/deny/ask) — es configuración de sesión/seguridad, no un primitivo de plugin/package; fuera del alcance temático de este blueprint.
