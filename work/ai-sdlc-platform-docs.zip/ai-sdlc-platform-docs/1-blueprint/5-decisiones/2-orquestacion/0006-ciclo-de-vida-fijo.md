# 0006 — Ciclo de vida fijo de fases para agentes multi-paso

## Estado

Propuesta.

## Contexto

Sin una estructura de fases nombrada, cada agente multi-paso describe su proceso en prosa libre, a su propio criterio. Cuando una ejecución falla a mitad de camino, no hay forma estándar de saber en qué etapa se detuvo ni qué debía pasar en ese punto — cada agente tiene su propio vocabulario y su propia noción de "qué hacer si esto falla".

## Decisión

Adoptar un ciclo de fases fijo y nombrado (no aplica link oficial — patrón propio del repo) (mecánica en [../../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md](../../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md)) para todo agente con tarea multi-paso no trivial, incluyendo la excepción documentada para agentes puramente asesores.

## Consecuencias

- **Positivas**: cualquier ejecución fallida puede describirse en términos de "falló en la fase X, con modo de fallo Y" — comparable entre agentes distintos; facilita escribir agentes nuevos reusando el mismo esqueleto de fases.
- **Negativas / trade-off**: agrega ceremonia a tareas que en la práctica son más simples que 6 fases distintas; fuerza encajar procesos genuinamente distintos en el mismo molde, lo que puede generar fases vacías o forzadas.

## Alternativas descartadas

- **Prompt libre sin fases nombradas**: descartado, dificulta auditar en qué punto falló una ejecución y por qué — cada agente termina inventando su propia forma de reportar progreso, no comparable entre sí.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Contrato de entrada/salida](../../1-conceptos/3-orquestacion/contrato-de-entrada-salida.md) — la pieza ya implementada (en `java-reviewer`) sobre la que este ADR propone formalizar fases nombradas.

## Actualización (2026-10-15)

El contrato de `java-reviewer` que se cita arriba como pieza ya implementada ya no existe, junto con ese agente. El precedente aproximado actual es `proc-pr-review` (pasos numerados con modo de fallo por paso y `findings-contract.md` como contrato de salida). La decisión sigue en estado **Propuesta**.
