# 0004 — Cap de fan-out depth en 1

## Estado

Propuesta.

## Contexto

El límite técnico de nesting de subagentes (3 capas por defecto, ver [../../2-primitivos/subagents.md](../../2-primitivos/subagents.md)) protege contra recursión descontrolada en general, pero no contra un caso concreto y peligroso: un agente hace [fan-out](../../2-primitivos/subagents.md) paralelo a N sub-agentes, y cada uno de esos N decide, por su cuenta, repetir el mismo patrón de fan-out. El límite de 3 capas permite que eso pase perfectamente — solo cuenta profundidad, no cuánto se multiplica el trabajo en cada capa.

## Decisión

Fijar el cap de fan-out en 1 (no aplica link oficial — patrón propio del repo) para cualquier patrón de fan-out paralelo diseñado deliberadamente (mecánica en [../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md](../../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md)) — vía guard explícito en el prompt del agente orquestador, no solo confiando en el límite técnico global.

## Consecuencias

- **Positivas**: previene explosión combinatoria de sub-agentes paralelos (N×N×N... en vez de N); el costo de una ejecución de fan-out queda acotado y predecible de antemano.
- **Negativas / trade-off**: es responsabilidad de quien escribe el prompt del agente incluir el guard — no hay enforcement estructural (a diferencia del límite técnico de 3 capas, que sí lo impone la plataforma); un agente nuevo que copie el patrón de fan-out sin copiar el guard reintroduce el riesgo.

## Alternativas descartadas

- **Confiar solo en el límite técnico de 3 capas**: descartado, no protege contra la multiplicación de trabajo dentro de esas 3 capas, solo contra profundidad infinita.
- **Fan-out recursivo sin ningún guard**: descartado por riesgo de explosión combinatoria de sub-agentes paralelos y su costo asociado.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Fan-out y profundidad de anidamiento](../../1-conceptos/3-orquestacion/fan-out-y-profundidad-de-anidamiento.md) — distingue el límite técnico de 3 capas del límite de diseño que fija esta decisión.
- [Token y coste](../../1-conceptos/1-fundamentos-del-modelo/token-y-coste.md) — por qué el fan-out repetido multiplica el coste de forma combinatoria, no lineal.
