# 0016 — Generalizar el límite de reintentos y hacerlo configurable

## Estado

Propuesta.

## Contexto

`java-reviewer` ya implementa un bucle de verificación real: reintenta `fetchFile` hasta 5 veces por hipótesis de hallazgo no resuelta antes de reportarla con severidad `advice` (ver `poc/java-reviewer/.apm/agents/java-reviewer.agent.md`). El valor 5 está hardcodeado en prosa, no expuesto como parámetro, y el patrón no está declarado como práctica reusable — cualquier otro agente que necesite un bucle de corrección/reintento tendría que reinventarlo.

## Decisión

Declarar el patrón "verificar → corregir y reintentar, acotado por un límite configurable" (no aplica link oficial — patrón propio del repo) como buena práctica reusable (ver [../../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md](../../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md)), con 5 fallos como valor por defecto y el mismo edge-case de `java-reviewer` (intento fallido/vacío cuenta como uno de los N) como regla general. El límite se declara como parámetro del agente/skill, no como número fijo en prosa.

## Consecuencias

- **Positivas**: evita reinventar el bucle en cada agente nuevo que lo necesite; el límite configurable permite ajustar costo/criticidad por caso de uso sin tocar la lógica del bucle.
- **Negativas / trade-off**: exige que `java-reviewer` (y cualquier futuro consumidor del patrón) exponga el límite como parámetro en vez de dejarlo hardcodeado — trabajo de migración pendiente, fuera del alcance de esta decisión.

## Alternativas descartadas

- **Mantener el límite fijo y no configurable (status quo de `java-reviewer`)**: descartado porque distintos agentes/tareas tienen costos y criticidad distintos por intento; un valor único hardcodeado no sirve para todos los casos.
- **Reintento infinito sin cota**: descartado por riesgo de bucle sin fin ante una hipótesis irresoluble — sin límite, no hay garantía de que el agente termine ni de que reporte el estado no resuelto.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Bucle de verificación y reintentos](../../1-conceptos/3-orquestacion/bucle-de-verificacion-y-reintentos.md) — el patrón concreto ya implementado en `java-reviewer` (5 fetches por hipótesis) que este ADR propone generalizar y parametrizar.

## Actualización (2026-10-15)

El bucle de `fetchFile` ×5 de `java-reviewer` que motiva esta decisión ya no existe, y **no hay hoy un precedente implementado** del patrón: la revisión actual degrada el estado de un rol (`execution.status: partial`) y limita el veredicto en lugar de reintentar. La decisión sigue en estado **Propuesta**; queda por decidir si se mantiene como propuesta de un patrón nuevo o se archiva.

## Actualización (2026-11-03)

La nota anterior ("no hay hoy un precedente implementado") deja de ser cierta: `proc-sarif-remediation` es el **primer precedente implementado** del patrón ([../../../2-architecture/sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md)). Lo que fija:

- **Valor por defecto 3, no 5**, justificado por el coste de cada intento (build + tests de integración + una llamada a agente). Sigue siendo un parámetro (`max-attempts`), no un número escrito en prosa.
- **Todo intento cuenta**: también la aplicación determinista del fix, `no_changes`, el timeout y el agente que movió HEAD.
- **Escalado determinista → agente**: el primer intento usa el fix del SARIF si existe; si no hay fix, o `apply` devuelve `stale_region`, o el build falla, los siguientes intentos pasan por el rol `code-fix`, con el resultado de build anterior en el brief.
- **Agotamiento → revertir y seguir con el siguiente ítem**: el ítem queda `failed` con fase y motivo en el informe; no aborta la ejecución.

La decisión sigue en estado **Propuesta**.
