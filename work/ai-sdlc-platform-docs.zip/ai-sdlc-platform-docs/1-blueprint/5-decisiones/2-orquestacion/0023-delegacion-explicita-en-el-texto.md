# 0023 — La delegación en subagentes se pide en el texto, no solo en el frontmatter

## Estado

Aceptada. Aplicada en `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md`; en `main` desde el 2026-10-28.

## Contexto

Un punto de entrada que tiene que ejecutarse dentro de un agente concreto (aquí `backend-java`, el único que conoce la tabla rol → skill) puede delegar de dos formas:
- **Por frontmatter**: `context: fork` + `agent: backend-java`. Solo lo entiende Claude Code.
- **Por texto**: "delega en el subagente `backend-java`". Lo entiende cualquier runtime con subagentes; en Antigravity se resuelve con `invoke_subagent`.

En la auditoría de los skills y agentes de los paquetes, el envoltorio `pr-review-java` era el único que delegaba **solo** por frontmatter. Su texto decía "ejecuta `proc-pr-review`", sin mencionar al agente. En Antigravity, que ignora esos campos, la revisión se habría ejecutado en el agente principal **sin la tabla de roles**, y sin ningún error visible.

## Decisión

- Un skill que necesita un agente concreto **lo pide en su texto**, además de declarar `context: fork` + `agent:`.
- El texto tiene dos ramas:
  - "si no eres ya `<agente>`, delega en él y espera su informe";
  - "si eres `<agente>`, ejecuta el proceso".
- Incluye una salida explícita: **si no puedes delegar, detente y dilo**, en lugar de ejecutar el proceso sin el agente.

## Consecuencias

- **Positivas:**
  - Mismo comportamiento en los dos runtimes: en Claude el fork entra directamente por la segunda rama; en Antigravity el agente principal delega.
  - **Comprobado en la prueba real:** con el hook roto, el skill no pudo delegar, se detuvo y explicó el motivo, en lugar de publicar una revisión incompleta.
- **Negativas / trade-off:**
  - El texto es algo más largo, y su corrección depende de que el modelo siga la instrucción. No hay un mecanismo de plataforma que lo garantice.

## Alternativas descartadas

- **Solo frontmatter**: no es portable y falla sin avisar.
- **Solo texto, sin `context: fork`**: en Claude perdería el aislamiento de contexto que da el fork.
- **Seleccionar el agente al arrancar (`agy --agent backend-java`)**: obliga a quien usa la herramienta a recordarlo y no sirve para la invocación con `/`.

## Conceptos

- [Delegación y jerarquía de capas](../../1-conceptos/3-orquestacion/delegacion-y-jerarquia-de-capas.md): quién delega en quién.
- [Subagente y aislamiento de contexto](../../1-conceptos/2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md): lo que aporta el fork en Claude y el subagente en Antigravity.
