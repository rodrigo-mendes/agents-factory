# 0021 — Aprovisionador post-install para los huecos del target antigravity de APM

## Estado

Aceptada. Implementada en `ai-sdlc-platform/ci/provision_agents_antigravity.py` (copia en `ai-sdlc-shared-skills`) y ensayada; en `main` desde el 2026-10-28. Es **temporal**: se retira cuando APM cubra estos huecos.

## Contexto

Con `apm install --target antigravity` (APM 0.33.0) quedan dos huecos que impiden que la revisión funcione en `agy`:
1. **No se despliegan agentes.** Sin `.agents/agents/backend-java.md` no hay subagente al que delegar.
2. **Las rutas de los hooks quedan mal.** APM escribe `python3 .agents/hooks/<pkg>/…`, relativo a la raíz del proyecto, pero `agy` ejecuta los hooks desde `.agents/`. La ruta se convierte en `.agents/.agents/…`, el hook falla y `agy` bloquea **todas** las herramientas, `invoke_subagent` incluida. Además, en cada install APM no reconoce como suya la entrada ya corregida y vuelve a añadir la relativa.

Cómo puede ejecutarse algo tras el install:
- APM solo ejecuta los `lifecycle` de la máquina (`/etc/apm/policy.d`), del usuario (`~/.apm/apm.yml`) y del proyecto (`apm.yml`, con `apm lifecycle trust`).
- **Los `lifecycle` de los paquetes dependientes no se ejecutan.**
- El nivel "policy" de APM no es el `apm-policy.yml` de la organización.

## Decisión

Un script Python (cumple [0017](0017-python-para-scripts-y-hooks.md)), `provision_agents_antigravity.py`, que hace dos cosas:

- **Agentes.** Lee `apm_modules/**/.apm/agents/*.agent.md` y escribe `.agents/agents/<name>.md`:
  - traduce `tools` con nombres verificados en `agy` (`Read`→`view_file`, `Bash`→`run_command`…, y `Task`/`Agent`→`invoke_subagent`); un agente sin `tools` recibe todas, delegación incluida;
  - `model` → `inherit`;
  - `skills` → `../skills/<n>`;
  - copia un bloque opcional `antigravity:` (`mainAgent`, `subagent`, `commandExecutionPolicy`), que Claude ignora;
  - lleva un manifiesto, no pisa archivos ajenos, elimina los agentes de paquetes desinstalados y tiene modos `--dry-run`, `--check` y `--clean`.
- **Hooks.** En el contenedor `apm` de `.agents/hooks.json`, reescribe como absolutas las rutas relativas `.agents/…` y elimina las entradas duplicadas. Es idempotente y `--check` lo reporta.

Organización:
- **Fuente única** en `ai-sdlc-platform/ci/`.
- **Copia** en `ai-sdlc-shared-skills/.apm/hooks/scripts/`, para que llegue a `apm_modules/` con el install, porque `ai-sdlc-platform` es un agregador que no se descarga. El CI de shared-skills compara las dos con `cmp`.
- **Disparo:** quien instala declara `lifecycle: post-install / post-update / post-uninstall` en su `apm.yml`, con `uv run --with pyyaml python apm_modules/…/provision_agents_antigravity.py --from-hook`, y ejecuta `apm lifecycle trust`. El script solo actúa si `targets` incluye `antigravity`.

## Consecuencias

- **Positivas:**
  - Los agentes se generan solos con cada install o update (comprobado: el `lifecycle` los creó sin intervención).
  - El hook queda en una sola entrada estable tras reinstalar.
  - Si un agente usa una herramienta sin equivalente verificado, el script falla con error en lugar de generar un agente que se cuelga.
- **Negativas / trade-off:**
  - Cada repo que use Antigravity tiene que declarar el `lifecycle` y confiar en él.
  - Requiere `uv`, porque el script necesita PyYAML y el `python3` del sistema puede no tenerlo.
  - `apm audit` informa de "drift" en `hooks.json`, aunque sale con 0.
  - Hay dos copias del script, que el `cmp` del CI mantiene alineadas; el PR de shared-skills depende de que la plataforma esté mergeada.

## Alternativas descartadas

- **Ejecutarlo a mano tras cada install**: se olvida, y el fallo de los hooks bloquea todo `agy`.
- **Declarar el `lifecycle` en el paquete**: APM no ejecuta los `lifecycle` de los dependientes.
- **Declararlo en la política de la organización**: el nivel "policy" de los `lifecycle` es `/etc/apm/policy.d`, de cada máquina.
- **Solo reportarlo a APM y esperar**: deja Antigravity sin soporte. Se reporta en paralelo y el script se retira cuando APM lo resuelva.

## Conceptos

- [APM: gestión de paquetes de agentes](../../1-conceptos/5-distribucion-y-dominio/apm-gestion-de-paquetes-de-agentes.md): `lifecycle`, targets y `apm_modules/`.
- [Subagente y aislamiento de contexto](../../1-conceptos/2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md): lo que el script genera para Antigravity.
