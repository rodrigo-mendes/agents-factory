# 0012 — Mantener commands/ como formato separado de skills/

## Estado

Reemplazada por [0020](../1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md): APM no despliega `commands/` (prompts) para Antigravity, y en los dos runtimes un skill ya es invocable con `/`. Se conserva como registro histórico.

## Contexto

Un proyecto externo (`agents-factory`) fusiona command-skills (invocación deliberada `/nombre`) y knowledge-skills (activación automática por descripción) en un único directorio `.claude/skills/`, distinguiéndolos únicamente por 4 campos de frontmatter acoplados (`context: fork` + `disable-model-invocation: true` + relacionados) — no tiene `.claude/commands/` en absoluto. Esto plantea la pregunta de si `ai-sdlc-platform` debería adoptar el mismo enfoque y dejar de usar `commands/` como directorio separado.

## Decisión

Mantener [`primitivos/commands.md`](../../2-primitivos/commands.md) y [`primitivos/skills.md`](../../2-primitivos/skills.md) como primitivos documentados por separado, tal como Claude Code los soporta oficialmente — ambos formatos son de primera clase y coexisten (ver `primitivos/commands.md`), sin fusionarlos en un único directorio por convención propia.

## Consecuencias

- **Positivas**: no se necesita mantener coherente el acoplamiento entre múltiples campos de frontmatter (ver patrón #2, ya documentado en `primitivos/skills.md`) para lograr algo que el propio formato `commands/` ya ofrece con menos piezas — un archivo plano, invocación explícita, sin necesidad de ningún campo adicional.
- **Negativas / trade-off**: se mantienen dos ubicaciones posibles para contenido invocable (`commands/` y `skills/`), lo que abre la puerta al antipatrón ya documentado en `primitivos/commands.md` — mismo nombre invocable definido en ambos formatos a la vez.

## Alternativas descartadas

- **Fusionar todo en `skills/`, sin `commands/` separado (el enfoque de agents-factory)**: descartado aquí porque agrega la carga de mantener coherentes varios campos de frontmatter acoplados sin una ganancia clara, dado que Claude Code ya distingue oficialmente ambos primitivos y los mantiene como soportados por separado.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Description matching](../../1-conceptos/2-primitivos-y-activacion/description-matching.md) — el mecanismo de activación automática que distingue una skill de un command de invocación explícita.
- [Frontmatter](../../1-conceptos/2-primitivos-y-activacion/frontmatter.md) — los campos acoplados (`context: fork`, `disable-model-invocation`) que el enfoque descartado necesitaría mantener coherentes.
