# 0019 — Soporte multi-runtime: Claude Code y Antigravity desde un único origen APM

## Estado

Aceptada. Implementada y ensayada de principio a fin; en `main` de `ai-sdlc-platform`, `ai-sdlc-backend-java`, `ai-sdlc-shared-skills` y `ai-sdlc-kb-java` desde el 2026-10-28.

## Contexto

Hasta ahora la plataforma era single-runtime: los paquetes declaraban `targets: [claude]` y todo el blueprint describía solo `.claude/`. Se quiere que la misma revisión de PRs (`/review-pr-java`) funcione también en **Antigravity CLI (`agy`)**, sin mantener dos copias de agentes, skills y reglas.

APM 0.33.0 tiene un target `antigravity` (alias `agy`). Qué despliega en cada runtime, según la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):

| Primitiva | Claude Code (`.claude/`) | Antigravity (`.agents/`) |
|---|---|---|
| `instructions` | ✅ | ✅ `rules/` |
| `prompts` | ❌ (APM lo convierte en command) | ❌ |
| `agents` | ✅ | ❌ |
| `skills` | ✅ | ✅ `skills/` |
| `commands` | ✅ | ❌ |
| `hooks` | ✅ | ✅ `hooks.json` |
| `mcp` | ✅ | ✅ `mcp_config.json` |

No despliega **agentes** ni **prompts** (comandos). Antigravity tiene subagentes propios (`.agents/agents/<n>.md`, delegación con `invoke_subagent`) y trata cada skill como un comando `/<nombre>`.

Lo que se comprobó en la prueba real con `agy` 1.4.8:
- El `targets:` de **cada paquete** importa. APM se salta un paquete cuyo `targets` no incluye el target activo, aunque se pase `--target antigravity`: `Package targets [claude] do not overlap authorized active targets; skipping`.
- `agy` no lee permisos ni variables de entorno del proyecto. Los permisos de comandos solo existen en `~/.gemini/antigravity-cli/settings.json`, que es global.
- En modo headless (`agy -p`), un hook `PreToolUse` puede denegar, pero no puede conceder permisos.

## Decisión

- Los paquetes declaran `targets: [claude, antigravity]`. Las primitivas se escriben **una vez**, en `.apm/`, y APM las despliega en cada runtime.
- Lo que APM no despliega para Antigravity lo cubre un aprovisionador que se ejecuta tras el install ([0021](0021-aprovisionador-post-install-para-antigravity.md)).
- Las primitivas deben funcionar en los dos runtimes sin depender de campos exclusivos de uno:
  - puntos de entrada como skills ([0020](../1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md));
  - delegación pedida en el texto ([0023](../2-orquestacion/0023-delegacion-explicita-en-el-texto.md));
  - hooks que entienden los dos formatos de evento ([0022](../3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)).
- El marketplace y el CI siguen siendo solo de Claude Code. Antigravity tiene plugins propios (`plugin.json` en la raíz, sin `commands/`) y un único marketplace oficial (`antigravity-plugins-official`), y no documenta marketplaces de terceros. Por eso el catálogo `ai-sdlc-platform` no le sirve; en Antigravity los paquetes se consumen con `apm install --target antigravity`.

## Consecuencias

- **Positivas:**
  - un solo origen y un solo `apm install` para dos herramientas;
  - el resultado de la revisión es el mismo en las dos: REQUEST_CHANGES con el blocker por inyección por campo, publicación con el resumen primero y patch idéntico a `gh pr diff`.
- **Negativas / trade-off:**
  - Requiere APM ≥ 0.33.0; el CI sigue en 0.32.0.
  - Cada paquete nuevo tiene que declarar los dos targets; si lo olvida, sus primitivas no llegan a Antigravity y no hay error.
  - En Antigravity las barreras de publicación se montan de otra forma: un hook propio para pedir confirmación, `GH_PR_PUBLISH` exportado en la shell y, en modo headless, una regla global `command(python3)` que afecta a toda la máquina.
  - Antigravity ignora algunos campos de control de Claude (`user-invocable`, `disable-model-invocation`, `context: fork`, `agent:`).
  - Hay que probar cada cambio en los dos runtimes.

## Alternativas descartadas

- **Un repo (o una rama) por runtime**: duplica cada primitiva y garantiza que diverjan.
- **Mantener `.agents/` a mano en el consumidor**: rompe la trazabilidad con el paquete y `apm audit` no la cubre.
- **Esperar a que APM despliegue agentes y prompts para Antigravity**: bloquea el soporte por un tiempo indefinido; el aprovisionador ([0021](0021-aprovisionador-post-install-para-antigravity.md)) es temporal y se retira cuando APM lo cubra.

## Conceptos

- [Harness de agente](../../1-conceptos/2-primitivos-y-activacion/harness-de-agente.md): Claude Code y Antigravity son dos harnesses distintos que leen las mismas primitivas.
- [APM: gestión de paquetes de agentes](../../1-conceptos/5-distribucion-y-dominio/apm-gestion-de-paquetes-de-agentes.md): el target por paquete y el despliegue por runtime.
