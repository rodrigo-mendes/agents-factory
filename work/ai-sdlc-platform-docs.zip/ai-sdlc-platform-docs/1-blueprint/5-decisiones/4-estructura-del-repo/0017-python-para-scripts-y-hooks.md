# 0017 — Python como lenguaje único para scripts y hooks

## Estado

Propuesta.

## Contexto

La automatización del proyecto (scripts de skills, helpers de CI, lint, publicación, hooks) hoy mezcla dos lenguajes:

- **Python**: `lint.py` (en `ai-sdlc-kb-java`, `ai-sdlc-backend-java` y `ai-sdlc-shared-skills`), `ci/publish-plugins.py` y `publish_plugin.py` / `ai_sdlc_lint.py` en `ai-sdlc-platform`, y `gh_pr.py` en `act-common-github-pr`. Todos con tests `pytest` y ejecución vía `uv`.
- **Bash**: `collect-review.sh` (skill `local-review`, ver su ADR local 0001), `demo-pr-review/scripts/*.sh`, los `fixture.sh` de `evals/` y el hook git `.husky/pre-commit`.

Mantener dos lenguajes duplica convenciones de manejo de errores, testing y linting. La lógica no trivial (parseo de JSON, rutas, expresiones regulares, llamadas a `gh`/`git`) es frágil y difícil de testear en Bash, y su comportamiento varía entre BSD (macOS) y GNU (Linux/CI). Además, estos scripts los invoca un agente o el CI: cuanto más uniforme es su forma, más simple es la regla de permisos que los autoriza.

> Motivación inferida del estado del repo; confirmar con el equipo si hubo una razón decisiva distinta (política de la organización, seguridad, etc.).

## Decisión

Todo script y hook nuevo se escribe en **Python 3**: hooks de los runtimes (Claude Code, Antigravity), hooks de git, scripts de skills y helpers de CI.

- Stdlib por defecto; si requiere dependencias, se ejecuta con `uv`.
- Shebang `#!/usr/bin/env python3` y se invoca como `python3 <script> ...`.
- Tests con `pytest` junto al script (`tests/`).
- Los scripts Bash existentes **migran de forma oportunista** (al modificarlos), sin reescritura masiva.
- Excepción acotada: wrappers de una línea que solo delegan en un script Python (p. ej. `.husky/pre-commit` invocando `python3 ...`).
- Fuera de alcance: el tooling Node de `ai-shared` (husky, lint-staged, `node:test`, TS/JS), que sigue su propio stack.

## Consecuencias

- **Positivas**: un único lenguaje y una única forma de testear (`pytest`); comportamiento portable entre macOS, Linux y CI; una regla de permisos uniforme (`Bash(python3 */scripts/*.py *)`, ya en uso para `gh_pr.py`); coherente con el principio de script determinista de `local-review` ADR 0001.
- **Negativas / trade-off**: exige Python 3 en máquinas de desarrollo y CI (versión mínima por fijar); arranque más lento que Bash en scripts triviales; coexistirán Bash y Python hasta completar la migración (`collect-review.sh`, `demo-pr-review/*.sh`, fixtures de `evals/`); `ai-shared` mantiene Node para su tooling, por lo que la regla "un solo lenguaje" no es absoluta.
- **Impacto en otros ADR**: `local-review` ADR 0001 cita `collect-review.sh`; queda como pendiente de migración y no se reescribe ese ADR.

## Alternativas descartadas

- **Bash para todo**: descartado, frágil para lógica compleja, testing débil y diferencias BSD/GNU.
- **Node/TS (como en `ai-shared`)**: descartado, los helpers de CI, lint y publicación ya son Python; adoptarlo obligaría a mantener dos runtimes de scripting.
- **Mixto, a criterio de cada caso (status quo)**: descartado, mantiene dos convenciones y obliga a decidir el lenguaje en cada script.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Harness de agente](../../1-conceptos/2-primitivos-y-activacion/harness-de-agente.md) — el entorno que ejecuta los hooks y scripts y aplica sus reglas de permisos.
- [Token firewall](../../1-conceptos/2-primitivos-y-activacion/token-firewall.md) — por qué un script determinista filtra la salida antes de que llegue al contexto del agente.
