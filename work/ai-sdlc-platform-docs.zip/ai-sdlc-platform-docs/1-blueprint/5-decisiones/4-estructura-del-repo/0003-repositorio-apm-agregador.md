# 0003 — Repositorio APM agregador sin código propio

## Estado

Aceptada — es la forma actual de `ai-sdlc-platform`.

## Contexto

Los primitivos reales (agents, [skills](../../2-primitivos/skills.md)) viven repartidos en repos independientes con ciclo de vida propio (hoy `ai-sdlc-backend-java`, con `ai-sdlc-shared-skills` y `ai-sdlc-kb-java` como dependencias; convención objetivo en [topologia-repos.md](../../3-modelo-operativo/topologia-repos.md)). Un equipo que quiere consumir "el paquete de revisión de PRs" necesitaría, sin un punto central, declarar cada dependencia por separado en su propio APM [ver distribución](../../3-modelo-operativo/distribucion.md) (`apm.yml`) y conocer de antemano cuáles repos existen y cómo se combinan entre sí — ese conocimiento (qué depende de qué, qué versión es compatible) tendría que repetirse en cada consumidor.

## Decisión

Crear un repo dedicado — este mismo, `ai-sdlc-platform` — que **no contiene código ni skills propias**, solo un `apm.yml` con `dependencies.apm` apuntando a los repos reales y un bloque `marketplace` que los cataloga. Mecánica completa (organización de archivos, qué genera `apm pack`) en [distribucion.md](../../3-modelo-operativo/distribucion.md). Un consumidor apunta a un solo repo/marketplace en vez de N packages sueltos.

## Consecuencias

- **Positivas**: punto único de catálogo y descubrimiento; versionar la combinación de packages compatibles entre sí vive en un solo lugar (`apm.yml` del agregador), no repetido en cada consumidor; los packages reales (`ai-sdlc-backend-java` y sus dependencias) mantienen su propio ciclo de vida sin acoplarse al del agregador.
- **Negativas / trade-off**: capa extra de indirección — el agregador debe mantenerse sincronizado manualmente con las versiones/refs de los packages que agrega (nadie actualiza `apm.yml` automáticamente cuando un package cambia); si el agregador queda desactualizado, un consumidor puede instalar versiones viejas sin darse cuenta.

## Alternativas descartadas

- **Monorepo con todos los packages juntos**: descartado, pierde el versionado y ciclo de vida independiente por package (un cambio en `act-java-check-style` forzaría una release conjunta con `backend-java` aunque no estén relacionados).
- **Cada consumidor declara dependencias directas a cada package**: descartado, duplica en cada consumidor el conocimiento de qué packages existen y cómo se combinan — sin punto único de descubrimiento ni catálogo.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [APM (gestión de paquetes de agentes)](../../1-conceptos/5-distribucion-y-dominio/apm-gestion-de-paquetes-de-agentes.md) — el gestor de dependencias cuyo `apm.yml` implementa este repo agregador.
- [Plugin y marketplace](../../1-conceptos/5-distribucion-y-dominio/plugin-y-marketplace.md) — qué genera este repo (`marketplace.json`) a partir de su `apm.yml` para catalogar los packages reales.

## Actualización (2026-10-15)

Los packages que agrega hoy `ai-sdlc-platform` son `ai-sdlc-backend-java`, con `ai-sdlc-shared-skills` y `ai-sdlc-kb-java` como dependencias transitivas. `java-reviewer` y `pr-validator`, citados en el contexto original, ya no existen: fueron sustituidos por `backend-java` y `proc-pr-review`. La decisión (repositorio agregador sin código propio) no cambia; solo se actualizaron los ejemplos de arriba para que describan la forma actual.
