# 0020 — Puntos de entrada como skills: sin commands ni prompts

## Estado

Aceptada. **Reemplaza a [0012](../4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md)**. En `main` de `ai-sdlc-backend-java` desde el 2026-10-28.

## Contexto

[0012](../4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md) decidió mantener `commands/` separado de `skills/`, porque Claude Code soporta los dos formatos. El caso real tenía **dos piezas para un solo punto de entrada**:
- el prompt `ai-sdlc-backend-java/.apm/prompts/review-pr-java.prompt.md`, desplegado como `.claude/commands/review-pr-java.md`;
- el skill envoltorio `pr-review-java` (`context: fork` + `agent: backend-java`), con el mismo texto.

Al añadir Antigravity ([0019](../4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)) aparecieron dos hechos:
- **No todos los harnesses soportan commands ni prompts.** Según la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):
  - `prompts` no se despliega como tal en ningún target; en Claude, APM lo convierte en un command;
  - `commands` solo existe en Claude Code; Antigravity no lo tiene.

  Un punto de entrada escrito así no llega a Antigravity, ni a cualquier otro harness sin commands.
- En los dos runtimes **un skill es invocable con `/<nombre>`** y recibe el texto que sigue en `$ARGUMENTS` (comprobado en `agy` 1.4.8).

## Decisión

- **Prohibido** usar `commands` (`.claude/commands/`) o `prompts` (`.apm/prompts/`) en cualquier paquete, nuevo o existente. No hay excepción "solo para Claude".
- Todo punto de entrada que el usuario invoca con `/` se escribe como **skill**.
- El caso real queda en un único `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md`, que sustituye al prompt y al envoltorio.
- La skill de entrada lleva dos frenos a la activación automática:
  - `disable-model-invocation: true`, que funciona en Claude Code;
  - una `description` que dice "úsalo solo cuando el usuario lo pida", porque Antigravity no tiene equivalente de `disable-model-invocation`.

## Consecuencias

- **Positivas:**
  - una sola pieza por punto de entrada, la misma en los dos runtimes;
  - desaparece el antipatrón de tener el mismo nombre invocable en `commands/` y en `skills/` (el riesgo negativo de 0012);
  - lo que el usuario escribe no cambia: `/review-pr-java <PR> [foco]`.
- **Negativas / trade-off:**
  - En Claude el archivo pasa de `.claude/commands/` a `.claude/skills/review-pr-java/`; los scripts y docs que buscaban el comando se actualizan.
  - En Antigravity se pierde el efecto de `user-invocable: false` y de `disable-model-invocation: true`: ignora los dos campos, y el único freno es la `description`. `disable-slash-command: true` (no documentado) no impidió la invocación con `/` en modo headless.
  - El skill depende de que el runtime pase bien `$ARGUMENTS`. Si llega vacío, usa el PR de la rama actual.

## Alternativas descartadas

- **Mantener el prompt para Claude y añadir un skill solo para Antigravity**: dos piezas con el mismo nombre invocable, el antipatrón que 0012 ya señalaba.
- **Ampliar el aprovisionador ([0021](../4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) para convertir prompts en skills**: más código temporal para algo que el formato skill ya resuelve de forma nativa en los dos runtimes.

## Conceptos

- [Description matching](../../1-conceptos/2-primitivos-y-activacion/description-matching.md): la `description` sustituye a `disable-model-invocation` como freno a la activación automática.
- [Frontmatter](../../1-conceptos/2-primitivos-y-activacion/frontmatter.md): qué campos lee cada runtime.
