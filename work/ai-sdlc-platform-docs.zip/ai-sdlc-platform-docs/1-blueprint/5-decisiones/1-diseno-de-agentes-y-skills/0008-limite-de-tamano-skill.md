# 0008 — Límite de tamaño concreto para SKILL.md

## Estado

Propuesta.

## Contexto

[`primitivos/skills.md`](../../2-primitivos/skills.md) ya documenta que existen archivos de soporte cargados on-demand (progressive disclosure), pero no da ningún criterio de cuándo algo debería moverse ahí en vez de quedarse en el `SKILL.md` principal. Sin un umbral, en la práctica los `SKILL.md` crecen sin control — cada ejemplo nuevo, cada caso de borde, se agrega al archivo principal porque no hay una señal clara de "esto ya debería ser un archivo aparte".

## Decisión

Fijar un umbral concreto (no aplica link oficial — patrón propio del repo) (~500 líneas, mecánica en [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md)) como señal de que el contenido debe extraerse, en vez de dejarlo a criterio subjetivo de cada autor.

## Consecuencias

- **Positivas**: da una señal objetiva y fácil de chequear para decidir cuándo extraer contenido; evita que cada activación de la skill cargue contenido que la tarea concreta no necesita.
- **Negativas / trade-off**: un número fijo es arbitrario — puede haber skills legítimamente extensas sin partes separables, o skills cortas que ya deberían dividirse antes de llegar al umbral; el número por sí solo no sustituye el juicio de qué es "siempre necesario" vs. "solo en algunos casos".

## Alternativas descartadas

- **Sin límite explícito, a criterio de cada autor**: descartado porque en la práctica los `SKILL.md` crecen sin control hasta contaminar cada activación — es exactamente lo que se observa cuando no hay un umbral.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Progressive disclosure](../../1-conceptos/2-primitivos-y-activacion/progressive-disclosure.md) — el mecanismo de carga escalonada que justifica mover contenido a archivos de soporte on-demand.
- [Ventana de contexto](../../1-conceptos/1-fundamentos-del-modelo/ventana-de-contexto.md) — el espacio finito que el umbral de ~500 líneas busca no desperdiciar en cada activación.
