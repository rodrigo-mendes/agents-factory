# 0018 — Estructurar prompts con etiquetas XML solo donde hay datos no confiables o entregas entre roles

## Estado

Propuesta.

## Contexto

Ningún prompt de este repo usa etiquetas XML estructurales. En la revisión de PR conviven tres situaciones donde el modelo recibe, en el mismo texto, instrucciones y contenido que no debe obedecer o que otro paso debe leer de forma fiable:

- El prompt de CI mezcla metadatos del PR (repo, número, SHA) con la instrucción de delegar, sin delimitar.
- El título, la descripción, los commits, el diff y los ficheros de un PR los controla quien abre el PR. La única defensa estructural es una regla en prosa repetida en tres sitios, y `gh_pr.py view` marca como `untrusted` solo `title`, `body` y `labels`. El propio concepto reconoce que está "mitigado en prosa y por estructura, sin prueba que lo verifique" (ver [prompt-injection](../../1-conceptos/5-distribucion-y-dominio/prompt-injection.md)).
- Cada rol devuelve un bloque `execution` + `findings` suelto dentro de la misma conversación, y `proc-pr-review` decide `not_executed` según lo que "ve". El contrato no tiene un delimitador (ver [contrato de entrada y salida](../../1-conceptos/3-orquestacion/contrato-de-entrada-salida.md)).

No hay convención escrita sobre cuándo delimitar y cuándo no. El riesgo opuesto también existe: envolver todo en etiquetas añade ruido sin beneficio.

## Decisión

Usar etiquetas XML **solo** cuando se da al menos una de estas condiciones:

1. El prompt mezcla instrucciones con datos variables o no confiables (input del usuario, contenido de un PR, metadatos inyectados por CI).
2. Un rol entrega a otro un resultado que el receptor debe poder localizar y validar.

Se usa un vocabulario cerrado: `<untrusted_pr_content>`, `<user_request>`, `<pr_context>`, `<task>`, `<role_result role="…">` y `<review_context>`. En instrucciones puras (agentes, `std-*`, conocimiento de referencia) no se usan: bastan cabeceras, tablas y listas. Cuando el problema es de reglas dispersas o de formato sin plantilla, se reestructura el texto en lugar de añadir etiquetas. La mecánica y los ejemplos viven en [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md).

Las etiquetas no se consideran una medida de seguridad. El control sigue siendo el menor privilegio (`tools:`, `--allowedTools`, `--disallowedTools`).

## Consecuencias

- **Positivas**: límite explícito entre instrucción y dato en los puntos de mayor riesgo; el contrato de los roles se puede comprobar (falta de `<role_result>` implica `not_executed`); una regla corta para decidir en prompts nuevos.
- **Negativas / trade-off**: más texto en los prompts afectados; el vocabulario de etiquetas hay que mantenerlo coherente entre repos; los placeholders de las plantillas (`<VERDICT>`, `<short-sha>`) se parecen visualmente a etiquetas, por eso no se tocan; no hay evidencia medida de que las etiquetas mejoren el resultado, de modo que su mantenimiento depende del escenario de prueba de la [ADR 0009](../3-control-y-calidad/0009-testing-de-skills-con-escenarios.md).

## Alternativas descartadas

- **XML en todos los prompts**: descartado porque en instrucciones puras no aporta y añade ruido.
- **Solo prosa (estado actual)**: descartado porque no da un límite estructural donde el contenido lo controla un tercero.
- **Validar la salida de los roles con un script en vez de etiquetas**: no se descarta como complemento, pero hoy los roles comparten conversación con el orquestador y no hay un punto donde ejecutarlo.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Prompt injection](../../1-conceptos/5-distribucion-y-dominio/prompt-injection.md) — por qué el contenido de un PR es un vector y por qué las etiquetas no bastan.
- [Contrato de entrada y salida](../../1-conceptos/3-orquestacion/contrato-de-entrada-salida.md) — qué recibe y qué devuelve cada rol.
