# 0002 — Taxonomía de tipos de skill

## Estado

Aceptada — ya en uso en [modelo-ejecucion.md](../../3-modelo-operativo/modelo-ejecucion.md) y en sus diagramas.

## Contexto

Sin una taxonomía explícita, cada [skill](../../2-primitivos/skills.md) nueva requiere que quien la lee infiera su rol leyendo el `SKILL.md` completo — no hay forma rápida de saber, mirando un diagrama de ejecución, si un nodo "Skill X" va a decidir flujo, aplicar un checklist fijo, o simplemente servir de referencia pasiva. Los diagramas de [modelo-ejecucion.md](../../3-modelo-operativo/modelo-ejecucion.md) ya distinguían roles (orquestadora/especialista/KB) antes de que existiera una definición formal citable, lo que hacía cada diagrama consistente solo consigo mismo.

## Decisión

Formalizar 3 roles (no aplica link oficial — patrón propio del repo) — mecánica completa en [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md) — como convención de diseño: no un campo de frontmatter, sino un vocabulario compartido para documentar y diagramar en todo el blueprint. Se documenta como buena práctica, no como decisión de mecánica, porque no compite con alternativas formales de implementación; lo que sí es una decisión es **que exista la taxonomía en absoluto** y se use consistentemente.

## Consecuencias

- **Positivas**: los diagramas de ejecución y de distribución pueden etiquetar nodos con un vocabulario común sin redefinirlo cada vez; facilita detectar cuando una skill mezcla roles (ej. una "especialista" que también decide flujo) como señal de que debería dividirse.
- **Negativas / trade-off**: es una convención informal, no forzada por ningún frontmatter — nada impide que una skill nueva no se clasifique o se clasifique mal; depende de disciplina documental, no de validación automática.

## Alternativas descartadas

- **Inferir el rol desde el frontmatter** (ej. presencia de `context: fork` implica orquestadora): descartado, no es 1:1 — una orquestadora puede no tener fork si corre inline.
- **No tener taxonomía y describir cada skill en prosa libre cada vez**: descartado, es lo que había antes y dificultaba comparar diagramas entre sí.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Orquestador vs. especialista](../../1-conceptos/3-orquestacion/orquestador-vs-especialista.md) — dos de los tres roles formalizados por esta taxonomía, con el tercero (conocimiento pasivo).
