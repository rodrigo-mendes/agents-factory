# 0013 — Convenciones de nombre por rol, no kebab-case genérico

## Estado

Propuesta.

## Contexto

Este blueprint ya usa la taxonomía de [tipos de skill](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md) (orquestadora/especialista/conocimiento pasivo) para clasificar por rol, pero no dice nada sobre cómo debería reflejarse esa clasificación en el *nombre* del archivo. Sin una convención, dos skills del mismo rol pueden nombrarse con patrones completamente distintos, y el nombre por sí solo no comunica si el artefacto es de activación automática o de invocación deliberada.

## Decisión

Adoptar convención de nombre por rol (no aplica link oficial — patrón propio del repo) (mecánica en [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/convenciones-de-nombres.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/convenciones-de-nombres.md)): gerundio-sustantivo para conocimiento pasivo, acción-sustantivo/dominio-rol para acción y agentes, alcance-sustantivo para reglas.

## Consecuencias

- **Positivas**: el nombre solo comunica el rol sin tener que abrir el archivo — "researching-X" se sabe de antemano que es conocimiento pasivo, no algo que hay que invocar.
- **Negativas / trade-off**: renombrar artefactos existentes para ajustarse a la convención tiene costo (links rotos, referencias que actualizar); la convención requiere que el autor ya sepa el rol antes de nombrar, lo cual no siempre es obvio al momento de crear el archivo.

## Alternativas descartadas

- **Nombre libre siempre que sea kebab-case**: descartado porque no comunica de un vistazo si el artefacto es conocimiento pasivo, acción, o agente — hay que abrir el archivo para saberlo, perdiendo la ventaja de un nombre bien elegido.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Orquestador vs. especialista](../../1-conceptos/3-orquestacion/orquestador-vs-especialista.md) — la clasificación por rol que esta convención de nombre busca reflejar en el nombre del archivo.
