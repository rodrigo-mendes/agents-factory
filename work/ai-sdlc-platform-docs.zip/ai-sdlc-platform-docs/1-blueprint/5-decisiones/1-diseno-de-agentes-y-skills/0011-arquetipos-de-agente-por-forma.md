# 0011 — Arquetipos de agente con enforcement por `tools:`

## Estado

Propuesta.

## Contexto

Un agente pensado como "solo asesor" (sin efectos secundarios) suele declararse así solo en prosa — "no escribas código, solo recomienda" — sin que el frontmatter refuerce esa restricción. [`primitivos/subagents.md`](../../2-primitivos/subagents.md) ya documenta que `tools:` reemplaza, no extiende, el pool heredado; pero nada en el blueprint conectaba explícitamente ese mecanismo con el diseño de roles de agente.

## Decisión

Definir arquetipos de agente por forma (no aplica link oficial — patrón propio del repo) (orquestador multi-dominio, asesor de solo lectura, etc. — mecánica en [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md)) donde el rol "asesor" se fuerza omitiendo `Write`/`Edit`/`Bash` de `tools:`, no solo pidiéndolo en el prompt.

## Consecuencias

- **Positivas**: el rol queda estructuralmente imposible de violar — un agente sin `Write` en `tools:` no puede escribir un archivo aunque su prompt se corrompa o el modelo "olvide" la instrucción de prosa.
- **Negativas / trade-off**: requiere pensar de antemano en qué arquetipo encaja el agente nuevo, en vez de partir siempre del mismo template genérico; un agente que después necesita una capacidad nueva (ej. un asesor que ahora sí necesita escribir un reporte) requiere revisar y ampliar deliberadamente su `tools:`, no solo cambiar el prompt.

## Alternativas descartadas

- **Un solo template genérico + instrucción en prosa pidiendo el límite de rol**: descartado porque una instrucción en prosa no es estructuralmente vinculante — es exactamente el mismo argumento ya usado en `primitivos/subagents.md` para justificar por qué `tools:` reemplaza en vez de extender.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Frontmatter](../../1-conceptos/2-primitivos-y-activacion/frontmatter.md) — por qué omitir una herramienta de `tools:` es enforcement estructural y no una sugerencia en prosa.
- [Orquestador vs. especialista](../../1-conceptos/3-orquestacion/orquestador-vs-especialista.md) — los roles que un arquetipo por forma busca reforzar vía `tools:`.

## Actualización (2026-11-03)

El ADR solo describía el asesor sin `Write`/`Edit`/`Bash`. La remediación de SARIF ([../../../2-architecture/sarif-remediation-java-flow.md](../../../2-architecture/sarif-remediation-java-flow.md)) añade dos formas más, también reforzadas por `tools:`:

- **Implementador acotado** (`backend-java-fix`): `Read, Grep, Glob, Edit, Write`; sin `Bash` ni `Agent`. Puede editar, pero no commitear, compilar ni delegar.
- **Orquestador con efectos vía scripts** (`backend-java-remediate`): `Read, Grep, Glob, Bash, Agent`; sin `Edit`/`Write`. Los efectos pasan solo por scripts de los roles; el alcance de `Bash` lo acotan los permisos del consumidor, no la prosa.

La decisión sigue en estado **Propuesta**.
