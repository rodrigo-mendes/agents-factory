# 0010 — Jerarquía de capas con prohibiciones explícitas

## Estado

Propuesta.

## Contexto

La separación de responsabilidad entre agente orquestador, [skill](../../2-primitivos/skills.md) de conocimiento y skill de acción existe en este blueprint de forma implícita — se puede inferir leyendo `primitivos/subagents.md` y `primitivos/skills.md` por separado — pero no hay ningún lugar que declare explícitamente qué le está *prohibido* a cada capa. Sin esa prohibición explícita, con el tiempo las capas tienden a mezclarse: una skill "de acción" empieza a acumular conocimiento de dominio que debería vivir en una skill de conocimiento, o un agente empieza a hardcodear reglas que deberían vivir en una skill.

## Decisión

Formalizar capas nombradas (no aplica link oficial — patrón propio del repo) con columna explícita de "qué NO debe contener" cada una, y la regla de que la delegación va siempre hacia abajo (mecánica en [../../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md)).

## Consecuencias

- **Positivas**: da un criterio concreto para detectar cuándo una capa se está mezclando con otra ("¿esta skill está haciendo algo de su columna prohibida?"); facilita revisar diseños nuevos contra un checklist en vez de un juicio subjetivo.
- **Negativas / trade-off**: mantener la tabla de capas y prohibiciones actualizada es trabajo adicional; en un proyecto pequeño con pocas capas, la formalización puede ser más ceremonia que valor.

## Alternativas descartadas

- **Dejar la separación de responsabilidad implícita**: descartado porque sin la columna de "qué NO debe contener" las capas tienden a mezclarse con el tiempo, sin ninguna señal que lo marque hasta que el diseño ya está enredado.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Delegación y jerarquía de capas](../../1-conceptos/3-orquestacion/delegacion-y-jerarquia-de-capas.md) — la regla de que la delegación va siempre hacia abajo, con columna explícita de qué no debe contener cada capa.
- [Subagente y aislamiento de contexto](../../1-conceptos/2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md) — por qué describir la jerarquía en prosa no garantiza que esté wireada estructuralmente.
