# 0001 — Agente router para entrada ambigua

## Estado

Propuesta.

## Contexto

En la entrada agnóstica **agente por `description`** ([modelo-ejecucion.md §3.2](../../3-modelo-operativo/modelo-ejecucion.md#32-agente-por-description)) no hay `/nombre`. El usuario describe la tarea, u otro agente delega, y el modelo elige el [subagente](../../2-primitivos/subagents.md) comparando su `description`.

Ese matching asume que hay un único candidato claro. Cuando la petición es ambigua y dos o más skills o agentes tienen una `description` parecida, el sistema puede:
- (a) elegir uno arbitrariamente y ejecutar sin que el usuario lo pida, con el riesgo de resolver la tarea equivocada;
- (b) preguntar.

Hoy esto no está resuelto en el blueprint: la entrada *agente por `description`* solo describe el caso feliz.

La selección ocurre de forma distinta en cada runtime, pero el problema es el mismo en los dos:

| Runtime | Quién elige el agente | Forma de evitar la ambigüedad sin router |
|---|---|---|
| Claude Code | Claude, por la `description` del subagente | `@agent-<name>` o `claude --agent` (solo Claude) |
| Antigravity | El planificador del agente principal, que delega con `invoke_subagent` | `agy --agent <name>`; ninguna @-mención elige agente |

Detalle en [modelo-ejecucion-claude-code.md](../../3-modelo-operativo/modelo-ejecucion-claude-code.md) y [modelo-ejecucion-antigravity.md](../../3-modelo-operativo/modelo-ejecucion-antigravity.md).

## Decisión

Adoptar el patrón **agente router** (no aplica link oficial — patrón propio del repo) para la entrada **agente por `description`**, en cualquier runtime.

- El router es un intermediario que conoce el catálogo de skills y agentes.
- Ante un match claro, delega directamente. Ante la ambigüedad, presenta las candidatas al usuario antes de ejecutar nada.
- Se escribe como agente o como skill, nunca como command o prompt ([0020](0020-puntos-de-entrada-como-skills.md)). Pide la delegación en su texto ([0023](../2-orquestacion/0023-delegacion-explicita-en-el-texto.md)), así funciona igual en Claude Code (`Agent`) y en Antigravity (`invoke_subagent`).

La mecánica completa, con las dos variantes observadas (router a nivel de subagente y a nivel de skill), está en [agente-router.md](../../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md).

## Consecuencias

- **Positivas**: evita ejecuciones erróneas silenciosas cuando la intención del usuario es ambigua. El catálogo de candidatas queda centralizado en un solo lugar (el router), en lugar de repetirse en cada agente.
- **Negativas / trade-off**:
  - Añade un salto extra (router → agente real), incluso en el caso feliz de un match claro.
  - El router tiene que mantenerse sincronizado con el catálogo de skills instaladas (ver [distribucion.md](../../3-modelo-operativo/distribucion.md)).
  - Las formas de forzar un agente sin router (`@agent-…`, `--agent`) cambian según el runtime, así que no sirven como solución agnóstica.

## Alternativas descartadas

- **Dejar que el modelo decida siempre sin preguntar**: descartada, porque es la causa raíz del problema que esta decisión busca resolver.
- **Que cada agente detecte su propia ambigüedad**: descartada, porque obligaría a duplicar la lógica de comparación entre agentes que no se conocen entre sí. El router centraliza precisamente esa comparación.
- **Pedir al usuario que nombre el agente (`@agent-…` / `--agent`)**: descartada como solución general. Depende del runtime (en Antigravity, las @-menciones no eligen agente) y traslada la ambigüedad al usuario.

## Conceptos

Vocabulario necesario para leer esta decisión:

- [Description matching](../../1-conceptos/2-primitivos-y-activacion/description-matching.md): el mecanismo cuya ambigüedad entre descriptions parecidas es el problema que resuelve el router.
- [Harness de agente](../../1-conceptos/2-primitivos-y-activacion/harness-de-agente.md): cada harness hace a su manera la selección por `description`.

## Actualización (2026-10-15)

La referencia a `knowledge-catalog` en el trade-off anterior corresponde a un paquete que ya no existe. El catálogo de conocimiento actual es el índice de `kb-java-best-practices`; el problema de mantener sincronizado un índice con lo instalado sigue vigente. La decisión sigue en estado **Propuesta**.

## Actualización (2026-10-28)

El ADR pasa a referirse a la entrada agnóstica *agente por `description`*. Antes se refería a la "Entrada C" del modelo de Claude Code; las entradas A–D quedaron como formato histórico de Claude Code ([0020](0020-puntos-de-entrada-como-skills.md)). La decisión sigue en estado **Propuesta**.
