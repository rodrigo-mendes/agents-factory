# Fase 2 — Cómo se invoca y dónde corre

## Objetivo

Decidir cómo se llega al trabajo (¿hay skill de entrada `/nombre`?) y dónde corre (dentro de un agente o inline), con una de las tres salidas agnósticas que funcionan en todos los runtimes objetivo.

## Precondición

Tabla de artefactos de la fase 1 aprobada en el gate. Hay que saber ya qué agentes y skills existen y cuál es la orquestadora.

## Pasos

1. **Elige la salida con el árbol.** Las tres salidas son agnósticas y están descritas en [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).

```mermaid
flowchart TD
    Q1{"¿La teclea una persona<br/>como /nombre?"}
    Q1 -- "sí" --> Q2{"¿Necesita aislamiento<br/>o un agente concreto?"}
    Q2 -- "sí: la skill nombra al agente" --> E["Skill de entrada → agente"]
    Q2 -- "no" --> I["Skill inline"]
    Q1 -- "no" --> Q3{"¿Hace falta un agente<br/>(aislamiento, tools propias)?"}
    Q3 -- "sí: el agente se elige por description" --> D["Agente por description"]
    Q3 -- "no" --> I

    style E fill:#e2f6e2,stroke:#27ae60
    style D fill:#e2f6e2,stroke:#27ae60
    style I fill:#e2f6e2,stroke:#27ae60
```

   - **Skill de entrada → agente:** una skill `/nombre` que delega en un agente concreto. Es el caso de `/review-pr-java`.
   - **Agente por `description`:** no hay skill de entrada. El modelo (o un agente padre) elige el agente por su `description`.
   - **Skill inline:** la skill corre en el contexto de quien la llama, sin agente.

   Headless no es una decisión de diseño: las tres salidas funcionan con `claude -p` y `agy -p`.

2. **Anota la consecuencia para las fases 4 y 5**, en los dos runtimes:

   | Salida | Fase 4 (skills) | Fase 5 (agentes) | En Claude Code | En Antigravity |
   |---|---|---|---|---|
   | Skill de entrada → agente | Frontmatter `context: fork` + `agent:` + `disable-model-invocation: true`, **y** las dos secciones de texto ("si no eres el agente, delega / si lo eres, ejecuta") | El agente lleva `tools:` traducibles; la orquestadora interna no lleva fork | El fork ejecuta la skill dentro del agente: entra por "si lo eres" | La skill corre en el agente principal, que delega con `invoke_subagent`: entra por "si no eres" |
   | Agente por `description` | Ninguna skill de entrada; la orquestadora, sin fork | La `description` del agente carga con toda la selección | Claude delega por `description` | El planificador delega por `description` |
   | Skill inline | Sin fork ni `agent:`; `description` con freno si solo debe activarla la persona | Ninguno | Corre en el contexto del caller | Igual |

3. **Decide si hay skill de entrada y su nombre.** La hay si una persona la teclea.
   - Una skill de entrada no tiene por qué ser 1:1 con las skills internas.
   - Las skills internas (`proc-*`, `act-*`, `kb-*`) no son entradas.
   - Nunca se escribe como command ni prompt ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).

4. **Si la skill de entrada delega, decide la delegación completa.** Se escribe en la fase 4, pero se decide aquí:
   - frontmatter `context: fork` + `agent:` (Claude);
   - **y** la delegación pedida en el texto, con la salida "si no puedes delegar, detente y dilo" ([delegación explícita](../4-buenas-practicas/2-orquestacion/delegacion-explicita-en-el-texto.md)).

   El texto hace falta porque Antigravity ignora `context: fork` y `agent:`. Sin él, la skill corre en el agente principal, sin el agente, y no hay error ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).

5. **Si hay efectos externos (publicar, escribir en terceros), exige una skill que solo active la persona.** El checkpoint va en la invocación: la skill de entrada con sus dos frenos (fase 4). Un "agente por `description`" no da ese checkpoint, porque lo elige el modelo.

6. **Decide si hace falta un agente router.** Solo para "agente por `description`", y solo si el catálogo de candidatos puede crecer hasta que el matching deje de ser obvio ([agente-router](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md)).
   - Con 2 o 3 agentes muy distintos es sobreingeniería: anota "sin router".

7. **Si hay fan-out paralelo, fija el cap ahora** ([cap-fanout-depth](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md)). El guard se redacta en la fase 5; la decisión de que exista es de esta fase.

8. **Si el proceso escribe y puede correr sin humano, decide autónomo o interactivo.**
   - **Autónomo** (default de un proceso de CI): una sola invocación, `--repo` y demás datos obligatorios, y todo "Preguntar primero" pasa a fallo con código. Los efectos externos quedan tras barreras opt-in (p. ej. `publish=true` + `GIT_CHANGE_PUBLISH=1`). Debe ser invocable también en headless (`claude -p` / `agy -p`) accionando la skill de entrada, no solo con `--agent`.
   - **Interactivo**: la persona teclea `/nombre`. Como el subagente forkeado no puede preguntar, el flujo se parte en **pasos** (`plan` → `apply` → `publish`) con el estado en un archivo. Ver [puntos-de-entrada.md](../../2-architecture/puntos-de-entrada.md) y [ADR 0005](../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md).

9. **Comprueba la coherencia con el arquetipo de la fase 1.** Si el arquetipo es "asesor de solo lectura" pero la entrada tiene efectos externos, una de las dos decisiones está mal: vuelve a la fase 1 y reabre el gate.

## Reglas que aplican

- Las salidas agnósticas y cómo corren en cada runtime: [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).
- Skill de entrada: [puntos-de-entrada-como-skills](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md) · [0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md).
- Delegación en el texto: [delegación explícita](../4-buenas-practicas/2-orquestacion/delegacion-explicita-en-el-texto.md) · [0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md).
- Campos de skill y de agente: [skills.md](../2-primitivos/skills.md) · [subagents.md](../2-primitivos/subagents.md).
- Detalle por runtime: [runtime-claude-code.md](../2-primitivos/runtime-claude-code.md) · [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md).
- Router: [agente-router](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md) · [0001](../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md).
- Cap de fan-out: [cap-fanout-depth](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md) · [0004](../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md).

## Salida

Cuatro decisiones escritas:

- Salida elegida (skill de entrada → agente / agente por `description` / skill inline) y, si aplica, el agente.
- Skill de entrada: sí (con nombre) o no.
- Router: sí o no, con el motivo.
- Cap de fan-out: aplica o no aplica.

## Errores comunes

- **Crear un command o un prompt.** Están prohibidos. Todo `/nombre` es una skill de entrada.
- **Skill de entrada que delega solo por frontmatter.** En Claude funciona; en Antigravity la skill corre en el agente principal sin el agente, y no hay error. La delegación va también en el texto.
- **Depender de `@agent-…` o de `claude --agent` como única forma de llegar al agente.** Las @-menciones de Antigravity no eligen agente, y `agy --agent` obliga a recordarlo. La entrada agnóstica es la skill de entrada o la `description`.
- **Una skill de entrada por cada skill.** La entrada existe para lo que una persona teclea; una skill que solo invoca la orquestadora no necesita puerta propia.
- **Fork en la skill de entrada y también en la orquestadora interna.** Dos aislamientos apilados sin motivo: el agente ya arranca limpio.
- **Confiar en el límite técnico de nesting como si fuera el cap de diseño.** Son cosas distintas; el cap se decide aquí.
