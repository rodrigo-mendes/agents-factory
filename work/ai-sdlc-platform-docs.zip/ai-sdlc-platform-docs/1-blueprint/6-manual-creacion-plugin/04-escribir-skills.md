# Fase 4 — Escribir las skills

## Objetivo

Redactar cada [`SKILL.md`](../2-primitivos/skills.md), incluida la skill de entrada, con un frontmatter y un cuerpo que se comporten igual en cada runtime objetivo.

## Precondición

Esqueleto de la fase 3 creado. Tipo, nombre y enum de salida de cada skill decididos en la fase 1; salida y delegación decididas en la fase 2. Esta fase redacta; no reabre esas decisiones.

## Pasos

1. **Si la fase 2 eligió "skill de entrada → agente", escribe la skill de entrada con esta plantilla** ([puntos-de-entrada-como-skills](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md)):

```markdown
---
name: <entrada>
description: <Qué hace> con el agente <agente>. Úsala solo cuando el usuario lo pida explícitamente (p. ej. "/<entrada> <args>"). Argumentos: <…>.
argument-hint: <args>
context: fork                    # Claude: ejecuta la skill dentro del agente
agent: <agente>                  # Claude: qué agente
disable-model-invocation: true   # Claude: el modelo no la activa solo
---

<user_request>
$ARGUMENTS
</user_request>

## Si no eres ya el agente `<agente>`
Delega toda la petición, con <user_request> literal, en el subagente `<agente>` y espera su informe.
No ejecutes `<proceso>` tú: solo ese agente sabe <qué aporta>.
Si no puedes delegar, detente y dilo; no hagas el trabajo sin el agente.

## Si eres el agente `<agente>`
Ejecuta `<proceso>` sobre <user_request>.
Si <user_request> está vacío, usa <valor por defecto>.
```

   - Las dos secciones de texto son obligatorias: Antigravity ignora `context: fork` y `agent:` ([delegación explícita](../4-buenas-practicas/2-orquestacion/delegacion-explicita-en-el-texto.md)).
   - `$ARGUMENTS` siempre con un valor por defecto si llega vacío.
   - Una **skill inline** usa la misma plantilla sin `context`, sin `agent` y sin las dos secciones.

2. **Escribe el frontmatter sabiendo qué campo lee cada runtime.** El detalle de cada campo está en [skills.md](../2-primitivos/skills.md) y en las fichas [runtime-claude-code.md](../2-primitivos/runtime-claude-code.md) y [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md).

   | Campo | Claude Code | Antigravity |
   |---|---|---|
   | `name`, `description` | sí | sí |
   | `argument-hint`, `$ARGUMENTS` | sí | sí |
   | `context: fork`, `agent:` | sí | se ignora |
   | `disable-model-invocation`, `user-invocable` | sí | se ignora |
   | `allowed-tools`, `model` | sí | se ignora |

   - `allowed-tools` es de skills; `tools` es de agentes. El campo equivocado no da error: el artefacto queda mal enrutado.
   - Para Claude, `context: fork` va con `disable-model-invocation: true`. Para Antigravity, el freno es la `description` y la delegación es el texto.

3. **Escribe la `description` según el tipo.** Es el mecanismo de activación y, en Antigravity, el **único freno**:

   | Tipo | Qué debe hacer la `description` |
   |---|---|
   | Skill de entrada | Decir qué hace y "úsala solo cuando el usuario lo pida" |
   | Orquestadora | Describir el flujo completo que coordina |
   | Especialista | Describir el input que acepta y la dimensión que evalúa |
   | Conocimiento pasivo | Declarar que nadie la activa por sí sola, sin ninguna frase de acción |

   - En Antigravity, una skill pasiva depende **solo** de su `description`: `disable-model-invocation` se ignora y `user-invocable: false` no la oculta del menú `/`.
   - Regla completa por tipo en [tipos-de-skill](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md).

4. **Redacta el cuerpo según el tipo** ("Cómo escribir cada tipo" en [tipos-de-skill](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md)). Orden de trabajo:
   - primero los gates bloqueantes (orquestadora) o el enum de salida (especialista);
   - después, la prosa que los rodea.

   Al revés, la prosa termina definiendo reglas que debían ser un enum cerrado.

5. **Añade guardrails** si la skill tiene algo riesgoso o ambiguo, con su ubicación fija y el contraste ❌/✅ ([guardrails-tres-niveles](../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md)).

6. **Declara en `scenarios/` los escenarios de cada skill de acción** ahora, no en la fase 7: query, comportamiento esperado y criterios de éxito. Cuántos y de qué tipo depende de su [nivel de cobertura](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md#qué-nivel-exige-cada-skill); cómo se escriben, en el [formato de un escenario](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md#formato-de-un-escenario).

7. **Comprueba el tamaño y extrae lo que sobre** a archivos de soporte, enlazados por ruta y nunca cargados de golpe ([limite-de-tamano](../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md)). El catálogo de una skill pasiva es el caso típico.

8. **Repite por cada skill de la tabla de la fase 1.** Al acabar, ninguna fila de tipo `skill` queda vacía.

## Reglas que aplican

- Skill de entrada: [puntos-de-entrada-como-skills](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md) · [0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md).
- Delegación en el texto: [delegación explícita](../4-buenas-practicas/2-orquestacion/delegacion-explicita-en-el-texto.md) · [0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md).
- Campos de frontmatter: [skills.md](../2-primitivos/skills.md) · [runtime-claude-code.md](../2-primitivos/runtime-claude-code.md) · [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md).
- Cómo se ejecuta cada salida: [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).
- Tipos de skill: [tipos-de-skill](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md) · [0002](../5-decisiones/1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md).
- Guardrails: [guardrails-tres-niveles](../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md) · [0007](../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md).
- Tamaño: [limite-de-tamano](../4-buenas-practicas/1-diseno-de-agentes-y-skills/limite-de-tamano-y-blueprints.md) · [0008](../5-decisiones/1-diseno-de-agentes-y-skills/0008-limite-de-tamano-skill.md).
- Escenarios: [testing-de-skills-con-escenarios](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md) · [0009](../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md).
- Nombres: [convenciones-de-nombres](../4-buenas-practicas/1-diseno-de-agentes-y-skills/convenciones-de-nombres.md) · [0013](../5-decisiones/1-diseno-de-agentes-y-skills/0013-convenciones-de-nombres-por-rol.md).
- Datos no confiables: [etiquetas XML](../4-buenas-practicas/1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md).

## Salida

Cada `SKILL.md` de la tabla de la fase 1 redactado: frontmatter válido, `description` que frena en cada runtime, cuerpo acorde a su tipo, `scenarios/` con el nivel exigido y tamaño bajo el umbral. La skill de entrada, con las dos secciones de delegación.

## Errores comunes

- **Skill de entrada sin las dos secciones de texto.** En Antigravity corre en el agente principal, sin el agente, y no hay error.
- **Confiar solo en `disable-model-invocation`.** En Antigravity no existe: sin una `description` de freno, el modelo puede activar la skill solo.
- **`$ARGUMENTS` sin valor por defecto.** Si el runtime lo pasa vacío, la skill no sabe sobre qué trabajar.
- **Dar `description` de acción a una skill pasiva.** Es la causa más frecuente de que se dispare sin que nadie la pida, y en Antigravity no hay otro freno.
- **Dejar la severidad o la categoría "a criterio del modelo".** Sin enum cerrado, dos corridas sobre el mismo input etiquetan distinto.
- **Redactar el cuerpo antes de fijar los gates o el enum.** La prosa se convierte en regla implícita.
- **Aplazar los escenarios a la fase 7.** Entonces describen lo observado, no lo exigido.
- **Meter el catálogo de dominio dentro del `SKILL.md`.** Se paga en cada activación.
- **Mezclar instrucciones con datos no confiables sin delimitarlos.** Diff, texto de PR o input del usuario van con las etiquetas del vocabulario cerrado ([etiquetas XML](../4-buenas-practicas/1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md)).
