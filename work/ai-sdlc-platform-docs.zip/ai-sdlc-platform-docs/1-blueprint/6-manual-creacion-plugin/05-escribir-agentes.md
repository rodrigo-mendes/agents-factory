# Fase 5 — Escribir los agentes

## Objetivo

Redactar cada [`*.agent.md`](../2-primitivos/subagents.md) con un frontmatter que se traduzca a cada runtime objetivo, un `tools:` que haga imposible violar el rol y un cuerpo con fases, modos de fallo y límites explícitos.

## Precondición

Esqueleto de la fase 3 creado. Arquetipo, `tools:`, fases y límites decididos en la fase 1; salida y cap de fan-out decididos en la fase 2. Es independiente de la fase 4.

## Pasos

1. **Escribe el frontmatter solo con campos que se traducen.** El aprovisionador genera el agente de Antigravity desde este archivo y **falla** con cualquier campo que no sepa traducir ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

   Campos admitidos:

   - `name` y `description` (obligatorios);
   - `tools`;
   - `model`, solo `inherit` o ausente;
   - `skills`;
   - `antigravity:` (paso 5).

   Detalle en [subagents.md](../2-primitivos/subagents.md) y [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md).

2. **Escribe `tools:` solo con nombres traducibles:** `Read`, `Grep`, `Glob`, `LS`, `Bash`, `Write`, `Edit`, `WebFetch`, `WebSearch`, `Task`/`Agent`.
   - `tools:` **reemplaza** el pool heredado, no lo extiende ([subagents.md](../2-primitivos/subagents.md)).
   - Sin `tools`, el agente recibe todas las herramientas en los dos runtimes, delegación incluida.
   - Cualquier otro nombre hace fallar al aprovisionador: el agente no llega a Antigravity.

3. **Si el cuerpo delega en otro agente, incluye `Task` o `Agent`.** Se traducen a `invoke_subagent` en Antigravity.
   - Ningún runtime comprueba que cuerpo y frontmatter coincidan.
   - Sin la herramienta, la delegación descrita queda muerta en el prompt.

4. **Usa `skills:` para dar skills al agente, no la herramienta `Skill`.** `Skill` no tiene traducción a Antigravity.

   | Necesidad | Campo |
   |---|---|
   | El agente siempre necesita ese contenido | `skills:`: precarga al iniciar |
   | El agente consulta un documento de conocimiento cuando lo necesita | leerlo por ruta con `Read` |

   - En Antigravity, `skills:` **no limita**: el agente puede usar cualquier skill del proyecto.
   - Un nombre erróneo en `skills:` no falla en `apm install`. Falla en el runtime de Claude, y en el aprovisionador si la skill no está desplegada en `.agents/skills/` ([06-declarar-apm.md](06-declarar-apm.md)).

5. **Añade el bloque `antigravity:` solo si hace falta.** Claude lo ignora; el aprovisionador lo copia tal cual:
   - `mainAgent: false`: el agente no se puede elegir como agente principal (lo usa `backend-java-ci`);
   - `subagent`: si otro agente puede delegar en él con `invoke_subagent` (por defecto `true`; [Subagents — antigravity.google](https://antigravity.google/docs/subagents));
   - `commandExecutionPolicy`: `off`, `auto`, `eager` o `sandbox` (por defecto).

6. **Escribe las fases con su modo de fallo**, tal como se declararon en la fase 1 ([ciclo-de-vida-de-fases](../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md)). Cada fase dice qué hace y qué pasa si falla: abortar, esperar input o corregir y reintentar.

7. **Expón el límite de reintentos como parámetro del agente**, no como número en prosa, y define qué pasa al agotarlo ([bucle de verificación](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md)). Un intento vacío o fallido consume uno de los N.

8. **Apunta la fase de validación a la definición de hecho** de la fase 1 ([definicion-de-hecho](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md)). El agente valida con herramienta, no con su impresión de haber terminado.

9. **Si el agente hace fan-out, escribe el guard del cap** en su prompt ([cap-fanout-depth](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md)).

10. **Si el agente reporta conteos, métricas o estado del repo, escribe la regla de reverificación** ([verificar-no-confiar-en-memoria](../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md)).

11. **Añade guardrails** si hay acciones destructivas o decisiones con trade-off ([guardrails-tres-niveles](../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md)).

12. **Si el arquetipo es asesor de solo lectura**, comprueba dos cosas:
    - `tools:` no incluye `Write`, `Edit` ni `Bash`;
    - la última fase es "Entregar", no "Implementar" ([ciclo-de-vida-de-fases](../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md)).

13. **Si la fase 2 decidió router**, redáctalo según la variante elegida, con su tabla de ruteo y su fallback ([agente-router](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md)). Sus únicas salidas válidas son "a quién delego" o "qué pregunto".

## Reglas que aplican

- Campos del agente y `tools:` que reemplaza: [subagents.md](../2-primitivos/subagents.md).
- Traducción a Antigravity (`tools`, `model`, `skills`, `antigravity:`): [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md) · [0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md).
- Campos propios de Claude: [runtime-claude-code.md](../2-primitivos/runtime-claude-code.md).
- Delegación con `Task`/`Agent` → `invoke_subagent`: [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).
- Arquetipos: [arquetipos-de-agente](../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md) · [0011](../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md).
- Fases y reintentos:
  - [ciclo-de-vida-de-fases](../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md) · [0006](../5-decisiones/2-orquestacion/0006-ciclo-de-vida-fijo.md)
  - [bucle de verificación](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md) · [0016](../5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md).
- Definición de hecho: [definicion-de-hecho](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md).
- Fan-out: [cap-fanout-depth](../4-buenas-practicas/2-orquestacion/cap-fanout-depth.md) · [0004](../5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md).
- Reverificación: [verificar-no-confiar-en-memoria](../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md) · [0014](../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md).
- Guardrails: [guardrails-tres-niveles](../4-buenas-practicas/3-control-y-calidad/guardrails-tres-niveles.md) · [0007](../5-decisiones/3-control-y-calidad/0007-guardrails-tres-niveles.md).
- Router: [agente-router](../4-buenas-practicas/1-diseno-de-agentes-y-skills/agente-router.md) · [0001](../5-decisiones/1-diseno-de-agentes-y-skills/0001-agente-router-para-entrada-ambigua.md).

## Salida

Cada `*.agent.md` de la tabla de la fase 1 redactado: frontmatter solo con campos traducibles, `tools:` coherente con el cuerpo, fases con modo de fallo, límite de reintentos parametrizado y validación apuntada a la definición de hecho.

## Errores comunes

- **Usar campos de frontmatter solo de Claude** (`effort`, `color`, `memory`, `maxTurns`…). El aprovisionador falla y el agente no llega a Antigravity.
- **`model` distinto de `inherit`.** El aprovisionador no lo traduce y falla. Si el proceso necesita un modelo concreto (p. ej. Sonnet), se fija en los **puntos de invocación**: `model:` en el frontmatter de la skill de entrada, `model` en la llamada a `Agent` y `--model` en headless. El agente queda en `inherit`; en Antigravity el modelo sale de la sesión.
- **Poner `Skill` en `tools:`.** No tiene traducción. Usa `skills:` o la lectura por ruta.
- **Prompt que delega sin `Task`/`Agent` en `tools:`.** No hay error al cargar; la delegación no ocurre.
- **Confiar en `skills:` para limitar qué skills usa el agente.** En Antigravity solo precarga.
- **Confiar en la prosa para impedir escrituras.** "No escribas código" es una instrucción; omitir `Write`/`Edit` es una garantía.
- **Contrato que pasa algo que no es texto** entre caller y subagente. Solo texto cruza el límite.
- **Checkpoint humano a mitad de la ejecución del subagente.** No puede hacerlo: el checkpoint va en la skill de entrada o en un flag explícito. Alternativa cuando el proceso necesita varias aprobaciones: **invocación en pasos** (`plan` → `apply` → `publish`), con el estado persistido en un archivo (`run.json`) entre invocaciones. Ver [gate antes de escribir](../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md).
- **Límite de reintentos como número en la prosa.** Deja de ser ajustable por caso de uso.
- **Fase de validación sin lista contra la que validar.** Es la definición de hecho de la fase 1.
- **Mezclar instrucciones con datos no confiables sin delimitarlos** ([etiquetas XML](../4-buenas-practicas/1-diseno-de-agentes-y-skills/estructurar-prompts-con-etiquetas-xml.md)).
