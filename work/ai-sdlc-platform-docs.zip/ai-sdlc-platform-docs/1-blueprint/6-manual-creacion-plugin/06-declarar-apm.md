# Fase 6 — Declarar `apm.yml`

## Objetivo

Declarar el manifiesto APM del paquete (identidad, runtimes objetivo y dependencias pineadas) y dejar escrito lo que necesita quien lo instala.

## Precondición

Skills y agentes redactados (fases 4 y 5), con sus `name` definitivos. Se salta esta fase si la fase 0 decidió "sin APM".

## Pasos

1. **Escribe la identidad y los runtimes objetivo.** `name` coincide con el nombre del repo. `description` describe el contrato (qué consume, qué devuelve), porque APM la usa en índices compilados:

```yaml
# Schema: https://github.com/microsoft/apm/blob/main/docs/src/content/docs/reference/manifest-schema.md
name: mi-paquete
version: 0.1.0
description: >-
  Qué resuelve, qué consume y qué devuelve; no el cómo.
targets:
  - claude
  - antigravity
dependencies:
  apm: []
license: UNLICENSED
```

   **`targets` es obligatorio** y lista los runtimes elegidos en la fase 0 ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).
   - APM se salta un paquete cuyo `targets` no incluye el runtime activo, aunque se pase `--target` y aunque lo pida otro paquete.
   - El aviso es `Package targets [claude] do not overlap … skipping`, y no hay error.

2. **Declara las dependencias pineadas por SHA**, no por rama. Una rama cambia el contenido sin cambiar la declaración, y dos consumidores del mismo `apm.yml` resuelven artefactos distintos:

```yaml
dependencies:
  apm:
    - <owner>/<repo>#<sha-completo>
```

3. **Añade el bloque `marketplace` solo si este repo es el catálogo** (el agregador, no un paquete hoja). El marketplace es **solo de Claude Code**; Antigravity no lo usa. Qué produce `apm pack` a partir de él: [distribucion.md](../3-modelo-operativo/distribucion.md).

```yaml
marketplace:
  owner:
    name: <owner>
  packages:
    - name: mi-paquete
      source: <owner>/mi-paquete
      ref: <sha-completo>
      description: >-
        Resumen para el catálogo.
```

4. **Asume que APM no valida casi nada de tu frontmatter.** Valida un subconjunto pequeño; el resto pasa intacto ([skills.md#frontmatter-y-apm](../2-primitivos/skills.md#frontmatter-y-apm), [subagents.md#frontmatter-y-apm](../2-primitivos/subagents.md#frontmatter-y-apm)). Dónde aparece cada error:

   | Si te equivocas en… | En Claude Code | En Antigravity |
   |---|---|---|
   | `name` de una skill (formato o desajuste con el directorio) | `apm install` | `apm install` |
   | Longitud de `description` | `apm install` | `apm install` |
   | Formato de `color` de un agente | `apm install` | `apm install` |
   | `skills:` con un nombre inexistente | runtime | aprovisionador (post-install) |
   | En un agente: `tools:` sin traducción, `model` ≠ `inherit` o un campo solo de Claude (`color`, `effort`…) | — (Claude lo acepta) | aprovisionador (post-install) |
   | `context: fork`, `agent:`, `disable-model-invocation` | runtime | nunca: se ignoran (por eso la delegación va en el texto) |
   | `targets` sin el runtime | — | ningún sitio: el paquete no llega |

   Un `apm install` verde no dice nada de esos campos. Verificarlos es trabajo de la fase 7.

5. **No toques `apm.lock.yaml`.** Es generado; su papel en la trazabilidad se usa en la fase 8.

6. **Corre `apm install` en el propio repo** y comprueba que resuelve. Sin dependencias, solo valida la sintaxis del manifiesto y los `name`, que es lo que APM sí valida.

7. **Documenta en el README del paquete qué necesita quien instala** (paso siguiente).

## Qué documentar para quien instala

Si el paquete tiene agentes o hooks y se usará en Antigravity, quien lo instala tiene que añadir el aprovisionador a **su** `apm.yml`.

APM no ejecuta los `lifecycle` de los paquetes dependientes.

Por eso el bloque **no** puede ir en el `apm.yml` del paquete ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md), [distribucion-antigravity.md](../3-modelo-operativo/distribucion-antigravity.md)).

Fragmento para el README del paquete:

```yaml
# apm.yml del repo consumidor
targets: [claude, antigravity]
lifecycle:
  post-install:   [{type: command, command: "uv run -q --with pyyaml python apm_modules/myinvestor-core/ai-sdlc-shared-skills/.apm/hooks/scripts/provision_agents_antigravity.py --from-hook"}]
  post-update:    [{type: command, command: "uv run -q --with pyyaml python apm_modules/myinvestor-core/ai-sdlc-shared-skills/.apm/hooks/scripts/provision_agents_antigravity.py --from-hook"}]
  post-uninstall: [{type: command, command: "uv run -q --with pyyaml python apm_modules/myinvestor-core/ai-sdlc-shared-skills/.apm/hooks/scripts/provision_agents_antigravity.py --from-hook"}]
```

Y los pasos, en este orden:

1. Ejecutar `apm lifecycle trust` en el repo consumidor. Sin esa confianza, APM no ejecuta el `lifecycle`.
2. Tener `uv` en el PATH: el aprovisionador necesita PyYAML.
3. Instalar sin tokens en el entorno (`env -u GITHUB_TOKEN -u GITHUB_APM_PAT apm install …`).

Además, en Antigravity:
- los permisos de comandos solo son globales (`~/.gemini/antigravity-cli/settings.json`);
- no hay `env` de proyecto: las variables se exportan en la shell antes de `agy`.

Si el paquete depende de permisos o variables, documéntalo también ([runtime-antigravity.md](../2-primitivos/runtime-antigravity.md)).

## Reglas que aplican

- Qué es APM, `targets`, `lifecycle` y despliegue por runtime: [distribucion.md](../3-modelo-operativo/distribucion.md) · [distribucion.md#target-antigravity](../3-modelo-operativo/distribucion.md#target-antigravity).
- Qué campos valida APM: [skills.md#frontmatter-y-apm](../2-primitivos/skills.md#frontmatter-y-apm) · [subagents.md#frontmatter-y-apm](../2-primitivos/subagents.md#frontmatter-y-apm).
- `lifecycle` del consumidor y aprovisionador: [distribucion-antigravity.md](../3-modelo-operativo/distribucion-antigravity.md).
- Qué traduce el aprovisionador: [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md) · [0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md).
- Dos runtimes desde un origen: [0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md).
- Agregador que declara y no contiene: [0003](../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md).

## Salida

- `apm.yml` válido, con `targets`, dependencias pineadas por SHA y bloque `marketplace` solo si corresponde.
- Un `apm install` local que termina sin error.
- README del paquete con el `lifecycle` y los pasos para quien instala, si aplica.

## Errores comunes

- **Omitir un runtime en `targets`.** APM se salta el paquete en ese runtime sin dar error.
- **Poner el `lifecycle` del aprovisionador en el `apm.yml` del paquete.** APM no lo ejecuta: los agentes no se generan en el consumidor.
- **No documentar `apm lifecycle trust`.** El consumidor declara el `lifecycle`, APM no lo ejecuta y `.agents/agents/` queda vacío.
- **Pinear por rama o tag móvil.** Rompe la reproducibilidad sin cambiar el manifiesto.
- **Tratar un `apm install` verde como "el paquete está bien".** Solo cubre lo que APM valida.
- **Añadir el bloque `marketplace` en un paquete hoja.** El catálogo lo publica el agregador; duplicarlo genera dos catálogos que divergen.
- **Editar `apm.lock.yaml` a mano.** El arreglo va en `apm.yml` y se regenera.
