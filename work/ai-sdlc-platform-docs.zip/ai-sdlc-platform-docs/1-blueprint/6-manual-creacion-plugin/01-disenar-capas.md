# Fase 1 — Diseñar capas, roles, nombres y definición de hecho

## Objetivo

Producir en papel la tabla completa de artefactos del paquete (capa, rol, nombre y prohibiciones de cada uno) y la definición de hecho en cada runtime objetivo. Es la fase donde cae el gate humano.

## Precondición

Fase 0 cerrada, con los runtimes objetivo elegidos. Si salió "archivo suelto", esta fase se reduce a los pasos 2 y 4.

## Pasos

1. **Nombra las capas y su columna "qué NO contiene".** Sin esa columna la separación no es verificable ([jerarquía de capas](../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md)).
   - Si encaja en la convención de este repo (`agent` / `core` / `shared` / `tech` / `kb`), úsala ([topologia-repos.md](../3-modelo-operativo/topologia-repos.md)).

2. **Asigna un tipo a cada skill**: orquestadora, especialista o conocimiento pasivo ([tipos-de-skill](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md)).
   - Una skill con dos tipos son dos skills.
   - Por cada especialista, anota su enum cerrado de salida (severidad, categoría, veredicto). Se decide aquí, no al redactarla.
   - La skill de entrada, si la hay, se decide en la fase 2; aquí solo se reserva su fila.

3. **Describe el arquetipo de cada agente** en prosa libre ([arquetipos-de-agente](../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md)). De esa descripción sale la lista `tools:` que hace imposible violar el rol.
   - **Usa solo nombres traducibles:** `Read`, `Grep`, `Glob`, `LS`, `Bash`, `Write`, `Edit`, `WebFetch`, `WebSearch` y `Task`/`Agent` para delegar.
   - El aprovisionador de Antigravity falla con cualquier otro nombre ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)). `Skill` tampoco se traduce (fase 5).
   - El frontmatter se escribe en la fase 5.

4. **Nombra cada artefacto por su rol** ([convenciones-de-nombres](../4-buenas-practicas/1-diseno-de-agentes-y-skills/convenciones-de-nombres.md)). El error típico es de orden de palabras, no de casing.

5. **Declara las fases del agente y el modo de fallo de cada una** si la tarea es multipaso ([ciclo-de-vida-de-fases](../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md)).
   - Para cada fase "corregir y reintentar", anota el límite que expondrás como parámetro ([bucle de verificación](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md)).

6. **Escribe la definición de hecho del paquete**: condiciones verificables con herramienta ([definicion-de-hecho](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md)). Va aquí porque forma parte del plan del gate. Punto de partida mínimo:

   - `apm install` termina sin error en un consumidor de prueba **por cada runtime objetivo**.
   - Cada artefacto de la tabla existe en `.claude/` **y** en `.agents/` (los agentes, en `.agents/agents/`).
   - `provision_agents_antigravity.py --check` sale con 0.
   - La entrada elegida en la fase 2 responde **en cada runtime objetivo**.
   - Los hooks no bloquean `agy`: una herramienta normal funciona y el hook solo deniega lo que debe.
   - Cada skill de acción pasa los escenarios de su nivel de cobertura.
   - Ningún `SKILL.md` supera el umbral de tamaño del blueprint.

7. **Consolida todo en la tabla de artefactos planificados**, que es la salida de la fase:

   | Nombre | Primitivo | Capa | Tipo/Arquetipo | Qué NO contiene | Archivo fuente |
   |---|---|---|---|---|---|
   | … | `skill` \| `agente` \| `instruction` \| `hook` \| `mcp` | … | … | … | `.apm/…` |

8. **Presenta la tabla y la definición de hecho, y espera aprobación explícita.** Ningún archivo del paquete se escribe antes ([gate-antes-de-escribir](../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md)). Es un bloqueo, no una sugerencia.

## Reglas que aplican

- Capas y "qué NO contiene": [jerarquía de capas](../4-buenas-practicas/1-diseno-de-agentes-y-skills/jerarquia-de-capas-responsabilidad.md) · [0010](../5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md).
- Tipos de skill: [tipos-de-skill](../4-buenas-practicas/1-diseno-de-agentes-y-skills/tipos-de-skill.md) · [0002](../5-decisiones/1-diseno-de-agentes-y-skills/0002-taxonomia-de-tipos-de-skill.md).
- Arquetipos y `tools:`: [arquetipos-de-agente](../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md) · [0011](../5-decisiones/1-diseno-de-agentes-y-skills/0011-arquetipos-de-agente-por-forma.md).
- Traducción de `tools` a Antigravity: [subagents.md](../2-primitivos/subagents.md) · [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md) · [0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md).
- Nombres por rol: [convenciones-de-nombres](../4-buenas-practicas/1-diseno-de-agentes-y-skills/convenciones-de-nombres.md) · [0013](../5-decisiones/1-diseno-de-agentes-y-skills/0013-convenciones-de-nombres-por-rol.md).
- Fases y reintentos:
  - [ciclo-de-vida-de-fases](../4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md) · [0006](../5-decisiones/2-orquestacion/0006-ciclo-de-vida-fijo.md)
  - [bucle de verificación](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md) · [0016](../5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md).
- Definición de hecho: [definicion-de-hecho](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md) · [0015](../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md).
- Gate: [gate-antes-de-escribir](../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md) · [0005](../5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md).
- Hooks en los dos runtimes: [hooks-portables-entre-runtimes](../4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md) · [0022](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md).

## Salida

- Tabla de artefactos planificados (paso 7).
- Definición de hecho en cada runtime objetivo (paso 6).
- Fases y modos de fallo del agente, si aplica (paso 5).
- **Aprobación humana explícita** del conjunto.

## Errores comunes

- **Planificar un command o un prompt.** La columna "Primitivo" no los admite: están prohibidos.
- **Definición de hecho solo para Claude.** "Existe en `.claude/`" no dice nada de Antigravity. Cada condición se comprueba en cada runtime objetivo.
- **Poner en `tools:` un nombre sin traducción** (por ejemplo `Skill` o una herramienta MCP). En Claude funciona; en Antigravity el aprovisionador falla y el agente no se genera.
- **Saltar el paso 6.** La definición de hecho escrita después de implementar se acomoda a lo implementado.
- **Columna "qué NO contiene" genérica.** "No contiene lógica de otras capas" no es verificable. "No contiene reglas de Java" sí.
- **Decidir `tools:` en la fase 5.** La restricción es una decisión de diseño y pertenece al plan del gate.
- **Pasar el gate con la tabla incompleta.** Un artefacto que aparece en la fase 4 sin estar en la tabla no pasó por el gate.
