# Fase 0 — Paquete APM agnóstico o archivo suelto

## Objetivo

Decidir en qué runtimes tiene que funcionar el trabajo y, con eso, si hace falta un paquete APM agnóstico o basta un archivo suelto.

## Precondición

Ninguna. Es la primera fase. Solo hace falta poder describir en una frase qué debe hacer el artefacto y quién lo va a usar.

## Pasos

1. **Escribe en una frase el trabajo a resolver.** Si no cabe en una frase, abarca más de un paquete: divídelo y repite la fase 0 por cada parte.

2. **Elige los runtimes objetivo.** Por defecto, `claude` + `antigravity`. Quita uno solo si hay un motivo escrito (por ejemplo, el trabajo solo corre en CI con `claude-code-action`).
   - La lista se declara en `targets` en la fase 6 ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).

3. **Elige los primitivos** contra la "Tabla resumen de uso" del [README del blueprint](../README.md). Solo hay cinco opciones: skill, agente, `instruction`, hook y MCP.
   - Command y prompt **no son una opción**: están prohibidos ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).
   - Lo que una persona teclea con `/` es una skill de entrada (fase 2).

4. **Aplica el árbol de decisión.** Las preguntas van de más restrictiva a menos.

```mermaid
flowchart TD
    Q0{"¿Más de un<br/>runtime objetivo?"}
    Q0 -- "sí" --> APM["Paquete APM agnóstico<br/>(aunque sea un solo repo)<br/>continúa en fase 1"]
    Q0 -- "no, uno solo" --> Q1{"¿Más de un artefacto<br/>cohesivo?<br/>(agente + skills, skills + hooks)"}
    Q1 -- "no, es uno solo" --> A1["Archivo suelto en el<br/>directorio de ese runtime<br/>FIN"]
    Q1 -- "sí" --> Q2{"¿Se consume desde<br/>más de un repo?"}
    Q2 -- "no" --> A2["Carpeta del runtime<br/>en ese repo<br/>FIN"]
    Q2 -- "sí" --> Q3{"¿Hace falta versión propia,<br/>resolución transitiva<br/>o catálogo?"}
    Q3 -- "no" --> A3["Copia controlada o submodule<br/>FIN — sin APM"]
    Q3 -- "sí" --> APM

    style APM fill:#e2f6e2,stroke:#27ae60
    style A1 fill:#eee,stroke:#888
    style A2 fill:#eee,stroke:#888
    style A3 fill:#eee,stroke:#888
```

   - **Más de un runtime → siempre APM.** APM es la única fuente que despliega el mismo origen en `.claude/` y en `.agents/`. Un archivo suelto vive en el directorio de un solo runtime.
   - Las salidas "FIN" solo existen con **un** runtime.

5. **Si el árbol termina en "FIN", para aquí.** Un `SKILL.md` suelto es un artefacto completo, no un paquete a medias. Para redactarlo, salta a [04-escribir-skills.md](04-escribir-skills.md) e ignora las fases 3, 6 y 8.

6. **Si sale "paquete APM agnóstico", registra el porqué** en una línea: los runtimes objetivo, o el reuso entre repos. Esa línea justifica el coste de las fases 6 y 8 (versión, pin de SHA, bump en consumidores, `lifecycle` en el consumidor).

## Reglas que aplican

- Cuándo usar cada primitivo: [README del blueprint](../README.md) (tabla resumen).
- Qué despliega APM en cada runtime: [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md) y [distribucion.md](../3-modelo-operativo/distribucion.md).
- Por qué no commands ni prompts: [0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md) y [puntos-de-entrada-como-skills](../4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md).
- Soporte de dos runtimes desde un origen: [0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md).
- Cuándo no hace falta empaquetar: [plugins.md](../2-primitivos/plugins.md).

## Salida

Los runtimes objetivo y una de estas salidas, escritas antes de pasar a la fase 1:

| Resultado | Siguiente paso |
|---|---|
| Archivo suelto (una skill o un agente, **un** runtime) | [04-escribir-skills.md](04-escribir-skills.md) o [05-escribir-agentes.md](05-escribir-agentes.md), nada más |
| Carpeta de **un** runtime en un solo repo | Fases 1, 2, 4, 5 y 7; sin 3, 6 ni 8 |
| Paquete sin APM (**un** runtime) | Todas las fases menos la 6 |
| Paquete APM agnóstico | Todas las fases |

## Errores comunes

- **Crear un command o un prompt.** Están prohibidos: un `/nombre` en `.claude/commands/` o `.apm/prompts/` no llega a Antigravity, y no hay error. Se escribe como skill.
- **Dar por hecho que solo existe Claude.** Si no eliges los runtimes aquí, la fase 6 declara `targets: [claude]` por inercia y el paquete no llega a Antigravity.
- **Archivo suelto para dos runtimes.** Obliga a mantener dos copias (`.claude/` y `.agents/`) que divergen. Con más de un runtime, siempre APM.
- **Empezar por la estructura de directorios.** El layout es la fase 3; decidirlo antes fija el resultado del árbol sin recorrerlo.
- **Paquete de una sola skill "por si luego crece"**, con un solo runtime. El envoltorio añade versión, pin y bump. Si crece, se envuelve entonces.
