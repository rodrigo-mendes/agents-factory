# Manual de creación de un paquete agnóstico

> **Para quién:** quien crea un paquete de agentes y skills para la plataforma.
> **Qué responde:** en qué orden se toman las decisiones para que el paquete funcione en todos sus runtimes objetivo (hoy, Claude Code y Antigravity).

El resto del blueprint dice:

- **qué** es cada primitivo ([primitivos](../2-primitivos/));
- **cómo** se distribuye y ejecuta ([modelo operativo](../3-modelo-operativo/));
- **cómo** se aplica cada patrón ([buenas prácticas](../4-buenas-practicas/));
- y **por qué** se decidió así ([decisiones](../5-decisiones/)).

Este manual añade la **secuencia**.

## Regla de partida

Un paquete agnóstico se construye **solo con skills y agentes**, más `instructions`, hooks y MCP.

- **Commands y prompts están prohibidos.** No todos los harnesses los soportan ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md), [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity)).
- Todo `/nombre` que teclea una persona es una **skill de entrada**.
- La delegación en un agente se pide **en el texto** de la skill ([0023](../5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)).

Detalle en [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).

## Principio de lectura

**Este manual no repite ninguna regla.** Cada paso dice *qué decidir* y *cuándo*, y enlaza al archivo que define la regla. Si un paso parece incompleto, el enlace es la parte que falta.

Para quien edite el manual: si falta una regla normativa, se crea en [buenas prácticas](../4-buenas-practicas/) **con su ADR** en [decisiones](../5-decisiones/). Aquí solo se enlaza.

## Las 9 fases

| Fase | Qué se decide | Detalle |
|---|---|---|
| 0 | ¿Paquete APM o archivo suelto? ¿En qué runtimes? | [00-decidir-primitivo.md](00-decidir-primitivo.md) |
| 1 | Capas, tipos de skill, nombres y definición de hecho, en papel | [01-disenar-capas.md](01-disenar-capas.md) |
| 2 | Cómo se invoca y dónde corre | [02-elegir-entrypoint.md](02-elegir-entrypoint.md) |
| 3 | Layout en disco: qué es fuente y qué es generado | [03-estructura-en-disco.md](03-estructura-en-disco.md) |
| 4 | Redactar cada `SKILL.md`, incluida la skill de entrada | [04-escribir-skills.md](04-escribir-skills.md) |
| 5 | Redactar cada `*.agent.md` | [05-escribir-agentes.md](05-escribir-agentes.md) |
| 6 | Declarar `apm.yml` y lo que necesita quien instala | [06-declarar-apm.md](06-declarar-apm.md) |
| 7 | Probar en cada runtime contra la definición de hecho | [07-probar.md](07-probar.md) |
| 8 | Publicar: común, Claude y Antigravity | [08-empaquetar-publicar.md](08-empaquetar-publicar.md) |
| — | Apéndice: paquete de ejemplo completo | [apendice-ejemplo.md](apendice-ejemplo.md) |

```mermaid
flowchart TD
    F0["Fase 0<br/>¿paquete APM? ¿runtimes?"] --> F1["Fase 1<br/>diseño en papel<br/>+ definición de hecho"]
    F1 --> GATE{"Gate humano<br/>plan aprobado"}
    GATE -- "no" --> F1
    GATE -- "sí" --> F2["Fase 2<br/>cómo se invoca y dónde corre"]
    F2 --> F3["Fase 3<br/>layout en disco"]
    F3 --> F4["Fase 4<br/>escribir skills"]
    F3 --> F5["Fase 5<br/>escribir agentes"]
    F4 --> F6["Fase 6<br/>apm.yml + lifecycle del consumidor"]
    F5 --> F6
    F6 --> F7["Fase 7<br/>probar en cada runtime"]
    F7 -- "no cumple<br/>(bucle acotado)" --> F4
    F7 -- "cumple" --> F8["Fase 8<br/>publicar"]

    F0 -- "un solo runtime<br/>y no hace falta paquete" --> OUT["archivo suelto<br/>en un runtime<br/>fin"]

    style GATE fill:#fff4e2,stroke:#d68910
    style OUT fill:#eee,stroke:#888
```

El gate tras la fase 1 no es decorativo: **no se escribe ningún archivo antes de que el plan esté aprobado** ([gate-antes-de-escribir](../4-buenas-practicas/3-control-y-calidad/gate-antes-de-escribir.md)). Las fases 4 y 5 son independientes y pueden hacerse en cualquier orden.

## Matriz: qué decisión se toma en qué fase

Sirve para volver atrás: si una decisión está mal, este es el sitio donde se tomó.

| Decisión | Fase | No se decide en |
|---|---|---|
| Paquete APM agnóstico vs. archivo suelto (el archivo suelto solo vale para **un** runtime) | 0 | — |
| Runtimes objetivo (`targets`; por defecto `claude` + `antigravity`) | 0 | 6 (la 6 solo los *declara*) |
| Primitivas permitidas: `skill`, `agente`, `instruction`, `hook`, `mcp` | 1 | — (commands y prompts, prohibidos) |
| Qué capas existen y qué **no** contiene cada una | 1 | 3 |
| Tipo de cada skill (orquestadora / especialista / conocimiento) | 1 | 4 |
| Nombre de cada artefacto | 1 | 4, 5 |
| Arquetipo y `tools:` de cada agente, solo con nombres traducibles | 1 (arquetipo) / 5 (se escribe) | — |
| Definición de hecho en **cada** runtime objetivo | 1 | 7 (la 7 solo *mide*) |
| ¿Hay skill de entrada `/nombre`? | 2 | 4 |
| ¿Dónde corre? (dentro de un agente o inline) | 2 | 4, 5 |
| Cómo delega la skill de entrada (frontmatter **y** texto) | 2 (se decide) / 4 (se escribe) | — |
| Router y cap de fan-out | 2 | 5 |
| Frenos a la activación automática (`disable-model-invocation` y `description`) | 4 | — |
| Bloque `antigravity:` del agente, si hace falta | 5 | — |
| Límite de reintentos por fase del agente | 5 | — |
| Pin de SHA de las dependencias | 6 | — |
| Qué documentar para quien instala (`lifecycle` + `apm lifecycle trust`) | 6 | 8 |
| Versión publicada; marketplace (solo Claude); validación con install real en Antigravity | 8 | — |

## Contrato de forma de cada fase

Igual que en [buenas prácticas](../4-buenas-practicas/README.md), las 9 fases comparten estructura:

- **Objetivo**: una frase.
- **Precondición**: qué debe estar listo de la fase anterior.
- **Pasos**: numerados e imperativos.
- **Reglas que aplican**: enlaces cortos, sin reexplicar la regla.
- **Salida**: artefacto o decisión verificable.
- **Errores comunes**: solo los propios de la secuencia.
