# Fase 7 — Probar en cada runtime contra la definición de hecho

## Objetivo

Comprobar con herramienta, condición por condición y en cada runtime objetivo, la definición de hecho de la fase 1, antes de publicar nada.

## Precondición

Fases 4, 5 y (si aplica) 6 completas. La definición de hecho de la fase 1 a la vista: esta fase la mide, no la escribe.

## Pasos

1. **Prepara un consumidor de prueba por runtime objetivo**, no el repo fuente: un directorio limpio con un [`apm.yml`](../3-modelo-operativo/distribucion.md) que declare el paquete como dependencia.
   - Para Antigravity, ese `apm.yml` lleva `targets` con `antigravity` y el `lifecycle` del aprovisionador, con `apm lifecycle trust` ([06-declarar-apm.md](06-declarar-apm.md#qué-documentar-para-quien-instala)).
   - Es la única forma de ejercitar la resolución real que verá un consumidor, incluido el README del paquete.

2. **Instala sin tokens en el entorno** (`env -u GITHUB_TOKEN -u GITHUB_APM_PAT apm install …`) y verifica lo desplegado con herramienta, no de memoria ([verificar-no-confiar-en-memoria](../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md)). Usa el checklist de abajo.

3. **Ejercita la salida elegida en la fase 2, en cada runtime:**

   | Salida | Cómo se prueba | Qué confirmar en Claude Code | Qué confirmar en Antigravity |
   |---|---|---|---|
   | Skill de entrada → agente | `/<entrada> <args>`; también sin argumentos | El fork corre dentro del agente; el caller solo recibe el resultado | El agente principal delega con `invoke_subagent` (panel `/agents`); si no puede, se detiene y lo dice |
   | Agente por `description` | Describir la tarea en lenguaje natural | El matching resuelve el agente correcto | El planificador delega en el agente correcto |
   | Skill inline | `/<skill> <args>` | El trabajo intermedio queda en el contexto | Igual |

   Las tres salidas, con `-p`, también deben funcionar en modo headless (`claude -p`, `agy -p`). Comportamiento esperado: [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).

4. **Corre los escenarios de cada skill de acción** declarados en la fase 4, los del nivel de cobertura de la skill y los hostiles si le tocan ([testing-de-skills-con-escenarios](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md)): secuencial, cada corrida independiente y veredicto con evidencia del output real.
   - Los modelos son distintos en cada runtime: córrelos en los dos.

5. **Comprueba las restricciones estructurales de los agentes.**
   - Que un agente asesor no pueda escribir no se prueba leyendo su prompt: se le pide que escriba y se confirma que no tiene la herramienta.
   - Igual con el guard de fan-out y con el límite de reintentos, que debe agotarse y **reportar** el estado no resuelto ([bucle de verificación](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md)).

6. **Marca cada condición de la definición de hecho como cumplida o no**, por runtime y con la evidencia al lado ([definicion-de-hecho](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md)).

7. **Si algo no cumple, vuelve a la fase 4 o 5 y repite**, con el bucle acotado por el mismo límite de reintentos. Al agotarlo, se reporta el estado no resuelto o se escala a humano. **No se pasa a la fase 8** con pendientes sin declarar.

### Checklist común

- [ ] `apm install` termina sin error en cada consumidor.
- [ ] `apm audit` sale con 0 (en Antigravity, el *drift* de `.agents/hooks.json` es esperado).
- [ ] Cada artefacto de la tabla de la fase 1 está desplegado en cada runtime.
- [ ] La salida de la fase 2 responde en cada runtime, con argumentos y sin ellos.
- [ ] Los escenarios pasan en cada runtime.

### En Claude Code

```bash
ls .claude/agents/ .claude/skills/          # todo lo planificado existe
ls .claude/skills/*/                        # archivos de soporte incluidos
claude -p "/<entrada> <args>"               # la entrada responde en modo headless
```

- [ ] Los campos que APM no valida (`skills:`, `context: fork`, `agent:`, `disable-model-invocation`) están bien en el archivo desplegado: léelo, no lo supongas ([06-declarar-apm.md](06-declarar-apm.md)).
- [ ] La skill de entrada no aparece activada por el modelo sin que nadie la pida.

### En Antigravity

```bash
ls .agents/skills/ .agents/rules/ .agents/agents/
uv run -q --with pyyaml python apm_modules/myinvestor-core/ai-sdlc-shared-skills/.apm/hooks/scripts/provision_agents_antigravity.py --check
agy -p "hola" --agent <agente>              # el agente generado responde
agy -p "/<entrada> <args>"                  # la entrada responde y delega
```

- [ ] `.agents/agents/<agente>.md` existe y lo generó el `lifecycle`, no una ejecución a mano.
- [ ] `provision_agents_antigravity.py --check` sale con 0.
- [ ] `agy -p … --agent <agente>` responde (`agy agents` no lista los agentes de proyecto; es normal).
- [ ] Los hooks no bloquean: una herramienta normal funciona y el hook solo deniega lo que debe ([hooks-portables-entre-runtimes](../4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md)).
- [ ] La delegación ocurre: el subagente aparece en `/agents` y el resultado es el mismo que en Claude.
- [ ] La `description` de la skill de entrada y de las skills pasivas frena la activación automática.

### Referencia: las demos

La revisión de PRs recorre este checklist completo en los dos runtimes:
- Claude Code: [demo-pr-review](../../../out-git/demo-pr-review/README.es.md) (paso 3, instalación y comprobaciones);
- Antigravity: [demo-pr-review-agy](../../../out-git/demo-pr-review-agy/README.es.md) (paso 3; "Problemas comunes" para los fallos típicos).

## Reglas que aplican

- Medir contra lista verificable: [definicion-de-hecho](../4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md) · [0015](../5-decisiones/3-control-y-calidad/0015-definicion-de-hecho.md).
- Reverificar con herramienta: [verificar-no-confiar-en-memoria](../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md) · [0014](../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md).
- Escenarios: [testing-de-skills-con-escenarios](../4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md) · [0009](../5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md).
- Bucle acotado: [bucle de verificación](../4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md).
- Comportamiento de cada salida por runtime: [modelo-ejecucion.md](../3-modelo-operativo/modelo-ejecucion.md).
- Qué despliega `apm install` y dónde: [distribucion.md](../3-modelo-operativo/distribucion.md).
- Hooks en los dos runtimes: [hooks-portables-entre-runtimes](../4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md) · [0022](../5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md).

## Salida

La definición de hecho de la fase 1, condición por condición y runtime por runtime, con veredicto y evidencia. Cualquier condición no cumplida queda declarada, no omitida.

## Errores comunes

- **Probar solo en Claude Code.** Lo que falla en Antigravity (delegación, aprovisionador, hooks) falla sin error visible.
- **Generar los agentes de Antigravity a mano.** Oculta que el `lifecycle` no funciona, que es justo lo que verá el consumidor.
- **Dar por buena la delegación porque la revisión terminó.** En Antigravity, sin las dos secciones de texto, el trabajo corre en el agente principal sin el agente. Confirma que el subagente aparece.
- **Probar en el repo fuente.** Ahí `.claude/` y `.agents/` pueden tener restos de instalaciones previas.
- **Correr los escenarios en paralelo.** Se contaminan entre sí.
- **Veredicto impresionista.** "Se ve bien" no es un veredicto: hay que señalar qué parte del output cumple cada criterio.
- **Dar por buenos los campos que APM no valida** porque el install fue verde.
- **Pasar a la fase 8 con pendientes sin declarar.** Publicar convierte un pendiente conocido en uno invisible.
