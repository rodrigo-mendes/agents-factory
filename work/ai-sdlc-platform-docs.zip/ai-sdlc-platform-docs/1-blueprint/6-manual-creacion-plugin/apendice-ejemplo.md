# Apéndice — paquete agnóstico de ejemplo, de principio a fin

> **Para quién:** quien quiere ver las 9 fases aplicadas a un caso completo y copiable.
> **Qué responde:** qué archivos se escriben, cuáles se generan y qué se prueba en cada runtime.

Paquete **inventado para este apéndice**: `ai-sdlc-tech-openapi`, un revisor de contratos OpenAPI. No documenta ningún repo existente; es una plantilla. Para el estado real de los repos, ver [topologia-repos.md](../3-modelo-operativo/topologia-repos.md).

Cubre en un solo recorrido:
- un agente con `tools:` traducibles y fases con modo de fallo;
- una skill especialista con enum cerrado;
- una skill de conocimiento pasivo;
- la **skill de entrada** `/revisar-openapi`, que delega en el agente desde su texto;
- `apm.yml` con `targets: [claude, antigravity]` y el `lifecycle` que necesita quien instala;
- lo desplegado en `.claude/` y en `.agents/`, y las pruebas en los dos runtimes.

## Fase 0 — decisión

- Runtimes objetivo: Claude Code y Antigravity. Con más de un runtime, siempre APM.
- Tres artefactos cohesivos más la entrada, consumidos desde varios repos de backend, con versión propia.

Árbol de [00-decidir-primitivo.md](00-decidir-primitivo.md): **paquete APM agnóstico**.

## Fase 1 — tabla de artefactos

| Nombre | Primitivo | Capa | Tipo/Arquetipo | Qué NO contiene | Archivo fuente |
|---|---|---|---|---|---|
| `revisar-openapi` | skill | Agentes | Skill de entrada | Lógica propia o reglas de OpenAPI | `.apm/skills/revisar-openapi/SKILL.md` |
| `openapi-reviewer` | agente | Agentes | Orquesta el análisis y escribe el informe final (descripción libre según [arquetipos-de-agente](../4-buenas-practicas/1-diseno-de-agentes-y-skills/arquetipos-de-agente.md)) | Reglas de OpenAPI (viven en las skills) | `.apm/agents/openapi-reviewer.agent.md` |
| `openapi-contract-review` | skill | Tech | Especialista | Lógica de flujo; decisiones de orden | `.apm/skills/openapi-contract-review/SKILL.md` |
| `documenting-openapi-conventions` | skill | Conocimiento | Conocimiento pasivo | Cualquier frase de acción en su `description` | `.apm/skills/documenting-openapi-conventions/SKILL.md` |

- Enum cerrado de la especialista: `severity: blocker | major | minor | advice` · `dimension: naming | versioning | errors | security`.
- `tools:` del agente, solo traducibles: `Read, Glob, Grep, Write`.

### Definición de hecho

1. `apm install` termina sin error en un consumidor de prueba de Claude Code y en otro de Antigravity.
2. Los 4 artefactos existen en `.claude/` y en `.agents/`; el agente, en `.agents/agents/` generado por el `lifecycle`.
3. `provision_agents_antigravity.py --check` sale con 0.
4. `/revisar-openapi <ruta>` devuelve, **en los dos runtimes**, hallazgos con `severity` y `dimension` dentro del enum.
5. En Antigravity, `/revisar-openapi` delega en `openapi-reviewer` (se ve en `/agents`).
6. `openapi-contract-review` pasa sus 3 escenarios en los dos runtimes.
7. Ningún `SKILL.md` supera el umbral de tamaño del blueprint.
8. En una sesión que no menciona `documenting-openapi-conventions`, las trazas confirman que la skill no se activa sola.

## Fase 2 — cómo se invoca y dónde corre

- Una persona teclea `/revisar-openapi`, y el trabajo intermedio es ruido para el caller: **skill de entrada → agente**.
- La skill delega en `openapi-reviewer` con `context: fork` + `agent:` (Claude) **y** en su texto (Antigravity).
- Sin efectos externos: escribe un informe local, no publica.
- Sin router (un solo agente). Sin fan-out.

## Fase 4 — `.apm/skills/revisar-openapi/SKILL.md` (skill de entrada)

```markdown
---
name: revisar-openapi
description: Revisa contratos OpenAPI con el agente openapi-reviewer y escribe un informe consolidado. Úsala solo cuando el usuario lo pida explícitamente (p. ej. "/revisar-openapi <ruta-o-glob>"). Argumento: ruta o glob de los ficheros; si falta, todos los *.yaml de openapi/.
argument-hint: <ruta-o-glob>
context: fork
agent: openapi-reviewer
disable-model-invocation: true
---

<user_request>
$ARGUMENTS
</user_request>

## Si no eres ya el agente `openapi-reviewer`
Delega toda la petición, con <user_request> literal, en el subagente `openapi-reviewer` y espera su informe.
No apliques reglas de OpenAPI tú: solo ese agente conoce el catálogo.
Si no puedes delegar, detente y dilo; no revises sin el agente.

## Si eres el agente `openapi-reviewer`
Revisa los ficheros indicados en <user_request>.
Si <user_request> está vacío, revisa todos los `*.yaml` de `openapi/`.
Devuelve el informe tal cual, sin resumirlo.
```

- En Claude, el fork ejecuta la skill dentro del agente: entra por la segunda sección.
- En Antigravity, la skill corre en el agente principal: entra por la primera sección y delega con `invoke_subagent`.
- La `description` es el freno en Antigravity, donde `disable-model-invocation` se ignora.
- Las dos skills internas no tienen entrada propia: nadie las teclea.

## Fase 5 — `.apm/agents/openapi-reviewer.agent.md`

```markdown
---
name: openapi-reviewer
description: >-
  Revisa uno o varios contratos OpenAPI y devuelve un informe consolidado de
  hallazgos. Recibe rutas de ficheros de especificación; devuelve solo el
  informe final, no el proceso de revisión.
tools: Read, Glob, Grep, Write
model: inherit
skills:
  - openapi-contract-review
---

# openapi-reviewer

Orquesta la revisión de contratos OpenAPI. No conoce ninguna regla de OpenAPI:
todas viven en `openapi-contract-review`, que se precarga vía `skills:`.

## Parámetros

| Parámetro | Default | Uso |
|---|---|---|
| `maxReadRetries` | 3 | Reintentos por fichero ilegible antes de reportar el hallazgo degradado |

## Fases

| Fase | Qué hace | Modo de fallo |
|---|---|---|
| Verificar | Resuelve las rutas recibidas y comprueba que cada fichero existe y parsea | Abortar si ninguna ruta resuelve |
| Analizar | Aplica `openapi-contract-review` a cada fichero | Corregir y reintentar, hasta `maxReadRetries` por fichero |
| Consultar | Lee por ruta `../documenting-openapi-conventions/conventions.md` cuando un hallazgo necesita contexto | No bloqueante: registra que el contexto no estaba disponible |
| Consolidar | Agrupa hallazgos por `dimension`, ordena por `severity` | Abortar si algún hallazgo trae un valor fuera del enum |
| Validar | Comprueba la definición de hecho con herramienta, no de memoria | Corregir y reintentar; al agotar `maxReadRetries`, reportar los ficheros no revisados con `severity: advice` |

Un intento de lectura vacío o fallido consume uno de los `maxReadRetries`. Al
agotarlos, el fichero se reporta como no revisado; nunca se omite en silencio.

## Guardrails

### Siempre
- Contar los ficheros revisados con `ls`/`grep` en el momento de escribir el
  informe, nunca a partir de un informe anterior.
- Emitir `severity` y `dimension` solo con valores del enum de la skill.

### Preguntar primero
- Antes de escribir el informe en una ruta que ya existe.

### Nunca
- Editar el contrato revisado.
  ❌ `Edit openapi.yaml` para "arreglar" un hallazgo: el agente revisa, no corrige;
  un cambio de contrato es una decisión del equipo dueño de la API.
  ✅ Reportar el hallazgo con la corrección propuesta en el informe.
```

Por qué este frontmatter:
- `tools:` no incluye `Task`/`Agent`: el agente no delega, y el frontmatter lo hace imposible.
- No incluye `Skill`, que no tiene traducción a Antigravity. `openapi-contract-review` va precargada por `skills:` y el conocimiento se lee por ruta con `Read`.
- Sin `effort` ni `color`: el aprovisionador no los traduce y fallaría.
- `model: inherit`, el único valor que el aprovisionador acepta.

## Fase 4 — `.apm/skills/openapi-contract-review/SKILL.md`

```markdown
---
name: openapi-contract-review
description: >-
  Aplica el checklist de contrato OpenAPI sobre el contenido de un fichero de
  especificación y devuelve hallazgos con severity y dimension de enum cerrado.
  Invocada por openapi-reviewer para cada fichero en alcance.
allowed-tools: Read, Grep
---

# Checklist de contrato OpenAPI

## Salida

Cada hallazgo: `{path, line, dimension, severity, rule, evidence, fix}`.

- `dimension`: `naming` | `versioning` | `errors` | `security`
- `severity`: `blocker` | `major` | `minor` | `advice`

Los dos son enums cerrados fijados en la definición de cada regla de abajo. No
se eligen al aplicar la regla.

## Reglas

| ID | Regla comprobable | dimension | severity |
|---|---|---|---|
| `OA-01` | Cada `path` usa sustantivos en plural y kebab-case | naming | minor |
| `OA-02` | Cada operación declara `operationId` único en el documento | naming | major |
| `OA-03` | La versión mayor aparece en el `path` base (`/v1/...`) | versioning | major |
| `OA-04` | Ningún campo requerido se añade a un request body existente | versioning | blocker |
| `OA-05` | Cada operación declara al menos una respuesta `4xx` | errors | major |
| `OA-06` | Las respuestas de error usan un único schema común | errors | minor |
| `OA-07` | Ninguna operación devuelve datos personales sin marcarlos en el schema | security | blocker |
| `OA-08` | Cada operación no pública declara `security` | security | blocker |

Contexto de convención de cada regla: `../documenting-openapi-conventions/conventions.md`,
leído por ruta solo cuando un hallazgo lo necesita.

## Escenarios

| # | Query | Comportamiento esperado | Criterios de éxito |
|---|---|---|---|
| 1 | Spec con `/Users` y sin `operationId` | 2 hallazgos: `OA-01` minor, `OA-02` major | Cita la línea de cada uno; no inventa reglas fuera de la tabla |
| 2 | Spec correcta con `/v1/orders`, `operationId`, `4xx` y `security` | 0 hallazgos | No degrada a "advice genérico" para tener algo que reportar |
| 3 | Spec que devuelve `email` sin marcar y sin `security` | 2 hallazgos blocker: `OA-07`, `OA-08` | `severity: blocker` exacto, no "alta"/"crítica" |
```

`allowed-tools` restringe la skill en Claude; Antigravity lo ignora. La restricción que vale en los dos runtimes es el `tools:` del agente que la ejecuta.

## Fase 4 — `.apm/skills/documenting-openapi-conventions/SKILL.md`

```markdown
---
name: documenting-openapi-conventions
description: >-
  Documento de referencia de convenciones OpenAPI del equipo. No es un
  procedimiento y no resuelve ninguna tarea por sí solo: solo lo leen por ruta
  openapi-contract-review y openapi-reviewer cuando un hallazgo necesita contexto.
disable-model-invocation: true
---

# Conocimiento de contratos OpenAPI

Índice de los documentos de este directorio, leídos por ruta, nunca de una vez:

| Documento | Contenido |
|---|---|
| `conventions.md` | Convención de naming, versionado y contrato de errores del equipo |
| `sensitive-fields.md` | Catálogo de campos considerados datos personales |
| `adrs/` | Decisiones de contrato ya tomadas, por si un hallazgo las contradice |
```

- La `description` no tiene ninguna frase de acción ("usa esto para", "aplica cuando").
- En Claude, además, `disable-model-invocation: true` impide que el modelo la active.
- En Antigravity ese campo se ignora: **la `description` es el único freno**, y la skill aparece en el menú `/`.
- No lleva `context: fork` porque no es una entrada: solo se lee por ruta.

## Fase 6 — `apm.yml`

```yaml
# Schema: https://github.com/microsoft/apm/blob/main/docs/src/content/docs/reference/manifest-schema.md
name: ai-sdlc-tech-openapi
version: 0.1.0
description: >-
  Revisión de contratos OpenAPI - consume {path, content} de uno o varios
  ficheros de especificación y devuelve {findings} con severity y dimension
  de enum cerrado. Sin noción de PR ni de repositorio concreto.
targets:
  - claude
  - antigravity
dependencies:
  apm: []
license: UNLICENSED
```

Sin bloque `marketplace`: es un paquete hoja. El alta en el catálogo de Claude va en el `apm.yml` del agregador (fase 8).

### Lo que documenta el README del paquete para quien instala

El paquete tiene un agente, así que en Antigravity el consumidor necesita el aprovisionador en **su** `apm.yml`:

```yaml
targets: [claude, antigravity]
dependencies:
  apm:
    - <owner>/ai-sdlc-tech-openapi#<sha-completo>
lifecycle:
  post-install:   [{type: command, command: "uv run -q --with pyyaml python apm_modules/myinvestor-core/ai-sdlc-shared-skills/.apm/hooks/scripts/provision_agents_antigravity.py --from-hook"}]
  post-update:    [ …igual… ]
  post-uninstall: [ …igual… ]
```

Y después:
1. `apm lifecycle trust`;
2. `env -u GITHUB_TOKEN -u GITHUB_APM_PAT apm install`.

El aprovisionador llega con `ai-sdlc-shared-skills` en `apm_modules/`. El consumidor tiene que instalar también ese paquete si aún no lo hace ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

## Fase 7 — qué queda desplegado y cómo se prueba

En Claude Code:

```
.claude/agents/openapi-reviewer.md              # el sufijo .agent desaparece al desplegar
.claude/skills/revisar-openapi/SKILL.md         # la skill de entrada
.claude/skills/openapi-contract-review/SKILL.md
.claude/skills/documenting-openapi-conventions/SKILL.md
```

En Antigravity:

```
.agents/agents/openapi-reviewer.md              # lo genera el aprovisionador, no APM
.agents/skills/revisar-openapi/SKILL.md
.agents/skills/openapi-contract-review/SKILL.md
.agents/skills/documenting-openapi-conventions/SKILL.md
```

Frontmatter de `.agents/agents/openapi-reviewer.md` tras la traducción:

```yaml
name: openapi-reviewer
description: Revisa uno o varios contratos OpenAPI y devuelve un informe consolidado…
tools: [view_file, find_by_name, grep_search, write_to_file]
model: inherit
skills: [../skills/openapi-contract-review]
```

El nombre de archivo cambia entre fuente (`<name>.agent.md`) y despliegue (`<name>.md`). El campo `name` no cambia, y es el que se usa para referirse al agente.

Pruebas:

| Prueba | Claude Code | Antigravity |
|---|---|---|
| Artefactos | `ls .claude/agents/ .claude/skills/` | `ls .agents/agents/ .agents/skills/` + `provision_agents_antigravity.py --check` = 0 |
| Agente | — | `agy -p "hola" --agent openapi-reviewer` responde |
| Entrada | `claude -p "/revisar-openapi openapi/orders.yaml"` | `agy -p "/revisar-openapi openapi/orders.yaml"`; el subagente aparece en `/agents` |
| Entrada sin argumentos | revisa `openapi/*.yaml` | igual |
| Escenarios 1–3 | pasan | pasan |
| Skill pasiva | no se activa sola | no se activa sola (solo depende de la `description`) |

## Fase 8 — bundle **generado** (solo Claude)

Salida de `apm pack`. **No se edita ni se versiona como fuente**; se muestra para saber qué esperar:

```
build/ai-sdlc-tech-openapi-0.1.0/
  plugin.json                                   # sintetizado desde apm.yml
  apm.lock.yaml                                 # embebido
  agents/openapi-reviewer.agent.md
  skills/revisar-openapi/SKILL.md
  skills/openapi-contract-review/SKILL.md
  skills/documenting-openapi-conventions/SKILL.md
```

`plugin.json` sale con los campos que `apm.yml` declara, nada más:

```json
{
  "name": "ai-sdlc-tech-openapi",
  "version": "0.1.0",
  "description": "Revisión de contratos OpenAPI - consume {path, content} de uno o varios ficheros de especificación y devuelve {findings} con severity y dimension de enum cerrado. Sin noción de PR ni de repositorio concreto.",
  "license": "UNLICENSED"
}
```

En Antigravity no hay bundle: la versión publicada se valida con un `apm install --target antigravity` real ([08-empaquetar-publicar.md](08-empaquetar-publicar.md)).

## Recorrido inverso — qué fase produjo cada archivo

| Archivo | Fase | Fuente o generado |
|---|---|---|
| `apm.yml` | 6 | Fuente |
| `.apm/skills/revisar-openapi/SKILL.md` | 4 (decidido en 2) | Fuente |
| `.apm/agents/openapi-reviewer.agent.md` | 5 | Fuente |
| `.apm/skills/openapi-contract-review/SKILL.md` | 4 | Fuente |
| `.apm/skills/documenting-openapi-conventions/SKILL.md` + documentos de soporte | 4 | Fuente |
| README del paquete (sección para quien instala) | 6 | Fuente |
| `.claude/agents/`, `.claude/skills/` del consumidor | 7 | Generado por `apm install` |
| `.agents/skills/` del consumidor | 7 | Generado por `apm install` |
| `.agents/agents/` del consumidor | 7 | Generado por el aprovisionador (`lifecycle`) |
| `build/.../plugin.json` | 8 | Generado por `apm pack` (solo Claude) |
| `apm.lock.yaml` | 6/7 | Generado |
