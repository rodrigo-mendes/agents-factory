# Fase 8 — Empaquetar y publicar

## Objetivo

Publicar una versión del paquete que llegue a cada runtime objetivo, darla de alta en el catálogo de Claude y dejar registrada la trazabilidad.

## Precondición

Fase 7 cerrada: definición de hecho cumplida en cada runtime, o con los pendientes declarados. Publicar es la primera acción con efecto fuera del repo.

## Pasos

### Común a todos los runtimes

1. **Fija la versión** en [`apm.yml`](../3-modelo-operativo/distribucion.md). Un cambio de contrato es un cambio mayor para los consumidores, aunque el diff sea pequeño. Cuenta como cambio de contrato:
   - el input o el output de un agente;
   - el enum de salida de una especialista;
   - el nombre de un artefacto o de la skill de entrada.

2. **Comprueba `targets`.** Debe listar todos los runtimes objetivo de la fase 0. Si falta uno, la versión publicada no llega a ese runtime y nadie recibe un error.

3. **Repinta los consumidores.** Cada repo que declare el paquete necesita el SHA nuevo.
   - Un consumidor sin repin sigue en la versión anterior, sin error y sin aviso.
   - Lista los consumidores antes de publicar.
   - Si el paquete añade agentes o hooks, comprueba que cada consumidor que usa Antigravity tiene el `lifecycle` del aprovisionador ([06-declarar-apm.md](06-declarar-apm.md#qué-documentar-para-quien-instala)).

4. **Registra la trazabilidad.** `apm.lock.yaml` ya guarda cada archivo desplegado con su hash. Falta el resto de la metadata mínima de cada artefacto editable a mano ([trazabilidad-sha](../4-buenas-practicas/3-control-y-calidad/trazabilidad-sha.md)):
   - autor;
   - fecha de creación y de última edición;
   - agente o skill responsable.

5. **Anota los pendientes de la fase 7** donde el equipo los vea. Un pendiente que solo vive en el hilo donde se publicó deja de existir al cerrarlo.

### Claude Code: `apm pack` y marketplace

6. **Genera el bundle:**

```bash
apm pack
```

   - Produce `build/<nombre>-<version>/` con `plugin.json` (sintetizado desde `apm.yml`), `agents/`, `skills/` y un `apm.lock.yaml` embebido.
   - `.claude-plugin/marketplace.json` **solo se genera si `apm.yml` tiene bloque `marketplace`**. En un paquete hoja no aparece, y es lo correcto.
   - Todo `build/` es output: no se edita a mano ([distribucion.md](../3-modelo-operativo/distribucion.md), [plugins.md](../2-primitivos/plugins.md#nota-sobre-este-repo-pluginjson-no-se-escribe-a-mano)).

7. **Revisa lo generado antes de commitear.** El `name`, la `version` y la lista de artefactos del `plugin.json` coinciden con la tabla de la fase 1. Mismo principio de la fase 7: verificar con herramienta.

8. **Da de alta el paquete en el agregador.** En este repo, se añade en el `apm.yml` de `ai-sdlc-platform`:
   - una dependencia en `dependencies.apm`;
   - una entrada en `marketplace.packages`.

   Las dos, pineadas al SHA publicado ([topologia-repos.md](../3-modelo-operativo/topologia-repos.md), [0003](../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md)). El marketplace es **solo de Claude Code**.

### Antigravity: validación con un install real

`apm pack` y el marketplace no cubren Antigravity. En `agy` el paquete se consume con `apm install --target antigravity` ([0019](../5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md)).

9. **Instala la versión publicada (el SHA, no la rama) en un consumidor de prueba de Antigravity**, con el `lifecycle` del aprovisionador declarado y confiado. Comprueba:
   - que existen `.agents/skills/`, `.agents/rules/` y `.agents/agents/`;
   - que `provision_agents_antigravity.py --check` sale con 0;
   - que `agy -p "…" --agent <agente>` responde;
   - que los hooks se ejecutan sin bloquear las herramientas.

10. **Usa la demo como referencia** del recorrido completo: [demo-pr-review-agy](../../../out-git/demo-pr-review-agy/README.es.md), paso 3 ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

## Reglas que aplican

- `apm pack`, artefactos generados y schema: [distribucion.md](../3-modelo-operativo/distribucion.md).
- Publicar en Claude (marketplace, plugin): [distribucion-claude-code.md](../3-modelo-operativo/distribucion-claude-code.md) · [runtime-claude-code.md](../2-primitivos/runtime-claude-code.md) · [plugins.md](../2-primitivos/plugins.md).
- Consumir en Antigravity: [distribucion-antigravity.md](../3-modelo-operativo/distribucion-antigravity.md) · [runtime-antigravity.md](../2-primitivos/runtime-antigravity.md).
- Topología y agregador: [topologia-repos.md](../3-modelo-operativo/topologia-repos.md) · [0003](../5-decisiones/4-estructura-del-repo/0003-repositorio-apm-agregador.md).
- Trazabilidad: [trazabilidad-sha](../4-buenas-practicas/3-control-y-calidad/trazabilidad-sha.md).
- Verificar con herramienta: [verificar-no-confiar-en-memoria](../4-buenas-practicas/3-control-y-calidad/verificar-no-confiar-en-memoria.md) · [0014](../5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md).

## Salida

- Versión fijada, con `targets` completos.
- Claude: bundle `build/<nombre>-<version>/` revisado y entrada en el agregador pineada por SHA.
- Antigravity: install real de la versión publicada, validado.
- Consumidores repintados, trazabilidad registrada y pendientes anotados.

## Errores comunes

- **Dar por publicado en Antigravity porque `apm pack` salió bien.** El bundle es solo de Claude; Antigravity solo se valida con un `apm install --target antigravity` real.
- **Validar Antigravity contra la rama y no contra el SHA publicado.** Lo probado no es lo que reciben los consumidores.
- **Publicar agentes nuevos sin avisar a los consumidores de Antigravity.** Sin `lifecycle`, el agente no se genera en su máquina.
- **Corregir a mano el `plugin.json` generado.** Dura hasta el siguiente `apm pack`.
- **Publicar sin repintar los consumidores.** Siguen en la versión vieja y nada falla.
- **Reusar la versión anterior "porque el cambio es pequeño".** El tamaño del diff no mide el impacto en el contrato.
- **Registrar solo el SHA.** Dice qué cambió; faltan el quién y el cuándo.
- **Cerrar sin anotar los pendientes de la fase 7.** Se convierten en deuda que nadie registró.
