# Fase 3 — Crear la estructura en disco

## Objetivo

Crear los directorios y archivos vacíos del paquete en el sitio correcto, sin confundir la fuente con lo que generan las herramientas.

## Precondición

Gate de la fase 1 aprobado y salida de la fase 2 elegida. Es la primera fase que escribe en disco.

## Pasos

1. **Identifica en qué layout estás.** Solo el primero se edita a mano:

   | Layout | Dónde | Quién lo escribe | ¿Se versiona? |
   |---|---|---|---|
   | Fuente APM | `.apm/agents/`, `.apm/skills/`, `.apm/instructions/`, `.apm/hooks/` | Tú | Sí |
   | Despliegue en Claude Code | `.claude/agents/`, `.claude/skills/`, `.claude/rules/`, hooks en `.claude/settings.json`, `.mcp.json` | `apm install` | No: es output |
   | Despliegue en Antigravity | `.agents/skills/`, `.agents/rules/`, `.agents/hooks.json`, `.agents/mcp_config.json` | `apm install` | No: es output |
   | Agentes en Antigravity | `.agents/agents/` | `provision_agents_antigravity.py`, en el `lifecycle` del consumidor ([0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) | No: es output |
   | Bundle de plugin (**solo Claude**) | `build/<nombre>-<version>/` con `plugin.json` | `apm pack` | No: es output |

   Detalle en [distribucion.md](../3-modelo-operativo/distribucion.md) (fuente y despliegue) y [plugins.md](../2-primitivos/plugins.md) (bundle).

2. **Crea el layout fuente**, con un directorio por skill. El nombre del directorio es idéntico al `name` del frontmatter ([skills.md](../2-primitivos/skills.md)); APM lo valida.

```
mi-paquete/
  apm.yml                              # fase 6 (targets: [claude, antigravity])
  .apm/
    agents/<nombre>.agent.md           # fase 5
    skills/<entrada>/SKILL.md          # skill de entrada /<entrada>, si la fase 2 la decidió
    skills/<nombre>/SKILL.md           # fase 4
    skills/<nombre>/<soporte>.md       # fase 4, si aplica
    instructions/<nombre>.instructions.md   # si la fase 1 planificó reglas
    hooks/…                            # si la fase 1 planificó hooks
```

   No existen `.apm/prompts/` ni `.claude/commands/`: están prohibidos ([0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).

3. **No crees `plugin.json` ni `marketplace.json`.** Son output de `apm pack` (fase 8), y solo sirven a Claude Code. En este repo `plugin.json` no es fuente versionada ([plugins.md](../2-primitivos/plugins.md#nota-sobre-este-repo-pluginjson-no-se-escribe-a-mano)).

4. **No crees nada dentro de `.agents/` ni de `.claude/` a mano.** Los dos son despliegue. Los agentes de Antigravity tampoco: los genera el aprovisionador desde `.apm/agents/`.

5. **Añade `.claude/`, `.agents/` y `apm_modules/` al `.gitignore`** si el repo fuente los va a generar al probar en la fase 7.
   - Versionar el despliegue duplica la fuente y produce drift silencioso.
   - El archivo desplegado se edita a mano y el siguiente `apm install` lo pisa.

6. **Verifica el esqueleto contra la tabla de la fase 1.** Un archivo en disco que no está en la tabla, o una fila sin archivo, es una desviación del plan aprobado. Corrígela antes de redactar.

## Reglas que aplican

- Layout fuente y despliegue en cada runtime: [distribucion.md](../3-modelo-operativo/distribucion.md) · [distribucion-antigravity.md](../3-modelo-operativo/distribucion-antigravity.md).
- Directorio de la skill = campo `name`: [skills.md](../2-primitivos/skills.md).
- Archivo `<name>.agent.md`: [subagents.md](../2-primitivos/subagents.md).
- `plugin.json` y `marketplace.json` son generados, solo Claude: [plugins.md](../2-primitivos/plugins.md) · [distribucion-claude-code.md](../3-modelo-operativo/distribucion-claude-code.md).
- Por qué no commands ni prompts: [0020](../5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md).
- Quién genera `.agents/agents/`: [0021](../5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md).

## Salida

Esqueleto de directorios y archivos vacíos que coincide fila por fila con la tabla de la fase 1, sin ningún archivo generado creado a mano.

## Errores comunes

- **Crear `.apm/prompts/` o `.claude/commands/`.** Están prohibidos: no llegan a Antigravity. La entrada es `.apm/skills/<entrada>/SKILL.md`.
- **Escribir `.agents/agents/<n>.md` a mano** "para probar ya en `agy`". Rompe la trazabilidad con el paquete y el aprovisionador no lo gestiona. La fuente es `.apm/agents/`.
- **Escribir `plugin.json` a mano.** Funciona hasta el primer `apm pack`, que lo regenera. La fuente es `apm.yml`.
- **Versionar `.claude/` o `.agents/` del repo fuente.** Fuente y copia divergen sin que nada lo detecte.
- **Nombrar el directorio de la skill distinto del `name`.** APM lo rechaza en la fase 6 y hay que renombrar.
- **Crear el directorio de una skill que la fase 1 no aprobó.** Es alcance nuevo sin gate.
