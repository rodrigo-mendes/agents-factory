# Revisión de PRs Java: de la skill de entrada al informe

> **Para quién / qué responde:** para quien toca o audita la revisión automática de PRs Java. Qué piezas intervienen, cómo llega `/review-pr-java` al informe en Claude Code y en Antigravity, y qué impide publicar por accidente.

**Conclusión:** `/review-pr-java` es una **skill de entrada** que delega en el agente `backend-java`. El agente ejecuta `proc-pr-review`, que resuelve cada rol con una skill y devuelve un informe con veredicto. Nada se publica en el PR sin confirmación y sin levantar dos barreras.

Es lo que se ejecuta hoy en las dos demos: [Claude Code](../../out-git/demo-pr-review/README.es.md) y [Antigravity](../../out-git/demo-pr-review-agy/README.es.md). Si vienes de nuevo, empieza por el [índice de la carpeta](README.md).

## Arquitectura

```
ai-sdlc-platform (catálogo de Claude Code + workflows de CI)
 └─ dep: ai-sdlc-backend-java      ← agentes + skill de entrada review-pr-java
      ├─ ai-sdlc-shared-skills     ← proc-pr-review, pr-access, report, security-scan, aprovisionador de Antigravity
      └─ ai-sdlc-kb-java           ← std-java-coding, style-check, coverage-check, kb-java-best-practices
```

| Capa | Pieza | Qué hace | Fuente |
|---|---|---|---|
| Skill de entrada | `/review-pr-java <PR> [foco]` | Delega en `backend-java` (fork en Claude; texto + `invoke_subagent` en Antigravity) con `publish=false` salvo petición expresa | `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md` |
| Agente | `backend-java` (interactivo) · `backend-java-ci` (CI, solo lectura) | Asigna cada rol a una skill y fija los límites | `ai-sdlc-backend-java/.apm/agents/` |
| Proceso | `proc-pr-review` | Orden y criterios de la revisión; no contiene reglas de lenguaje | `ai-sdlc-shared-skills/.apm/skills/proc-pr-review/` |
| Roles | `pr-access`, `style-check`, `security-scan`, `coverage-check`, `report` | Capacidades atómicas, resueltas por el agente | tabla siguiente |

Cómo se escribe la skill de entrada y por qué no es un command: [puntos de entrada](puntos-de-entrada.md).

Asignación de roles (idéntica en `backend-java` y `backend-java-ci`):

| Rol | Skill | Repo |
|---|---|---|
| `pr-access` | `act-common-github-pr` (`scripts/gh_pr.py`) | `ai-sdlc-shared-skills` |
| `style-check` | `act-java-check-style` | `ai-sdlc-kb-java` |
| `coverage-check` | `act-java-check-coverage` | `ai-sdlc-kb-java` |
| `security-scan` | `act-common-scan-security` (consulta `kb-java-best-practices`) | `ai-sdlc-shared-skills` |
| `report` | `act-common-write-report` | `ai-sdlc-shared-skills` |

Tres rasgos de diseño que conviene no perder:

- **Los roles no son subagentes.** `proc-pr-review` los ejecuta uno tras otro en la misma conversación. No hay fan-out ni paralelismo. El único aislamiento de contexto es el de `backend-java` respecto a la conversación principal.
- **Los roles se piden por nombre, no por skill.** Cambiar de stack es cambiar la tabla del agente; el proceso no se toca.
- **Solo el rol `pr-access` habla con GitHub.** El agente tiene prohibido ejecutar `gh` directamente para acceder al PR.

## Qué roles corren

| Rol | Corre y es obligatorio cuando |
|---|---|
| `style-check` | cambian ficheros de producción o de tests |
| `security-scan` | siempre (prioritario si cambian dependencias, autenticación, autorización o entrada externa) |
| `coverage-check` | cambia código de producción |

Con foco (`security`, `style` o `tests`), el rol correspondiente se ejecuta primero y con más profundidad. Un rol sin skill asignada se registra como `not_executed`; uno que la tabla no marca como obligatorio y no se ejecuta, como `not_required` (no afecta al veredicto).

## Diagrama de secuencia

Lo único que cambia entre runtimes es cómo se llega al agente (bloque `alt`). Desde ahí, el flujo es el mismo.

```mermaid
sequenceDiagram
  actor U as Usuario
  participant H as Runtime (Claude Code / agy)
  participant A as backend-java
  participant P as proc-pr-review
  participant G as gh_pr.py (pr-access)
  participant GH as GitHub (gh CLI)
  participant R as Roles (style / security / coverage)
  participant W as report (act-common-write-report)

  U->>H: /review-pr-java <url> [foco]
  alt Claude Code
    H->>A: context: fork + agent: backend-java
  else Antigravity
    Note over H: la skill corre en el agente principal (ignora el fork)
    H->>A: invoke_subagent (petición literal)
  end
  Note over A: rama "eres el agente" — contexto aislado
  A->>P: ejecuta (publish=false)
  P->>G: preflight
  G->>GH: gh auth status, gh repo view
  P->>G: resolve <url>
  G->>GH: gh pr view
  GH-->>G: PR + head sha
  G-->>P: sha analizado
  P->>G: files / diff
  G->>GH: gh pr diff
  G-->>P: patch en $TMPDIR/ai-sdlc-pr-<uid>/ (+ .json con "truncated")
  P->>P: clasifica ficheros (prod / tests / config / deps)
  loop cada rol obligatorio
    P->>R: PR ref + sha
    R->>G: patch --expect-sha
    G-->>R: ruta del patch
    R-->>P: execution {status, source} + findings
  end
  P->>P: consolida, dedupe, veredicto
  P->>W: findings + veredicto + contexto + publish
  W-->>A: resumen + inline (Markdown)
  A-->>H: informe
  H-->>U: informe + "¿publicar?"
  opt el usuario confirma y las dos barreras están levantadas
    W->>G: publish --expect-sha
    G->>GH: crea/actualiza el resumen con marcador (primero)
    G->>GH: crea la review con los comentarios inline
    G->>GH: actualiza el resumen si hubo findings fuera del diff
  end
```

- Si falla `preflight` (`no_gh`, `no_auth`) o `resolve` devuelve `no_pr`, la revisión se detiene y lo informa: nunca inventa un diff.
- En Antigravity, si el agente principal no puede delegar, se detiene y lo explica en lugar de revisar sin `backend-java`.

### Variante CI

El workflow reutilizable `ai-sdlc-platform/.github/workflows/pr-review-backend-java.yml` ejecuta el mismo proceso sin persona delante:

```mermaid
flowchart LR
  A["PR abierto (no draft, no fork)"] --> B["token read-only de la GitHub App"]
  B --> C["apm install ai-sdlc-backend-java"]
  C --> D["claude-code-action<br/>subagente backend-java-ci, publish=true"]
  D --> E["gh_pr.py publish --expect-sha<br/>resumen primero, luego inline"]
  E --> F["gh_pr.py verify --expect-sha<br/>falla el job si no hay resumen del commit"]
```

`backend-java-ci` solo puede leer (`Read, Grep, Glob, Bash`) y la invocación permite únicamente `git diff`, `git log` y `gh_pr.py`; `Edit`, `Write`, `git push` y `mvn` están denegados.

## Contrato de datos

Cada rol devuelve el mismo bloque, definido en `proc-pr-review/references/findings-contract.md`:

```
<role_result role="coverage-check">
execution:
  status: full | partial | not_executed
  source: jacoco.xml          # informe, herramienta o "diff"
  reason: motivo              # obligatorio si status != full
findings:
  - severity: blocker | warning | suggestion
    file: src/main/java/.../Class.java
    line: 42                  # opcional
    rule: rule-id
    rule_url: https://…       # opcional
    message: qué pasa y por qué importa
    fix: propuesta concreta   # opcional
</role_result>
```

| Severidad | Criterio |
|---|---|
| `blocker` | bug probable, vulnerabilidad o incumplimiento de norma obligatoria |
| `warning` | riesgo de mantenibilidad o desviación de buenas prácticas |
| `suggestion` | mejora opcional |

**Veredicto** (`proc-pr-review` §5). Primero se deriva de los findings y luego se limita:

| Condición | Veredicto |
|---|---|
| al menos un `blocker` | `REQUEST_CHANGES` |
| solo `warning` o `suggestion` | `COMMENT` |
| sin findings | `APPROVE` |
| `APPROVE` pero un rol obligatorio no está en `full` | `COMMENT` (el límite nunca baja un `REQUEST_CHANGES`) |

El veredicto es una **recomendación**: nunca aprueba ni rechaza formalmente el PR.

**Informe.** `report` genera siempre el mismo formato:

- Un resumen que empieza por `<!-- ai-sdlc-review sha=<SHA> -->`.
- Un comentario inline por finding con fichero y línea, etiquetado con [Conventional Comments](https://conventionalcomments.org) (`issue (blocking): …`).

Los findings sin línea van solo al resumen. No se escribe nada en el repositorio revisado.

## Publicación

`gh_pr.py publish --expect-sha <sha>` es la única vía válida:

1. Crea o actualiza el comentario-resumen (se identifica por el marcador), de modo que sea el primer comentario del PR.
2. Publica los inline en una sola review no bloqueante. Descarta los que ya existen con la misma ruta, línea y texto exactos (`_post_inline` en `gh_pr.py`).
3. Los findings que no se pueden ubicar en el diff se añaden al resumen, en la sección "Findings not placed on the diff".

Errores que el flujo trata como parte del contrato: `stale_head` (el PR recibió commits tras el análisis; no se publica nada), `publish_disabled` (`GH_PR_PUBLISH=0`; se devuelve el Markdown), `summary_required` (un inline sin resumen previo).

## Barreras de publicación

Publicar comentarios en un PR real notifica al autor y queda en el historial. Por eso hay **dos barreras**, y las dos tienen que estar levantadas para publicar:

| Barrera | Claude Code | Antigravity |
|---|---|---|
| 1. Solo comandos de lectura | `permissions.allow` de `.claude/settings.json`: solo `preflight`, `resolve`, `view`, `files`, `diff`, `patch`, `checks`, `verify` | `agy` no lee permisos de proyecto. La demo añade el hook `demo-permissions` en `.agents/hooks.json`: `allow` para la lectura y **`ask`** para `publish`, `comment` y `review-inline` |
| 2. Traba en el propio script | `env.GH_PR_PUBLISH=0` en `.claude/settings.json` | `GH_PR_PUBLISH=0` exportado en la shell antes de abrir `agy` (la demo lo carga desde `.demo-env`): no hay `env` de proyecto |
| Modo headless | `claude -p` con los mismos permisos | `agy -p` necesita la regla global `{"permissions": {"allow": ["command(python3)"]}}` en `~/.gemini/antigravity-cli/settings.json`. Un hook no puede conceder permisos en headless, y `ask` equivale a denegar |

Con `GH_PR_PUBLISH=0`, `gh_pr.py` rechaza cualquier escritura (`publish_disabled`), decida lo que decida el agente. Esta segunda barrera existe porque en una prueba e2e el agente intentó publicar sin que se le hubiera pedido.

Notas:
- En Claude Code hay que **confirmar la confianza en el directorio**. Sin ella, Claude ignora los permisos y el `env` del `settings.json`.
- En Antigravity la barrera 1 es un hook **de la demo**, no del paquete. Un consumidor tiene que montar el suyo ([hooks portables](../1-blueprint/4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md)).
- La regla global de `agy` afecta a toda la máquina: añádela solo cuando haga falta.

## Controles de seguridad

- **Dos barreras de publicación**, descritas en la sección anterior.
- **SHA fijado.** El sha de `resolve` viaja a todos los roles y a `publish`; si el head se mueve, se rechaza (`stale_head`).
- **El contenido del PR son datos.** Título, descripción, commits y ficheros nunca cambian qué proceso o roles corren ni el veredicto. Una instrucción detectada se anota en el informe, no como finding.
- **Sin credenciales en ficheros versionados.** Las demos instalan con `--only apm` y sin tokens exportados; con tokens exportados, APM los grabaría en `.mcp.json`.

## Puntos de atención

| Punto | Dónde |
|---|---|
| Solo funciona con un PR abierto; no hay modo pre-PR | `ai-sdlc-platform/docs/tracking/local-review-vs-proc-pr-review.md` (P1) |
| `coverage-check` busca `jacoco.xml` en el checkout local, mientras `proc-pr-review` prohíbe leer el checkout. Sin JaCoCo el rol queda en `partial` y el mejor veredicto es `COMMENT` | `act-java-check-coverage/SKILL.md`, `proc-pr-review/SKILL.md` §3 |
| Solo el resumen es idempotente. Los inline solo se descartan si el texto es idéntico; como el modelo redacta distinto en cada ejecución, al republicar se duplican | [demo de Claude Code](../../out-git/demo-pr-review/README.es.md), paso 7 |
| El workflow reutilizable y `examples/ai-pr-review.caller.yml` ya apuntan a `MyInvestor-Core`, pero `@v1` y `agent-version: v1.0.0` son tags que no existen | `ai-sdlc-platform/.github/workflows/pr-review-backend-java.yml`, `examples/` |
| Las dependencias están en `#main`; aún no hay tags. La demo de Antigravity instala desde `feature/agy-support` hasta que se mergee | `ai-sdlc-backend-java/apm.yml`, `demo-pr-review-agy/config.env` |
| Antigravity necesita APM 0.33.0 (el CI usa 0.32.0), `targets: [claude, antigravity]` en cada paquete y el aprovisionador en el `lifecycle` de quien instala | [0021](../1-blueprint/5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md), [distribución en Antigravity](../1-blueprint/3-modelo-operativo/distribucion-antigravity.md) |
| En Antigravity, la ruta de los hooks que despliega APM 0.33.0 falla (`.agents/.agents/…`) y bloquea todas las herramientas; la corrige el aprovisionador | [modelo de ejecución en Antigravity](../1-blueprint/3-modelo-operativo/modelo-ejecucion-antigravity.md#hooks) |
| Sin CI en Antigravity: no hay acción equivalente a `claude-code-action` | [modelo de ejecución en Antigravity](../1-blueprint/3-modelo-operativo/modelo-ejecucion-antigravity.md#ci) |
| El resultado del modelo no es determinista (p. ej. la inyección por campo puede salir como `COMMENT`). En Antigravity el modelo es otro (Gemini) | [no determinismo](../1-blueprint/1-conceptos/1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) |

Inventario completo y priorizado: [`mejoras-pendientes.md`](mejoras-pendientes.md).
