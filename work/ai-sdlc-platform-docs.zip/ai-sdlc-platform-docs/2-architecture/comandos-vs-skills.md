# Comandos vs. skills (sustituido)

Este documento se sustituyó por [Puntos de entrada: todo `/nombre` es una skill](puntos-de-entrada.md). Los commands y los prompts ya no se usan en ningún paquete ([0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)).
