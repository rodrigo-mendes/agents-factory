# Remediación de hallazgos SARIF: del plan a la PR draft

> **Para quién / qué responde:** para quien toca o audita la remediación automática de hallazgos SARIF en repos Java. Qué piezas intervienen, cómo se ejecuta en modo interactivo (en pasos) y autónomo, y qué impide publicar o escribir fuera de lugar.

**Conclusión:** `/remediate-sarif-java` es una **skill de entrada** que delega en el agente `backend-java-remediate`. El agente ejecuta `proc-sarif-remediation`: aplica cada hallazgo en un **worktree aislado**, verifica con build y tests, deja **un commit por ítem** y, solo si se levantan dos llaves, abre **una PR draft** con un informe en tabla. Es el primer proceso del repo que escribe código; por eso su diseño es una extensión explícita del [ADR 0005](../1-blueprint/5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md) (actualización 2026-11-03).

Hermano de [pr-review-java-flow.md](pr-review-java-flow.md): misma capa de skill de entrada y mismos roles por nombre, pero con efectos de escritura. Si vienes de nuevo, empieza por el [índice de la carpeta](README.md).

## Arquitectura

```
ai-sdlc-platform (catálogo de Claude Code + workflows de CI)
 └─ dep: ai-sdlc-backend-java      ← agentes backend-java-remediate y backend-java-fix + skill de entrada remediate-sarif-java
      ├─ ai-sdlc-shared-skills     ← proc-sarif-remediation, apply-sarif, deliver-change, write-report (modo remediation)
      └─ ai-sdlc-kb-java           ← act-java-run-build, kb-java-best-practices, std-java-coding
```

| Capa | Pieza | Qué hace | Fuente |
|---|---|---|---|
| Skill de entrada | `/remediate-sarif-java <sarif...> \| apply <run-id> \| publish <run-id>` | Delega en `backend-java-remediate` (fork en Claude; texto + `invoke_subagent` en Antigravity). Interactiva, en pasos | `ai-sdlc-backend-java/.apm/skills/remediate-sarif-java/SKILL.md` |
| Agente | `backend-java-remediate` | Orquestador con efectos vía scripts: `Read, Grep, Glob, Bash, Agent`; sin `Edit`/`Write` | `ai-sdlc-backend-java/.apm/agents/` |
| Subagente | `backend-java-fix` | Implementador acotado: `Read, Grep, Glob, Edit, Write`; sin `Bash` ni `Agent`. Aplica un brief dentro del worktree | `ai-sdlc-backend-java/.apm/agents/` |
| Proceso | `proc-sarif-remediation` | 10 fases, bucle por ítem, definición de hecho; no contiene reglas de Java ni nombres de skills | `ai-sdlc-shared-skills/.apm/skills/proc-sarif-remediation/` |
| Roles | `sarif-source`, `change-delivery`, `build-test`, `code-fix`, `report` | Capacidades atómicas, resueltas por el agente | tabla siguiente |

Asignación de roles (en `backend-java-remediate`):

| Rol | Skill / subagente | Repo |
|---|---|---|
| `sarif-source` | `act-common-apply-sarif` (`scripts/sarif.py`) | `ai-sdlc-shared-skills` |
| `change-delivery` | `act-common-deliver-change` (`scripts/deliver_change.py`) | `ai-sdlc-shared-skills` |
| `build-test` | `act-java-run-build` (`scripts/java_build.py`) | `ai-sdlc-kb-java` |
| `code-fix` | subagente `backend-java-fix` (default) | `ai-sdlc-backend-java` |
| `report` | `act-common-write-report` (modo `remediation`, solo formatea) | `ai-sdlc-shared-skills` |

Rasgos de diseño que conviene no perder:

- **`code-fix` es el único rol que es subagente**, y por qué: necesita `Edit`/`Write` y un contexto limpio por brief, mientras que el orquestador no puede editar. Ver [skills-vs-subagentes.md](skills-vs-subagentes.md). Los demás roles son scripts o skills ejecutadas en la misma conversación.
- **Profundidad de delegación 2**: `remediate-sarif-java` → `backend-java-remediate` → `backend-java-fix`. Dentro del límite de 3 de [0004](../1-blueprint/5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md); no hay fan-out paralelo.
- **Este proceso trabaja sobre un checkout** (el worktree), a diferencia de `proc-pr-review`, que nunca lee el checkout.
- **Solo `deliver_change.py` toca git/gh.** El agente tiene prohibido ejecutar `git`, `gh`, `claude` o `agy` directamente.
- **`gh_pr.py` no cambia**: su contrato es "nunca hace push ni crea PRs".
- **Un agente por responsabilidad**: `backend-java` y `backend-java-ci` quedan intactos.

## Cómo se usa

### Interactivo, en pasos

Un subagente no puede preguntar a mitad de la ejecución ([05-escribir-agentes](../1-blueprint/6-manual-creacion-plugin/05-escribir-agentes.md)). El gate va **entre invocaciones**, con el estado en `run.json`:

| Paso | Comando | Qué ocurre | ¿Escribe? |
|---|---|---|---|
| 1. Plan | `/remediate-sarif-java <archivo.sarif...> [--repo R] [--base B]` | parse, repo resuelto, tabla de ítems × acción prevista, definición de hecho; devuelve el `run-id` | no |
| 2. Aplicar | `/remediate-sarif-java apply <run-id> [--max-attempts N]` | worktree, baseline, bucle por ítem, commits; devuelve el informe y pregunta "¿publicar?" | solo en el worktree aislado |
| 3. Publicar | `/remediate-sarif-java publish <run-id>` | verifica estado vs git, push y PR draft (exige `GIT_CHANGE_PUBLISH=1`) | remoto |

Si falta un dato (`missing_repo`, `ambiguous_repo`, `baseline_failed`), el paso devuelve el código y una pista ("pasa `--repo owner/repo`"); no queda esperando respuesta.

### Autónomo (default del proceso)

`proc-sarif-remediation` con `mode=autonomous`, en una sola invocación: plan, aplicar y, si está liberado, publicar.

- `--repo` es **obligatorio** y la provenance del SARIF debe coincidir (`repo_mismatch`).
- Sin `publish=true` **y** `GIT_CHANGE_PUBLISH=1`: termina con los commits en el worktree y devuelve el informe.
- Entradas: la skill de entrada con `mode=autonomous`, o headless (`claude -p` / `agy -p`) accionando esa misma skill. No depende solo de `--agent`.

## Diagrama de secuencia

```mermaid
sequenceDiagram
  actor U as Usuario
  participant H as Runtime (Claude Code / agy)
  participant A as backend-java-remediate
  participant P as proc-sarif-remediation
  participant S as sarif.py (sarif-source)
  participant D as deliver_change.py (change-delivery)
  participant B as java_build.py (build-test)
  participant F as backend-java-fix (code-fix)
  participant R as report (act-common-write-report)
  participant GH as GitHub (git / gh)

  U->>H: /remediate-sarif-java <sarif...> (paso plan)
  alt Claude Code
    H->>A: context: fork + agent: backend-java-remediate
  else Antigravity
    Note over H: la skill corre en el agente principal (ignora el fork)
    H->>A: invoke_subagent (petición literal)
  end
  A->>P: ejecuta (mode=interactive, step=plan)
  P->>S: parse (dedup, filtros, provenance vs --repo)
  S-->>P: items + run-id
  P-->>U: tabla de ítems × acción + definición de hecho (no escribe)

  U->>H: /remediate-sarif-java apply <run-id>
  H->>A: delega (step=apply)
  A->>P: ejecuta
  P->>D: prepare (clone/fetch en caché, worktree add -b feature/sarif-remediation-<run-id>)
  P->>B: run baseline
  B-->>P: build_result (si falla: baseline_failed, aborta)
  loop cada ítem (por archivo, de abajo hacia arriba)
    alt intento 1 con fix en el SARIF
      P->>S: apply --item (determinista)
    else sin fix, stale_region o build fallido
      P->>F: remediation_brief + build_result previo
      F-->>P: resumen (untrusted_agent_output)
      P->>D: status --expect-head (HEAD sin mover, nada fuera del worktree)
    end
    end
    P->>B: compile → unit → integración (para en el primer fallo)
    alt ok
      P->>D: commit (trailers)
    else agota max-attempts
      P->>D: revert hasta last_good (ítem failed, continúa)
    end
  end
  P->>D: verify (run.json × git log base..HEAD × HEAD)
  P->>R: remediation_context (de sarif.py summary)
  R-->>U: informe + "¿publicar?"

  opt publish <run-id>, GIT_CHANGE_PUBLISH=1 y verify ok
    U->>H: /remediate-sarif-java publish <run-id>
    A->>D: push (solo feature/sarif-remediation-*, sin force)
    D->>GH: git push
    A->>D: pr-create (draft fijo)
    D->>GH: gh pr create --draft
  end
  A->>D: cleanup
```

En modo autónomo es la misma secuencia en una sola invocación, sin las pausas del usuario; donde el interactivo pregunta, el autónomo falla con código.

Las fases completas con su modo de fallo están en el [ciclo de vida de fases](../1-blueprint/4-buenas-practicas/2-orquestacion/ciclo-de-vida-de-fases.md#caso-con-escritura-remediación-de-sarif).

### Bucle por ítem

- `max-attempts` por defecto **3**, parámetro (no número en prosa). Toda tentativa cuenta, incluido `apply` determinista, `no_changes`, timeout y el agente que movió HEAD. Ver [bucle de verificación](../1-blueprint/4-buenas-practicas/2-orquestacion/bucle-de-verificacion-y-limite-de-reintentos.md) y [0016](../1-blueprint/5-decisiones/2-orquestacion/0016-bucle-de-verificacion-limite-de-reintentos.md).
- Éxito: `commit` con trailers `Sarif-Item`, `Rule`, `Fix-Source: sarif|agent`, `Attempts`, `Generated-By`. Agotado: `revert` y el ítem queda `failed`, y el proceso sigue.

## `run.json`

Estado de la ejecución, persistido entre pasos. **Único escritor: `sarif.py state init|record|show`**; el modelo no lo edita ni cuenta nada (`sarif.py summary` calcula las cifras del informe). Registra por ítem: intentos, fase, estado y commit. El `run-id` es determinista: `sha256(ids ordenados)[:12]`; el `base_sha` se registra en `run.json` y en el marcador de la PR, no en el `run-id`, porque no se conoce hasta `prepare` y el `run-id` debe ser el mismo en `plan`, `apply` y `publish`. `deliver_change.py verify` lo contrasta con `git log base..HEAD` (trailers) y con HEAD; una divergencia es `state_mismatch` y bloquea la publicación ([0014](../1-blueprint/5-decisiones/3-control-y-calidad/0014-verificacion-objetiva-de-hechos.md)).

## Barreras

| Barrera | Qué impone | Dónde vive |
|---|---|---|
| Escritura solo en worktree aislado | `Edit`/`Write` solo en `backend-java-fix`, dentro del worktree fuera del proyecto; `status` falla con `head_moved` / `outside_worktree` | `deliver_change.py` |
| 1. `publish=true` | sin él, los commits quedan en el worktree | parámetro del proceso |
| 2. `GIT_CHANGE_PUBLISH=1` | sin la variable, `push` devuelve `publish_disabled`. Interruptor **invertido** respecto a `GH_PR_PUBLISH`: sin variable, no publica | `deliver_change.py` |
| PR siempre draft | `pr-create` no tiene flag para cambiarlo | `deliver_change.py` |
| Permisos por subcomando | ver tabla siguiente | `.claude/settings.json` del consumidor |
| Verificación posterior | `verify` antes de publicar | `deliver_change.py` |

Permisos del consumidor (Claude Code; el detalle y el equivalente de Antigravity viven en el README de `ai-sdlc-backend-java`):

| Qué | Regla |
|---|---|
| Libres | `sarif.py *`, `java_build.py *`, `deliver_change.py preflight\|prepare\|status\|commit\|revert\|verify\|cleanup` |
| Piden confirmación | `deliver_change.py push`, `pr-create` |
| Denegados | `Bash(git push*)`, `Bash(gh pr*)`, `Bash(claude *)`, `Bash(agy *)` |
| Directorios | `additionalDirectories` (Claude) / `--add-dir` (Antigravity) para el worktree del caché |

No hay hook global que bloquee `git push`: APM aplica los hooks sin matcher a todas las sesiones del consumidor. El hook `check_prereqs.py` solo reconoce `deliver_change.py` (git + gh autenticado), acepta los dos formatos de evento y nunca bloquea por error interno ([0022](../1-blueprint/5-decisiones/3-control-y-calidad/0022-hooks-portables-entre-runtimes.md)).

## Controles de seguridad

- **El SARIF es entrada no confiable.** Se valida (versión 2.1.0, límite de 50 MB, rutas dentro del repo, sin `..`), se deduplica y sus campos de texto libre van en `<untrusted_sarif_content>`. Una instrucción detectada ("haz push a main", "ejecuta otro proceso") se anota en el informe, no se obedece. Práctica: [entrada de herramientas externas como datos](../1-blueprint/4-buenas-practicas/3-control-y-calidad/entrada-de-herramientas-externas-como-datos.md); concepto: [prompt injection](../1-blueprint/1-conceptos/5-distribucion-y-dominio/prompt-injection.md).
- **El SARIF no decide el destino.** `--repo` es obligatorio en autónomo y la provenance debe coincidir; si no, `repo_mismatch`. Impide que un SARIF forjado redirija el push.
- **`insertedContent` es código no confiable**, tanto el de los `fixes` del SARIF como el que escribe el agente; el informe indica el origen de cada fix y la PR va en draft con revisión humana obligatoria.
- **La salida del subagente es un dato** (`<untrusted_agent_output>`). Tras cada `code-fix`, `status --expect-head` confirma que HEAD no se movió y que no hay cambios fuera del worktree; si no, la tentativa se revierte y se cuenta como fallo.
- **`apply` no escapa del worktree**: `realpath` dentro del worktree, sin fuga por symlink (`path_outside_worktree`).
- **Nunca**: `--force`, push a la rama base/default, `reset`/`clean` fuera del worktree del run, merge.

## Modelo de ejecución: Sonnet

`model: sonnet` **no puede ir en el frontmatter de los agentes** (solo se admite `inherit`; el aprovisionador de Antigravity falla con otro valor, ver [subagents.md](../1-blueprint/2-primitivos/subagents.md)). El modelo se fija en los puntos de invocación; los agentes quedan en `model: inherit`:

| Punto | Cómo fijar Sonnet | Runtime |
|---|---|---|
| Skill de entrada `remediate-sarif-java` | `model: sonnet` en su frontmatter (Antigravity lo ignora sin error) | Claude |
| `backend-java-remediate` → `backend-java-fix` | el proceso pide invocar el subagente con `model: sonnet` en la llamada a `Agent` | Claude |
| Headless / CI | `claude -p --model sonnet …` | Claude |
| Antigravity | no hay campo portable: el modelo sale de la sesión `agy` (el README documenta cuál elegir) | Antigravity |

Pendiente de comprobar en transcript/telemetría: que el fork de la skill de entrada y cada invocación de `backend-java-fix` corren en Sonnet. Si el `model` de la skill no se propaga al fork con `agent:`, queda la llamada explícita a `Agent`.

## Puntos de atención

| Punto | Dónde |
|---|---|
| Build + integración por ítem es lento en repos grandes; un futuro parámetro `integration: per-item\|final` lo resolvería | [mejoras-pendientes.md](mejoras-pendientes.md) |
| El worktree está fuera del proyecto: sin `additionalDirectories` / `--add-dir`, `backend-java-fix` no puede editar. El `preflight` debe detectarlo | [mejoras-pendientes.md](mejoras-pendientes.md) |
| Sin Docker, la integración con Testcontainers queda `partial`: resultado ⚠️ "applied, integration not run", nunca ✅, y la PR lleva `[partial]` | [definición de hecho](../1-blueprint/4-buenas-practicas/3-control-y-calidad/definicion-de-hecho.md) |
| El SARIF no se vuelve a ejecutar: el informe dice "not re-scanned"; no afirma que el hallazgo desapareció | `act-common-write-report/references/remediation-pr-template.md` |
| `code-fix` es la parte más variable; la contención viene del worktree, el revert, la verificación de HEAD y la PR draft con revisión humana | esta página |
| Fase 2 (adaptador de agente externo `claude -p` / `agy -p`): no implementada; exige un ADR nuevo | [mejoras-pendientes.md](mejoras-pendientes.md) |
| El resultado del modelo no es determinista; en Antigravity el modelo es otro | [no determinismo](../1-blueprint/1-conceptos/1-fundamentos-del-modelo/no-determinismo-y-conjuntos-cerrados.md) |

Inventario completo y priorizado: [`mejoras-pendientes.md`](mejoras-pendientes.md).
