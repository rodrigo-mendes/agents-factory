# Documentación de arquitectura

> **Para quién / qué responde:** índice de la carpeta. Qué documento leer según lo que necesites, y cómo se reparten el trabajo.

**Conclusión:** todo lo de esta carpeta vale para Claude Code y para Antigravity. Los paquetes son **agnósticos**: solo agentes y skills, y todo `/nombre` es una skill de entrada ([modelo de ejecución agnóstico](../1-blueprint/3-modelo-operativo/modelo-ejecucion.md#1-regla-solo-agentes-y-skills)).

Paso previo, si no vienes de crear o customizar agentes: [`../1-blueprint/1-conceptos/README.md`](../1-blueprint/1-conceptos/README.md).

## Orden de lectura

| # | Documento | Para quién | Qué responde |
|---|---|---|---|
| 1 | [`guia-skills-agentes.md`](guia-skills-agentes.md) | Producto, negocio, QA, gestión. **Sin requisitos técnicos** | ¿Qué son una skill y un agente, y cuándo pedir cada uno? |
| 2 | [`skills-vs-subagentes.md`](skills-vs-subagentes.md) | Quien diseña o extiende paquetes | ¿Skill o subagente? Trade-offs, criterios y qué tiene que cumplir cada uno |
| 3 | [`puntos-de-entrada.md`](puntos-de-entrada.md) | Idem, tras el anterior | ¿Por qué todo `/nombre` es una skill? Cómo se escribe una skill de entrada que delega en un agente |
| 4 | [`mejoras-pendientes.md`](mejoras-pendientes.md) | Quien planifica el trabajo | Qué queda por cambiar en los paquetes, priorizado. Lo cerrado, en [`mejoras-cerradas.md`](mejoras-cerradas.md) |
| 5 | [`pr-review-java-flow.md`](pr-review-java-flow.md) | Quien toca el flujo de revisión | Cómo `/review-pr-java` llega al informe en los dos runtimes: agente, roles, `gh_pr.py` y publicación |
| 6 | [`sarif-remediation-java-flow.md`](sarif-remediation-java-flow.md) | Quien toca la remediación de SARIF | Cómo `/remediate-sarif-java` llega de un SARIF a una PR draft: pasos interactivos y modo autónomo, worktree aislado, barreras de publicación y controles de seguridad |
| 7 | [`escenarios-de-skills-implementacion.md`](escenarios-de-skills-implementacion.md) | Quien escribe escenarios de una skill | Qué nivel de cobertura le toca a cada skill, dónde se declaran sus escenarios y qué falta |

`comandos-vs-skills.md` se sustituyó por `puntos-de-entrada.md`; el archivo antiguo solo redirige.

**Atajo según lo que necesites:**

- *Decidir si pedir una skill o un agente* → 1, y para nada más.
- *Diseñar una pieza nueva* → 2 y 3, más el [modelo de ejecución](../1-blueprint/3-modelo-operativo/modelo-ejecucion.md).
- *Planificar trabajo sobre los paquetes* → 4.
- *Entender la revisión de PRs* → 5 y las demos.
- *Entender la remediación de hallazgos SARIF* → 6.

## Cómo se relacionan

```mermaid
flowchart TB
    G["1 · guia-skills-agentes<br/>conceptos, sin jerga"]
    S["2 · skills-vs-subagentes<br/>trade-offs y criterios"]
    E["3 · puntos-de-entrada<br/>skill de entrada y delegación"]
    M["4 · mejoras-pendientes<br/>inventario priorizado"]
    F["5 · pr-review-java-flow<br/>el flujo concreto"]
    R["6 · sarif-remediation-java-flow<br/>flujo con escritura"]

    G --> S
    S --> E
    E -->|"caso real"| F
    E -->|"segundo caso real"| R
    S -->|"los criterios producen<br/>los incumplimientos"| M
    F -->|"sus puntos de atención<br/>remiten a"| M
    R -->|"sus puntos de atención<br/>remiten a"| M
```

## Reparto de responsabilidades entre documentos

- **Los documentos 1, 2 y 3 explican mecánica y criterios.** No contienen tareas.
- **El documento 4 contiene todas las tareas** sobre los paquetes de revisión de PRs. Los demás enlazan ahí en lugar de duplicar.
- **El documento 5 describe lo que hoy se ejecuta** (skill de entrada, agente, roles, `gh_pr.py`) y se contrasta con las dos demos. Sus puntos de atención remiten al documento 4.
- **El documento 6 describe la remediación de SARIF**, el primer flujo con escritura (worktree aislado, commits, PR draft). Sus puntos de atención también remiten al documento 4.

## Demos

- [Demo en Claude Code](../../out-git/demo-pr-review/README.es.md): `/review-pr-java` desde cero, con `.claude/settings.json`.
- [Demo en Antigravity](../../out-git/demo-pr-review-agy/README.es.md): el mismo paquete con `agy`, el aprovisionador de agentes y las barreras de publicación propias de Antigravity.

## Estado

- Los documentos 2, 3 y 5 describen el diseño actual: `review-pr-java` → `backend-java` → `proc-pr-review`, en Claude Code y en Antigravity.
- El documento 6 describe `remediate-sarif-java` → `backend-java-remediate` → `proc-sarif-remediation` (con `backend-java-fix` como subagente de `code-fix`). El diseño está aprobado; la implementación se entrega por bloques, así que contrasta cada afirmación con el código antes de darla por ejecutada.
- El documento 1 explica los conceptos con ese mismo caso.
- El documento 4 solo lista lo abierto; lo cerrado u obsoleto está en `mejoras-cerradas.md`.
