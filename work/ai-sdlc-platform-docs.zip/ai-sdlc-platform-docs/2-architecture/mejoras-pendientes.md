# Mejoras pendientes

> **Para quién:** quien planifica el trabajo sobre los paquetes de revisión de PRs y de remediación de SARIF.
> **Qué responde:** qué queda por arreglar hoy, con qué prioridad y dónde está el problema.

**Conclusión:** quedan **17 mejoras abiertas**. Las más urgentes son las que impiden usar el CI fuera del entorno del autor (#19, #20, N1) y su paso a APM 0.33.0 (N4). Los ítems cerrados u obsoletos están en [mejoras-cerradas.md](mejoras-cerradas.md).

Referencias del estado actual:
- flujo de revisión: [pr-review-java-flow.md](pr-review-java-flow.md);
- flujo de remediación de SARIF: [sarif-remediation-java-flow.md](sarif-remediation-java-flow.md);
- skill de entrada: [puntos-de-entrada.md](puntos-de-entrada.md) y [ADR 0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md);
- demos: [Claude Code](../../out-git/demo-pr-review/README.es.md) y [Antigravity](../../out-git/demo-pr-review-agy/README.es.md).

## Prioridades

| Prioridad | Significado |
|---|---|
| **P0 — Bloqueante** | No se puede usar fuera del entorno del autor |
| **P1 — Conformidad** | Funciona, pero incumple una decisión o da resultados no deterministas |
| **P2 — Deuda** | Empaquetado, documentación o comprobaciones pendientes. No rompe la ejecución |

## Tabla de estado

| # | Mejora | Runtime | Prioridad |
|---|---|---|---|
| [19](#19-el-ci-instala-desde-un-fork-personal) | El CI instala desde un fork personal (parcial: faltan los tags) | Claude (CI) | P0 |
| [20](#20-política-de-pinning-sin-definir) | Política de pinning sin definir | Agnóstico | P0 |
| [N1](#n1-tag-v100-inexistente) | Tag `v1.0.0` inexistente | Agnóstico | P0 |
| [N4](#n4-ci-en-apm-0330) | CI en APM 0.33.0 | Agnóstico | P1 |
| [9](#9-el-ci-publica-sin-una-persona-delante) | El CI publica sin una persona delante | Claude (CI) | P1 |
| [N2](#n2-coverage-check-lee-el-checkout-local) | `coverage-check` lee el checkout local | Agnóstico | P1 |
| [N6](#n6-skills-de-ai-shared-en-antigravity) | Skills de `ai-shared` en Antigravity | Antigravity | P1 |
| [N5](#n5-informar-a-microsoftapm) | Informar a `microsoft/apm` | Antigravity | P2 |
| [N7](#n7-agy-agents-no-lista-los-agentes-de-proyecto) | `agy agents` no lista los agentes de proyecto | Antigravity | P2 |
| [N8](#n8-distribución-con-plugins-de-antigravity) | Distribución con plugins de Antigravity | Antigravity | P2 |
| [14](#14-catálogo-del-marketplace-declarado-dos-veces) | Catálogo del marketplace declarado dos veces | Claude | P2 |
| [N3](#n3-comentarios-inline-duplicados) | Comentarios inline duplicados | Agnóstico | P2 |
| [N9](#n9-adaptador-de-agente-externo-fase-2-de-la-remediación) | Adaptador de agente externo (fase 2 de la remediación) necesita un ADR nuevo | Agnóstico | P2 |
| [N10](#n10-antigravity-no-puede-fijar-sonnet) | Antigravity no puede fijar Sonnet | Antigravity | P2 |
| [N11](#n11-namespacing-de-agentes-en-plugins) | Namespacing de agentes en plugins | Claude | P2 |
| [N12](#n12-worktree-fuera-del-proyecto-y-permisos-de-directorio) | Worktree fuera del proyecto y permisos de directorio | Agnóstico | P1 |
| [N13](#n13-ejecutor-de-escenarios) | Ejecutor de escenarios | Agnóstico | P2 |

Los números sin prefijo vienen del inventario original de 22 mejoras. Las "N" son nuevas.

## Orden sugerido

1. **#19, #20 y N1 juntas:** sin ellas el CI no funciona fuera del entorno del autor.
2. **N4:** subir el CI a APM 0.33.0.
3. **#9:** decidir si el CI publica sin persona delante (la remediación autónoma ya fija su respuesta: dos llaves y PR draft, ver el ADR 0005).
4. **N2:** decidir la fuente de la cobertura.
5. **N6:** revisar `ai-shared` antes de anunciarlo para Antigravity.
6. El resto, cuando haya hueco.

El modo pre-PR se sigue en `ai-sdlc-platform/docs/tracking/local-review-vs-proc-pr-review.md`.

---

## 19. El CI instala desde un fork personal

**Estado:** parcial. El fork está corregido en `ai-sdlc-platform` (PR [#12](https://github.com/MyInvestor-Core/ai-sdlc-platform/pull/12), pendiente de merge). Falta que los refs existan.

- `.github/workflows/pr-review-backend-java.yml` instala `MyInvestor-Core/ai-sdlc-backend-java`.
- `examples/ai-pr-review.caller.yml` llama a `MyInvestor-Core/ai-sdlc-platform/.github/workflows/pr-review-backend-java.yml@v1`.
- Ningún repo `ai-sdlc-*` tiene tags publicados: ese `@v1` y `agent-version: v1.0.0` no resuelven hasta cerrar [N1](#n1-tag-v100-inexistente) y [#20](#20-política-de-pinning-sin-definir).

**Arreglo restante:** publicar los tags o fijar otra política de pinning. Cuando eso esté, mover esta mejora a [mejoras-cerradas.md](mejoras-cerradas.md).

## 20. Política de pinning sin definir

**Estado:** abierta.

- Todas las dependencias están en `#main` (`ai-sdlc-platform`, `ai-sdlc-backend-java`).
- El workflow reutilizable usa `agent-version: v1.0.0`, que no existe (ver N1).

**Arreglo:** una política única (SHA o tag semver) y un proceso escrito para actualizarla.

## N1. Tag `v1.0.0` inexistente

**Estado:** abierta. Ningún repo `ai-sdlc-*` tiene tags.

- El workflow reutilizable declara `agent-version: v1.0.0` por defecto.
- `examples/ai-pr-review.caller.yml` lo repite.
- El README de `ai-sdlc-backend-java` cita `apm install <org>/ai-sdlc-backend-java#v1.0.0`.

Quien siga el ejemplo falla en `apm install`. Las demos instalan `#main`.

**Arreglo:** crear el tag, o fijar el valor por defecto a un SHA o a `main` documentado hasta que exista.

## N4. CI en APM 0.33.0

**Estado:** abierta.

- La action `ai-sdlc-publish-plugin` usa `apm-version: 0.32.0` por defecto.
- APM 0.32.0 no tiene el target `antigravity`. Las demos de Antigravity usan 0.33.0.
- El workflow de revisión instala con `target: claude`, así que hoy no le afecta.

**Arreglo:** subir el CI a 0.33.0 y comprobar que `apm pack` y `apm audit --ci` siguen en verde con paquetes que declaran `targets: [claude, antigravity]`.

## 9. El CI publica sin una persona delante

**Estado:** abierta, reformulada.

Barreras actuales en local:

| Barrera | Claude Code | Antigravity |
|---|---|---|
| La skill de entrada pasa `publish=false` y el informe pregunta "¿publicar?" | Sí | Sí |
| Solo comandos de lectura | `permissions.allow` en `.claude/settings.json` | Hook de la demo que responde `ask` a las escrituras |
| Traba en el script (`GH_PR_PUBLISH=0`) | `env` de `settings.json` | Variable exportada antes de abrir `agy` |
| `--expect-sha` impide publicar sobre otro commit | Sí | Sí |

**Ampliación (2026-11-03).** La remediación de SARIF ([sarif-remediation-java-flow.md](sarif-remediation-java-flow.md)) extiende la excepción de CI a la ejecución autónoma que escribe código, con barreras propias (worktree aislado, `publish=true` + `GIT_CHANGE_PUBLISH=1`, PR draft fija, `verify`); ver la actualización del [ADR 0005](../1-blueprint/5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md). Para la revisión de PRs sigue abierto lo de abajo.

**Lo que queda abierto:** el CI ejecuta `backend-java-ci` con `publish=true` y sin persona delante. Eso contradice la decisión del 2026-09-23 ("nunca sin una persona delante"; ver [mejoras-cerradas.md](mejoras-cerradas.md#decisiones-registradas)).

**Arreglo:** decidir una de dos:
- revisar la decisión: el CI publica, solo como comentarios;
- o el CI pasa a generar Markdown sin publicar.

## N2. `coverage-check` lee el checkout local

**Estado:** abierta.

- `act-java-check-coverage` busca `**/target/site/jacoco/jacoco.xml` en el repositorio.
- `proc-pr-review` indica a los roles que no lean ficheros del checkout local.
- Sin JaCoCo el rol queda en `partial` y el mejor veredicto posible es `COMMENT`. En las demos no hay `pom.xml`, así que pasa siempre.

**Arreglo:** decidir si la cobertura llega como artefacto del CI (un job previo publica `jacoco.xml`) o si el rol asume `partial` fuera del CI. Documentarlo en las dos skills.

## N6. Skills de `ai-shared` en Antigravity

**Estado:** abierta, sin probar en `agy`.

Las skills de `ai-shared/plugins/engineering/skills/` usan campos que Antigravity no soporta:
- `model:` (`opus`, `sonnet`) en casi todas: `agy` lo ignora en las skills;
- `allowed-tools` en `local-review`: `agy` lo ignora;
- `${CLAUDE_PLUGIN_ROOT}` en `local-review`: no existe fuera de un plugin de Claude.

**Arreglo:** probarlas en `agy`. Sustituir `${CLAUDE_PLUGIN_ROOT}` por una ruta que funcione en los dos runtimes. Documentar qué se pierde sin `model:` ni `allowed-tools`. Ver [runtime-antigravity.md](../1-blueprint/2-primitivos/runtime-antigravity.md#skills).

## N5. Informar a `microsoft/apm`

**Estado:** abierta. Hoy lo compensa el aprovisionador ([ADR 0021](../1-blueprint/5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)).

Dos comportamientos de APM 0.33.0 con el target `antigravity`:
- **no despliega agentes** en `.agents/agents/`;
- **escribe la ruta de los hooks relativa a la raíz** (`python3 .agents/hooks/…`), pero `agy` ejecuta los hooks desde `.agents/`. La ruta queda `.agents/.agents/…`, el hook falla y `agy` bloquea todas las herramientas.

**Arreglo:** abrir un issue en [microsoft/apm](https://github.com/microsoft/apm) por cada uno. Si APM los corrige, retirar esa parte del aprovisionador.

## N7. `agy agents` no lista los agentes de proyecto

**Estado:** abierta (`agy` 1.4.8).

- `agy agents` no muestra los agentes de `.agents/agents/`.
- `agy --agent <nombre>` sí los usa.

**Arreglo:** informarlo a Antigravity. Mientras tanto, comprobar con `agy -p "hola" --agent backend-java`, como hacen las demos.

## N8. Distribución con plugins de Antigravity

**Estado:** abierta, **sin verificar**.

Antigravity tiene plugins propios, pero solo un marketplace oficial documentado. Hay dos vías posibles, no probadas:
- `agy plugin install https://github.com/<org>/ai-sdlc-backend-java` sobre la rama `claude-plugin`;
- `agy plugin import`, que según la CLI importa plugins "from gemini or claude".

**Arreglo:** probar las dos. Si funcionan, valorar si son una alternativa a `apm install` en Antigravity. Contexto en [runtime-antigravity.md](../1-blueprint/2-primitivos/runtime-antigravity.md#plugins-y-marketplace).

## 14. Catálogo del marketplace declarado dos veces

**Estado:** abierta, reformulada. Solo afecta a Claude Code.

- El catálogo está en el bloque `marketplace:` del `apm.yml` y en `.claude-plugin/marketplace.json`.
- Los dos declaran `backend-java` con `ref: claude-plugin`.
- La action `ai-sdlc-publish-plugin` lee el JSON.

**Arreglo:** declarar cuál es la fuente de verdad. Si se mantienen los dos, añadir una comprobación en el CI que falle si difieren.

## N3. Comentarios inline duplicados

**Estado:** abierta.

- Solo el resumen es idempotente: se actualiza por marcador.
- `gh_pr.py publish` omite los inline "ya publicados", pero la deduplicación falla si el texto cambia entre ejecuciones del modelo.

**Arreglo:** deduplicar por (fichero, línea, `rule`) en lugar de por texto, o resolver los hilos obsoletos antes de publicar. Mientras tanto, publicar una sola vez por PR.

## N9. Adaptador de agente externo (fase 2 de la remediación)

**Estado:** abierta, sin implementar.

- El papel `code-fix` usa hoy el subagente `backend-java-fix`. La alternativa opt-in, `act-common-delegate-code-fix` (`code_fix.py run --brief-file F --worktree DIR`), invocaría un agente externo (`claude -p`, `agy -p`) cuyo comando vendría solo de configuración.
- Toca los ADR [0004](../1-blueprint/5-decisiones/2-orquestacion/0004-cap-fanout-depth-uno.md), [0010](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0010-jerarquia-de-capas.md), [0019](../1-blueprint/5-decisiones/4-estructura-del-repo/0019-soporte-multi-runtime-claude-y-antigravity.md) y [0023](../1-blueprint/5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md).
- Guardas obligatorias previstas: `--disallowedTools "Agent,Task,Bash"`, marcador `AI_SDLC_REMEDIATION_RUN` contra recursión, tope de coste, timeout y verificación de HEAD y archivos posterior.

**Arreglo:** un ADR nuevo ("Delegación a agente externo por proceso") con su práctica pareada, aceptado antes de escribir una línea del adaptador.

## N10. Antigravity no puede fijar Sonnet

**Estado:** abierta, limitación de plataforma.

- `model: sonnet` no puede ir en el frontmatter de los agentes (solo `inherit`; el aprovisionador falla con otro valor).
- En Claude se fija en los puntos de invocación: `model: sonnet` en la skill de entrada, `model` en la llamada a `Agent` y `claude -p --model sonnet`.
- En Antigravity no hay campo portable: el modelo sale de la sesión `agy`.

**Arreglo:** documentar en el README qué modelo seleccionar en `agy`, y revisar si Antigravity añade un campo de modelo por agente o skill.

## N11. Namespacing de agentes en plugins

**Estado:** abierta, sin comprobar.

Una skill de entrada con `agent: backend-java-remediate` y una llamada `Agent` al subagente `backend-java-fix` dependen de cómo se resuelva el nombre del agente cuando viene de un plugin (con o sin prefijo de plugin).

**Arreglo:** comprobarlo en el e2e con el paquete instalado desde el marketplace, y ajustar el texto de delegación si hace falta el nombre cualificado.

## N12. Worktree fuera del proyecto y permisos de directorio

**Estado:** abierta, riesgo conocido de la remediación.

- El worktree se crea en el caché del usuario, **fuera del proyecto**. Para que `backend-java-fix` pueda editarlo, el consumidor debe declarar ese directorio: `additionalDirectories` en `.claude/settings.json` (Claude) o `--add-dir` (Antigravity).
- Si no lo configura, el subagente no puede editar y la ejecución falla de forma poco clara.

**Arreglo:** que `deliver_change.py preflight` detecte la falta del permiso y falle con un código y una pista; documentarlo en el README de `ai-sdlc-backend-java` y en [runtime-claude-code.md](../1-blueprint/2-primitivos/runtime-claude-code.md) / [runtime-antigravity.md](../1-blueprint/2-primitivos/runtime-antigravity.md).

## N13. Ejecutor de escenarios

**Estado:** abierta.

- Los escenarios se declaran en `scenarios/` junto a cada skill, pero ninguna herramienta los ejecuta ni emite el veredicto PASS/PARTIAL/FAIL.
- Hay que elegir un ejecutor y decidir si corre en CI. El estado por skill está en [escenarios-de-skills-implementacion.md](escenarios-de-skills-implementacion.md).
