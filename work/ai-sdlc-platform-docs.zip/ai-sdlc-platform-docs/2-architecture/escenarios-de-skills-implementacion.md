# Escenarios de skills: implementación en los paquetes

> **Para quién:** quien escribe o revisa los escenarios de una skill de los paquetes `ai-sdlc-*`.
> **Qué responde:** qué nivel le toca a cada skill, dónde está su directorio de escenarios y qué falta.

**Conclusión:** la norma está en la [práctica de escenarios](../1-blueprint/4-buenas-practicas/3-control-y-calidad/testing-de-skills-con-escenarios.md) y en el [ADR 0009](../1-blueprint/5-decisiones/3-control-y-calidad/0009-testing-de-skills-con-escenarios.md). Este documento la aplica a nuestros paquetes. Todas las skills de acción tienen sus escenarios declarados (62 en total) y **ninguna tiene un ejecutor que los corra**.

## Estructura

En cada repositorio, junto a la skill:

```text
.apm/skills/<skill>/scenarios/
├── README.md                    nivel y número de escenarios
└── NN-<categoría>-<slug>.md     un archivo por escenario
```

Ejemplo real: `review-pr-java/scenarios/` en `ai-sdlc-backend-java`.

El directorio vive dentro de `.apm/`, así que el linter de la plataforma lo recorre y el empaquetado lo publica con el plugin. Los escenarios se redactan para cumplir esas reglas: sin nombres de herramientas de un runtime y sin nombrar otras skills por su nombre. Que se publiquen los escenarios hostiles es una consecuencia aceptada por ahora.

## Nivel por skill

| Repo | Skill | Nivel | Escenarios previstos | Declarados |
|---|---|---|---|---|
| ai-sdlc-backend-java | `review-pr-java` | Bueno | 9 | 9 |
| ai-sdlc-backend-java | `remediate-sarif-java` | Bueno | 10 | 10 |
| ai-sdlc-shared-skills | `act-common-github-pr` | Aceptable | 6 | 6 |
| ai-sdlc-shared-skills | `act-common-deliver-change` | Aceptable | 6 | 6 |
| ai-sdlc-shared-skills | `act-common-apply-sarif` | Aceptable | 6 | 6 |
| ai-sdlc-shared-skills | `act-common-write-report` | Aceptable | 5 | 5 |
| ai-sdlc-kb-java | `act-java-run-build` | Aceptable | 5 | 5 |
| ai-sdlc-shared-skills | `proc-pr-review` | Mínimo | 3 | 3 |
| ai-sdlc-shared-skills | `proc-sarif-remediation` | Mínimo | 3 | 3 |
| ai-sdlc-shared-skills | `act-common-scan-security` | Mínimo | 3 | 3 |
| ai-sdlc-kb-java | `act-java-check-style` | Mínimo | 3 | 3 |
| ai-sdlc-kb-java | `act-java-check-coverage` | Mínimo | 3 | 3 |
| ai-sdlc-kb-java | `kb-java-best-practices`, `std-java-coding` | Exentas | — | — |

`ai-sdlc-platform` no tiene skills.

## Relación con los tests deterministas

`test_gh_pr.py`, `test_deliver_change.py`, `test_sarif.py` y `test_java_build.py` cubren los scripts de las skills. Los escenarios cubren el comportamiento del modelo. No se duplican.

## Material de referencia

- La demo de revisión de PRs, equivalente manual de `/review-pr-java`: [demo en Claude Code](../../out-git/demo-pr-review/README.es.md).
- Los controles de seguridad que los escenarios hostiles de la remediación ponen a prueba: [sarif-remediation-java-flow.md](sarif-remediation-java-flow.md#controles-de-seguridad).

## Brechas

- No hay un ejecutor que corra los escenarios y emita el veredicto. Falta decidirlo: ver [mejoras-pendientes.md](mejoras-pendientes.md#n13-ejecutor-de-escenarios).
- La revisión Java no tiene una suite automática propia.
