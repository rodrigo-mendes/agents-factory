# Mejoras cerradas

> **Para quién:** quien quiere saber por qué se cerró una mejora o de dónde viene una decisión.
> **Qué responde:** qué mejoras del inventario original están cumplidas u obsoletas, y por qué.

**Conclusión:** de las 22 mejoras originales, **14 son obsoletas** y **4 están cumplidas**. Las 4 restantes (#9, #14, #19, #20) siguen abiertas y están en [mejoras-pendientes.md](mejoras-pendientes.md).

El inventario original se escribió sobre los paquetes `pr-validator` y `java-reviewer` (con `fetch-pr.sh`, `catalog.md` y tres skills `java-*-review`). Esos paquetes **ya no existen**:
- la revisión la hace el agente `backend-java` con `proc-pr-review` y `gh_pr.py` ([pr-review-java-flow.md](pr-review-java-flow.md));
- se entra por la skill de entrada `review-pr-java` ([puntos-de-entrada.md](puntos-de-entrada.md)).

Las rutas que se citan abajo (`pr-validator/…`, `java-reviewer/…`) son historia. El texto completo de cada mejora está en el historial de git de `mejoras-pendientes.md`.

## Cumplidas

| # | Mejora original | Cómo se cumplió |
|---|---|---|
| 11 | El README describía refs `#main` y el `apm.yml` pinaba SHAs | El README de `ai-sdlc-platform` describe el `apm.yml` agregador y los repos reales (2026-10-15) |
| 12 | `/review-pr` documentado, pero sin punto de entrada | Existe la skill de entrada `review-pr-java` (`ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md`) con `context: fork`, `agent: backend-java`, `disable-model-invocation: true` y la delegación en el texto ([ADR 0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md), [ADR 0023](../1-blueprint/5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md)) |
| 16 | `.gitignore` ignoraba `build/` por rutas exactas | `.gitignore` ignora `build/` y `apm_modules/` |
| 22 | El control de invocación estaba en prosa, no en el frontmatter | Las skills internas llevan `user-invocable: false`. `review-pr-java` lleva `disable-model-invocation: true`, efectivo solo en Claude Code. En Antigravity el único freno es la `description` ("úsalo solo cuando el usuario lo pida") |

### Nota sobre #12 y #22: el prompt y el wrapper

Hubo una etapa intermedia que ya no existe:
- un prompt `.apm/prompts/review-pr-java.prompt.md`, que APM convertía en command de Claude;
- una skill wrapper `pr-review-java` con el fork.

Se retiraron por el [ADR 0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md): un paquete agnóstico usa solo agentes y skills.

Los prompts no se despliegan en ningún target de APM y los commands solo existen en Claude Code. El ADR 0012, que mantenía los commands, está reemplazado.

## Obsoletas

| # | Mejora original | Por qué ya no aplica |
|---|---|---|
| 21 | La cadena de delegación no era ejecutable (`tools: Bash` sin `Agent`) | `backend-java` no delega en subagentes: `proc-pr-review` ejecuta los roles en su contexto |
| 1 | `fetchFile` como callback no cruzaba la frontera de subagente | No hay callback. El patch se escribe una vez y cada rol lo localiza con `gh_pr.py patch --expect-sha` |
| 2 | El campo `id` de los findings no lo generaba nadie | El contrato actual (`findings-contract.md`) no tiene `id`; `rule` identifica la regla |
| 3 | `fetch-pr.sh` dependía del cwd | `fetch-pr.sh` no existe. `gh_pr.py` se ejecuta con ruta absoluta |
| 4 | Placeholder no ejecutable dentro de un comando `gh` | El agente no ejecuta `gh` directamente: todo pasa por `gh_pr.py` |
| 5 | `java-test-review` sin vía de escape | La skill no existe. Los tests se evalúan en `act-java-check-style` y `act-java-check-coverage` |
| 6 | "PR" filtrado en una skill que no debía conocerlo | La skill no existe |
| 7 | `catalog.md` con una sola fila | No hay `catalog.md`. El conocimiento Java está en `kb-java-best-practices` |
| 8 | Referencia a una "sección 6.2" inexistente | Las tres skills no existen |
| 10 | El template escribía un `headSha` que no podía leer | El informe empieza con `<!-- ai-sdlc-review sha=<SHA> -->` y `gh_pr.py` lo lee en `comment`, `publish` y `verify` |
| 13 | El README afirmaba versionar 4 ficheros | El README ya no enumera ficheros |
| 15 | Dos modelos de empaquetado coexistían | No hay `build/` ni bundle único; el catálogo anuncia un plugin, `backend-java` |
| 17 | `GEMINI.md` con un include colgante | El paquete no existe |
| 18 | Ficheros basura y directorios vacíos de residuo de build | Los paquetes no existen |

### Lecciones que siguen vigentes

Aunque los paquetes ya no existen, varias mejoras dejaron reglas que se mantienen:
- **#21:** una lista `tools` explícita sustituye a las heredadas. Sin `Agent` (o `Task`), un agente no puede delegar.
  - En Antigravity, el aprovisionador traduce `Task`/`Agent` a `invoke_subagent` ([runtime-antigravity.md](../1-blueprint/2-primitivos/runtime-antigravity.md#traducción-del-aprovisionador)).
- **#1:** por la frontera de un subagente solo pasa texto. Ni callbacks ni estado compartido.
- **#3:** lo que un agente necesita para ser correcto se garantiza por construcción (rutas absolutas, argumentos), no por prosa.
- **#8:** las referencias cruzadas citan el nombre de la sección, no solo su número.
- **#22:** una skill con `disable-model-invocation: true` no se puede precargar en un subagente (Claude Code).

## Decisiones registradas

Se tomaron sobre `pr-validator`/`java-reviewer`.

| Fecha | Decisión | Estado hoy |
|---|---|---|
| 2026-09-23 | La publicación en GitHub nunca se ejecuta sin una persona delante | **En revisión:** el CI publica sin persona delante (mejora #9 en [mejoras-pendientes.md](mejoras-pendientes.md#9-el-ci-publica-sin-una-persona-delante)) |
| 2026-09-23 | Para #1, comando de fetch parametrizado en lugar de prefetch total | Sin objeto: no hay fetch por callback |
| 2026-09-24 | Para #21, las skills de review por precarga (`skills:`), no por la herramienta `Skill` | Sin objeto: no hay skills de review precargadas |
| 2026-09-24 | El punto de entrada es una skill, no un fichero en `commands/` | **Vigente** y generalizada: ningún punto de entrada usa commands ni prompts ([ADR 0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md)) |
