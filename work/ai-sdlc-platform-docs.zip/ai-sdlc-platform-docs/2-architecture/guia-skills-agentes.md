# Guía de introducción: skills y agentes

> **Para quién / qué responde:** para cualquiera que tenga que decidir, pedir o entender una skill o un agente, sin saber programar. Qué es cada cosa y cuándo pedir cada una. No hay código en este documento.
>
> El análisis técnico de trade-offs está en [`skills-vs-subagentes.md`](skills-vs-subagentes.md).

**Conclusión:** una skill es un manual que el asistente aplica en tu conversación; un agente es un especialista que trabaja aparte y vuelve solo con la conclusión. Funciona igual en los dos asistentes que usamos, Claude Code y Antigravity.

---

## 1. El problema que resuelven las dos cosas

Un asistente de IA sabe muchas cosas generales y **ninguna** cosa nuestra. No sabe que en
MyInvestor una Pull Request tiene que llevar referencia a un ticket. No sabe qué consideramos
un fallo grave y qué es un detalle menor. No sabe dónde están nuestros documentos de
estándares.

Hay dos maneras de darle eso:

**Una [skill](../1-blueprint/2-primitivos/skills.md) es un manual.** Un documento con instrucciones que el asistente lee y aplica
él mismo, en la misma conversación en la que estás tú. Como darle a alguien una hoja con
el checklist y decirle "revisa esto siguiendo la hoja".

**Un [agente](../1-blueprint/2-primitivos/subagents.md) es un especialista al que le encargas el trabajo.** Va, lo hace por su cuenta,
y vuelve con la conclusión. Como mandar un expediente al departamento de riesgos: no ves
cómo lo analizan, recibes el veredicto.

Esa es toda la diferencia de fondo. Todo lo demás se deriva de ahí.

---

## 2. La diferencia que importa: qué queda encima de la mesa

Imagina una mesa de trabajo. Todo lo que el asistente está usando ahora mismo está encima
de esa mesa: tu pregunta, los documentos que ha abierto, las notas que ha tomado. La mesa
tiene un tamaño limitado.

Cuando se llena, las cosas del fondo se caen — y son justamente
las primeras que pusiste: tus instrucciones iniciales.

**Con una skill, todo se queda encima de tu mesa.** Si el trabajo implica abrir 30
documentos, esos 30 documentos ocupan tu mesa. Aunque ya no los necesites. Y las
instrucciones que diste al principio son las que empiezan a caerse.

**Con un agente, el trabajo pasa en otra mesa.** El especialista abre sus 30 documentos en
su propia mesa, saca una conclusión, te entrega un folio con el resultado y tira el resto.
Tu mesa solo recibe el folio.

Por eso la pregunta que decide siempre es la misma:

> **¿El material de trabajo hace falta después, o solo hace falta el resultado?**

Hace falta después → skill (manual). Solo el resultado → agente (especialista).

---

## 3. Las tres cosas que un agente NO puede hacer

Esto es lo que se olvida y lo que provoca los errores caros. Un especialista que trabaja
en otra sala tiene tres limitaciones inevitables:

### 3.1 No te puede preguntar a mitad del trabajo

Se va con el encargo y vuelve con el resultado. No hay teléfono. Si a mitad del análisis
descubre algo que requiere una decisión tuya, no puede consultarte: **decide él**, con las
instrucciones que le diste al principio.

*Ejemplo real de nuestro repo.* Nuestro revisor de Pull Requests es un agente. Publicar
comentarios en la Pull Request notifica al autor y queda en el historial, y el agente no
puede pararse a preguntar *"¿los publico?"*.

Por eso se le encarga siempre con la orden "no
publiques": devuelve el informe y es el informe el que, ya en tu conversación, te pregunta si
publicarlo. Publicar es un segundo encargo, no parte del primero.

**Regla:** si en algún momento hace falta un "¿seguro?" humano, esa parte no puede ser un
agente.

### 3.2 Solo te puede entregar texto

Por la puerta de la sala solo pasan folios. No puedes darle al especialista una llave para
que entre a buscar cosas él mismo, ni él puede devolverte algo que no quepa en un folio.

Suena abstracto, pero un diseño anterior de nuestro revisor falló justo aquí: asumía que
quien le encargaba el trabajo le daba "una forma de pedir ficheros adicionales". Eso no pasa
por la puerta.

El diseño actual lo resuelve sin pasar nada: los cambios a revisar se guardan
en un sitio con un nombre fijo, y cada parte del revisor sabe encontrarlos.

**Regla:** si el encargo o el resultado necesitan ser algo más que un documento de texto,
el diseño está mal planteado.

### 3.3 No ves cómo ha trabajado

Recibes la conclusión, no el razonamiento. Cuando el resultado es raro, no puedes mirar
atrás para ver dónde se torció. Solo puedes cambiar el encargo y volver a intentarlo.

**Regla:** un agente necesita que su encargo y su resultado estén definidos por escrito y
con precisión, porque es lo único que vas a poder inspeccionar.

---

## 4. Y las tres cosas que una skill no puede hacer

Por simetría, el manual también tiene límites. Los tres valen para un manual que se aplica
**en tu mesa**, que es el caso normal y el de todos los nuestros:

**Hace lo que tú puedes hacer.** Un manual se aplica con tus permisos. En Claude Code se le
pueden quitar permisos concretos ("mientras esto esté activo, no escribas ficheros"); en
Antigravity, ni eso. El punto de partida siempre es el tuyo.

Con un especialista es al revés: se le contrata con una lista cerrada de
lo que puede hacer, y todo lo que no esté en la lista le resulta *estructuralmente imposible*.
Nuestro revisor de código está así: solo puede leer y ejecutar consultas, no puede modificar
el código que revisa ni queriendo.

Esa lista cerrada tiene un filo que nos cortó en un diseño anterior: si te olvidas de
incluir "puede encargar trabajo a otro especialista", no puede, y nada te avisa (mejora #21
del inventario, ya resuelta).

**No trabaja en paralelo.** Un manual se lee y se aplica de principio a fin. Si hay que hacer
cinco análisis independientes, se hacen uno detrás de otro. Cinco especialistas trabajan a la
vez.

**No se reutiliza limpiamente entre contextos distintos.** El manual ve todo lo que hay en
tu mesa, así que acabará usando cosas que no debería.

Un especialista en otra sala solo ve
lo que le has entregado, y eso es lo que permite que el mismo especialista trabaje para
proyectos distintos sin contaminarse.

> **Matiz que conviene saber que existe.** Un manual puede pedir "esto no se aplica aquí,
> mándalo a una sala aparte". Entonces se comporta como un especialista: trabaja fuera de tu
> mesa y no puede preguntarte nada. Los tres límites de arriba dejan de aplicarle.
>
> Nuestra revisión de Pull Requests lo usa: el manual que tecleas, `/review-pr-java`, solo
> sirve de puerta y manda el trabajo al especialista. En Claude Code lo pide en su cabecera;
> en Antigravity, que no lee esa cabecera, lo pide en el propio texto. Detalle en
> [`puntos-de-entrada.md`](puntos-de-entrada.md).

---

## 5. Los tres tipos de skill, en lenguaje llano

No todas las skills son lo mismo. Hay tres usos, y confundirlos es el error más habitual.

### Tipo A — Manual de criterios

**Qué es:** una lista de cosas que comprobar, con el criterio de cada una.

**Analogía:** el checklist de un inspector. No decide a qué edificio va ni qué hace con el
informe. Solo dice qué mirar y cuándo algo está mal.

**Ejemplos nuestros:** tenemos tres. Uno para calidad de código, uno para seguridad, uno
para tests. Cada uno es una lista de problemas conocidos con su criterio de gravedad.

**Cómo se pide bien:** cada punto de la lista tiene que ser comprobable — de los que se
pueden contestar con sí o no. *"El código tiene que estar bien estructurado"* no vale, es
opinión. *"Un fichero abierto tiene que cerrarse siempre, incluso si hay un error"* sí vale.

**Señal de que lo estás pidiendo mal:** si tu lista incluye pasos del tipo "primero X,
luego Y, y si pasa Z entonces avisa a alguien", eso ya no es un manual de criterios. Es
coordinación — Tipo B.

### Tipo B — Manual de procedimiento (coordinador)

**Qué es:** el orden en que se hacen las cosas, qué requisitos hay que cumplir antes de
seguir, a quién se le encarga cada parte, y qué se hace con los resultados.

**Analogía:** el procedimiento de una oficina. "Primero comprueba que el expediente esté
completo. Si falta la firma, devuélvelo y para aquí. Si el importe pasa de X, manda el
expediente a riesgos. Cuando vuelva el informe, **pregúntale al cliente antes de ejecutar**."

**Su ventaja única:** es el único que puede pedir confirmación a una persona en medio del
proceso. Si no aprovechas eso, probablemente querías un agente.

**Cómo se pide bien:**
- Pasos numerados, en orden.
- Cada requisito marcado como **bloqueante** (si falla, se para todo) o **aviso** (si falla,
  se anota y se sigue). Sin esa distinción explícita, el asistente decide por su cuenta —
  y va a decidir distinto cada vez.
- Un punto de confirmación humana antes de cualquier acción que no se pueda deshacer:
  enviar un correo, publicar algo, borrar algo, mover dinero.

**Señal de que lo estás pidiendo mal:** si el procedimiento implica revisar 200 ficheros él
mismo, no es un coordinador. Un coordinador delega el trabajo pesado; si lo hace él, llena
la mesa y pierde el sentido.

### Tipo C — Carpeta de documentación

**Qué es:** conocimiento de la casa. Estándares, decisiones tomadas, convenciones. Nadie
"ejecuta" esta carpeta; otros manuales y otros especialistas la consultan.

**Analogía:** el archivo de la empresa. No hace nada por sí solo. Existe para que quien lo

necesite sepa dónde mirar.

**Ejemplo nuestro:** nuestro catálogo de conocimiento. Contiene los estándares de Spring
Boot de la casa y una tabla de correspondencia que dice qué documento aplica a qué tipo de
fichero.

**Cómo se pide bien:** que diga desde la primera línea que nadie la activa. Nuestro catálogo
lo hace literalmente, y el aviso está ahí porque alguien va a intentar meterle instrucciones
esperando que se cumplan solas. No se van a cumplir: es un archivo, no un procedimiento.

**Ventaja práctica:** el conocimiento que no se usa no ocupa mesa. Se abre solo el documento
que hace falta, no el archivo entero.

---

## 6. Cómo elegir

### Árbol de decisión

```mermaid
flowchart TD
    A["Quiero que el asistente<br/>sepa hacer algo nuevo"] --> B{"¿Es saber, o es hacer?"}

    B -->|"Conocimiento de la casa<br/>que otros consultan"| C["Carpeta de documentación<br/>(Tipo C)"]
    B -->|"Criterios para juzgar:<br/>qué mirar, qué está mal"| D["Manual de criterios<br/>(Tipo A)"]
    B -->|"Una secuencia de pasos"| E{"¿Hay que preguntar a<br/>una persona a mitad,<br/>o hacer algo que<br/>no se puede deshacer?"}

    E -->|"Sí"| F["Manual de procedimiento<br/>(Tipo B)<br/>+ especialista para<br/>la parte pesada"]
    E -->|"No"| G{"¿Hay que abrir y leer<br/>mucho material que<br/>después no hace falta?"}

    G -->|"Sí"| H["Especialista<br/>(agente)"]
    G -->|"No"| I{"¿Debe tener menos<br/>permisos que tú?<br/>¿O hay 5 análisis<br/>independientes a la vez?"}

    I -->|"Sí"| H
    I -->|"No"| J["Manual de procedimiento<br/>(Tipo B)"]

    H --> K{"¿El encargo y el resultado<br/>caben en un documento<br/>de texto?"}
    K -->|"No"| L["Replantear:<br/>por la puerta solo<br/>pasan folios"]
    K -->|"Sí"| M["Definir por escrito:<br/>qué recibe, qué devuelve,<br/>cuántos intentos tiene"]
```

### Atajo: la tabla del "quiero..."

| Quiero... | Pide un... | Por qué |
|---|---|---|
| Que aplique nuestros criterios de calidad al revisar | Manual de criterios (A) | Es saber juzgar, no hacer pasos |
| Que tenga a mano nuestros estándares | Carpeta de documentación (C) | Es archivo, no procedimiento |
| Que siga nuestro proceso de aprobación paso a paso | Manual de procedimiento (B) | Hay orden, requisitos y confirmaciones |
| Que revise 200 ficheros y me diga solo los problemas | Especialista (agente) | El material sobra después; solo quiero la conclusión |
| Que analice algo pero **no pueda modificar nada** | Especialista (agente) | Solo un especialista se puede contratar con menos permisos |
| Que haga 5 análisis independientes rápido | Especialista (agente) | Cinco a la vez; un manual va uno detrás de otro |
| Que me pregunte antes de publicar o enviar algo | Manual de procedimiento (B) | Un especialista no puede preguntar |
| Que lo usen también el equipo de CI y el IDE | Especialista (agente) | El encargo por escrito es lo que lo hace reutilizable |
| Que recuerde una preferencia mía para siempre | Ninguno de los dos | Eso es configuración, no capacidad |

---

## 7. Nuestro caso, explicado de principio a fin

Así funciona hoy nuestra revisión automática de Pull Requests, en Claude Code y en Antigravity. Usa las tres piezas.

**El encargo.** Un desarrollador teclea `/review-pr-java` con la Pull Request que quiere revisar.

**Paso 1 — La puerta.** Lo que tecleas es una skill de entrada: un manual corto que solo dice "esto lo hace el especialista de Java". Si no consigue pasárselo, se para y lo dice; nunca revisa por su cuenta.

**Paso 2 — El especialista recoge el material.** En su propia mesa, descarga de GitHub la lista de ficheros cambiados y los cambios concretos. Si no hay Pull Request o no hay cambios, se para y lo informa: nunca se inventa un cambio.

**Paso 3 — Aplica los manuales de criterios.** Uno detrás de otro: estilo, seguridad y tests. Cada uno devuelve sus hallazgos con una gravedad de una lista cerrada (bloqueante, aviso, sugerencia). Para la seguridad consulta la carpeta de documentación de la casa.

**Paso 4 — Junta y decide.** Quita duplicados y saca una recomendación: pedir cambios si hay algo bloqueante, comentar si solo hay avisos, aprobar si no hay nada. Si algún manual no pudo comprobarlo todo (por ejemplo, faltan datos de cobertura de tests), nunca recomienda aprobar.

**Paso 5 — Te entrega el folio.** Tu mesa solo recibe el informe, con la pregunta "¿lo publico?". **Nunca aprueba una Pull Request** — aprobar es una decisión humana.

**Paso 6 — Publicar, solo si tú lo pides.** Hay dos cerrojos que impiden publicar por accidente: los permisos del asistente y una traba en la propia herramienta de publicación. Si la Pull Request cambió desde la revisión, la publicación se rechaza.

Detalle técnico: [`pr-review-java-flow.md`](pr-review-java-flow.md).

**Otro caso, con escritura: corregir hallazgos de un escáner.** Alguien teclea `/remediate-sarif-java` con el informe SARIF de una herramienta de análisis. El coordinador no edita código: lee el informe como **datos** (nunca como órdenes), prepara una copia de trabajo aparte del proyecto y, por cada hallazgo, aplica la corrección, compila, pasa los tests y deja un commit. Cuando la corrección que traía el informe no vale, llama a un especialista que **sí puede editar pero no puede ejecutar nada** (es el único subagente del proceso). Si un hallazgo no se arregla en 3 intentos, se deshace y se sigue con el siguiente. Como un agente no puede preguntarte a mitad del trabajo, el proceso se hace **en pasos** (plan → aplicar → publicar), y publicar exige dos cerrojos; la Pull Request sale siempre como borrador. Detalle: [`sarif-remediation-java-flow.md`](sarif-remediation-java-flow.md).

---

## 8. Lo que suele salir mal

| Lo que pasa | Por qué pasa | Qué pedir en su lugar |
|---|---|---|
| "Escribí las instrucciones y no se aplican nunca" | Falta decir **cuándo** se usa, no solo qué hace | Añadir las condiciones de disparo *y* las de no-disparo |
| "Unas veces se aplica y otras no" | Dos manuales con descripciones parecidas; el asistente elige a suertes | Separarlos por un criterio que no se solape, o fusionarlos |
| "Funciona al principio y se degrada" | La mesa se llenó; las instrucciones iniciales se cayeron | Mover el trabajo pesado a un especialista |
| "Hizo algo que yo no habría aprobado" | Se encargó a un especialista algo que necesitaba confirmación humana | Esa parte va en un manual de procedimiento |
| "Da resultados distintos cada vez con lo mismo" | Las categorías de salida están abiertas y el asistente inventa sinónimos | Lista cerrada de valores posibles, y regla fija para los empates |
| "No sé por qué ha dicho eso" | Un especialista es una caja negra por definición | Definir por escrito qué recibe y qué devuelve; es lo único inspeccionable |
| "Modificó ficheros que no debía" | Un manual hereda tus permisos; como mucho se le recortan algunos, y solo en Claude Code | Especialista contratado sin permiso de escritura |
| "Montamos un especialista y no aportó nada" | Un solo cliente y poco material: se pagó el coste de la separación sin ninguna de sus ventajas | Era un manual |

---

## 9. Antes de pedirlo: seis preguntas

Contéstalas y quien lo implemente tendrá todo lo que necesita:

1. **¿Cuándo debe activarse, y cuándo no?** Lo segundo importa tanto como lo primero.
2. **¿Qué necesita para empezar?** Y qué debe hacer si algo de eso falta.
3. **¿Qué devuelve exactamente?** Qué campos, qué valores puede tomar cada uno.
4. **¿Qué requisitos son bloqueantes y cuáles son avisos?** Uno por uno.
5. **¿Hay alguna acción que no se pueda deshacer?** Si sí, quién la confirma y en qué punto.
6. **¿Cuántos intentos tiene, y qué hace si se agotan?** Nunca "descartar en silencio".

---

## 10. Glosario

Si quieres la explicación larga de cualquiera de estos términos, empieza desde cero en [`../1-blueprint/1-conceptos/README.md`](../1-blueprint/1-conceptos/README.md).

| Término | Qué es |
|---|---|
| **Skill** | Un manual de instrucciones que el asistente lee y aplica él mismo, en tu conversación |
| **[Skill de entrada](puntos-de-entrada.md)** (`/algo`) | Lo que teclas para invocar algo. No es un tipo distinto de cosa: es una skill, invocada a mano en lugar de por decisión del asistente. Puede mandar el trabajo a un especialista |
| **Skill forkeada** | En Claude Code, un manual que en su cabecera dice "mándame a una sala aparte". Se comporta como un especialista. Antigravity no lee esa cabecera: allí el manual lo pide en su texto |
| **Runtime / harness** | El asistente donde corre todo: Claude Code o Antigravity. Nuestros paquetes son **agnósticos**: el mismo paquete funciona en los dos |
| **Agente / [subagente](../1-blueprint/1-conceptos/2-primitivos-y-activacion/subagente-y-aislamiento-de-contexto.md)** | Un especialista que trabaja aparte y vuelve solo con la conclusión |
| **[Fork](../1-blueprint/2-primitivos/subagents.md)** | Palabra sobrecargada: tres cosas distintas la usan. Solo una de las tres hereda lo que hay en tu mesa. Si te la encuentras, mira [tres mecanismos que se confunden](../1-blueprint/2-primitivos/runtime-claude-code.md#tres-mecanismos-que-se-confunden) antes de asumir cuál es |
| **Herramienta** | Una capacidad concreta: leer ficheros, ejecutar comandos, encargar trabajo a un especialista. Un especialista solo tiene las que se le listan |
| **[Contexto](../1-blueprint/1-conceptos/1-fundamentos-del-modelo/ventana-de-contexto.md)** ("la mesa") | Todo lo que el asistente tiene presente ahora. Tamaño limitado; lo viejo se cae |
| **[Descripción](../1-blueprint/1-conceptos/2-primitivos-y-activacion/description-matching.md)** (de una skill o agente) | El texto que determina cuándo se usa. Es el mecanismo de activación por defecto. En Claude Code hay dos ajustes de cabecera que lo cambian; en Antigravity es el único |
| **[Contrato](../1-blueprint/1-conceptos/3-orquestacion/contrato-de-entrada-salida.md)** | Lo acordado por escrito: qué recibe y qué devuelve. Imprescindible para un especialista |
| **[Delegar](../1-blueprint/1-conceptos/3-orquestacion/delegacion-y-jerarquia-de-capas.md)** | Encargar una parte del trabajo a un especialista en lugar de hacerla uno mismo |
| **Requisito bloqueante** | Si no se cumple, se para todo. Lo contrario de un aviso |
| **Pull Request (PR)** | Una propuesta de cambio en el código, que alguien tiene que revisar y aprobar |
| **Hallazgo / finding** | Un problema concreto encontrado en una revisión, con su ubicación y su gravedad |
