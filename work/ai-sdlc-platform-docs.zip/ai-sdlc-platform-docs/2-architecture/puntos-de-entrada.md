# Puntos de entrada: todo `/nombre` es una skill

> **Para quién / qué responde:** para quien diseña o revisa un paquete. Por qué un punto de entrada es siempre una skill (nunca un command ni un prompt), cómo se escribe una skill de entrada y cómo corre `/review-pr-java` en Claude Code y en Antigravity.

**Conclusión:**
- Todo lo que una persona teclea como `/nombre` es una **skill de entrada** (`.apm/skills/<nombre>/SKILL.md`).
- Los commands y los prompts están **prohibidos** en cualquier paquete: no todos los runtimes los soportan.
- Si la skill tiene que correr dentro de un agente, lo declara en el frontmatter (para Claude) **y** lo pide en su texto (para cualquier runtime).

Decisiones: [0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md) (puntos de entrada como skills) y [0023](../1-blueprint/5-decisiones/2-orquestacion/0023-delegacion-explicita-en-el-texto.md) (delegación explícita en el texto).

---

## 1. Por qué una skill y no un command

Un paquete agnóstico usa solo agentes y skills (más `instructions`, hooks y MCP). El motivo está en la [matriz de targets de APM](https://microsoft.github.io/apm/reference/targets-matrix/#antigravity):

| Formato | Claude Code | Antigravity | ¿Se puede usar? |
|---|---|---|---|
| `prompts` (`.apm/prompts/`) | solo convertido en command | ❌ | **No** |
| `commands` (`.claude/commands/`) | ✅ | ❌ | **No** |
| `skills` | ✅ | ✅ | **Sí** |

- Un punto de entrada en `commands` o `prompts` no llega a Antigravity. No aparece, y no hay error.
- En los dos runtimes una skill ya funciona como comando: sale en el menú `/` y recibe el texto que sigue en `$ARGUMENTS`.
- Por tanto, un solo archivo sirve para los dos runtimes.

No hay excepción "solo para Claude". La tabla completa de primitivas está en [modelo de ejecución §1](../1-blueprint/3-modelo-operativo/modelo-ejecucion.md#1-regla-solo-agentes-y-skills).

---

## 2. Cómo se escribe una skill de entrada

Hay dos casos:

| Caso | Qué lleva | Ejemplo |
|---|---|---|
| **Skill inline** | Solo `name`, `description` y el cuerpo. Corre en el contexto de quien la llama | Un flujo corto cuyo resultado intermedio hace falta después |
| **Skill de entrada → agente** | Las cuatro piezas de abajo. Corre dentro de un agente concreto | `/review-pr-java` → `backend-java` |

### Las cuatro piezas de una skill de entrada que delega

1. **Frontmatter de Claude:** `context: fork` + `agent: <agente>`. En Claude ejecutan la skill dentro del agente.
2. **Freno a la activación automática:**
   - `disable-model-invocation: true` en Claude (el modelo no puede activarla solo);
   - una `description` con "úsalo solo cuando el usuario lo pida", que es **el único freno en Antigravity**.
3. **Delegación pedida en el texto**, con dos ramas:
   - "si no eres `<agente>`, delega en él la petición literal y espera su informe";
   - "si eres `<agente>`, ejecuta el proceso".
4. **Salida explícita:** "si no puedes delegar, detente y dilo". Evita que el proceso corra sin el agente.

Por qué las dos capas (frontmatter y texto):

| Campo o mecanismo | Claude Code | Antigravity |
|---|---|---|
| `name`, `description` | sí | sí |
| `argument-hint`, `$ARGUMENTS` | sí | sí (`$ARGUMENTS` comprobado) |
| `context: fork`, `agent:` | sí | se ignora |
| `disable-model-invocation`, `user-invocable` | sí | se ignora |
| Delegación escrita en el cuerpo | se lee, pero el fork ya entra en el agente | **es lo que hace delegar** (`invoke_subagent`) |

Plantilla y detalle: [puntos de entrada como skills](../1-blueprint/4-buenas-practicas/1-diseno-de-agentes-y-skills/puntos-de-entrada-como-skills.md) y [delegación explícita en el texto](../1-blueprint/4-buenas-practicas/2-orquestacion/delegacion-explicita-en-el-texto.md).

### Skill forkeada o agente con `skills:`

Las dos acaban en un subagente ejecutando conocimiento. Lo que cambia es **quién es dueño de la tarea**:

| | Agente con `skills: [a, b]` | Skill de entrada con fork + delegación |
|---|---|---|
| Quién define la tarea | el cuerpo del agente | el cuerpo de la skill |
| Qué se reutiliza | el agente, con distintas skills | la skill, como puerta a un agente |
| Ejemplo real | `backend-java-ci` (7 skills precargadas) | `review-pr-java` → `backend-java` |

En los dos casos el subagente arranca sin el historial de quien llama. La palabra "fork" designa tres cosas distintas en Claude Code: ver [tres mecanismos que se confunden](../1-blueprint/2-primitivos/runtime-claude-code.md#tres-mecanismos-que-se-confunden).

---

## 3. Caso real: `/review-pr-java`

Archivo: `ai-sdlc-backend-java/.apm/skills/review-pr-java/SKILL.md`.

```markdown
---
name: review-pr-java
description: Reviews a backend Java Pull Request with the backend-java agent. Use it only when the user explicitly asks to review a PR (…)
argument-hint: <PR> [focus]
context: fork
agent: backend-java
disable-model-invocation: true
---

<user_request>
$ARGUMENTS
</user_request>

## If you are not already the `backend-java` agent
Delegate this whole request, including <user_request> verbatim, to the `backend-java` subagent … If you cannot delegate, stop and say so …

## If you are the `backend-java` agent
Run the core skill `proc-pr-review` … Pass `publish=false` unless the user explicitly asks to publish …
```

Cómo corre en cada runtime:

```mermaid
flowchart LR
    U["/review-pr-java &lt;PR&gt; [foco]"] --> R{runtime}
    R -- "Claude Code:<br/>context: fork + agent:" --> A["Subagente backend-java<br/>(rama 'eres el agente')"]
    R -- "Antigravity:<br/>ignora el fork" --> M["Agente principal"]
    M -- "invoke_subagent<br/>(rama 'no eres el agente')" --> A
    M -- "no puede delegar" --> X["Se detiene y lo explica"]
    A --> P["proc-pr-review → roles → informe"]
```

| | Claude Code | Antigravity (`agy` 1.4.8) |
|---|---|---|
| Dónde corre la skill | dentro de `backend-java` (fork) | en el agente principal |
| Cómo llega al agente | `context: fork` + `agent:` | el texto pide delegar → `invoke_subagent` |
| Qué impide que se active sola | `disable-model-invocation: true` | solo la `description` |
| Origen del agente | desplegado por APM | generado por el aprovisionador ([0021](../1-blueprint/5-decisiones/4-estructura-del-repo/0021-aprovisionador-post-install-para-antigravity.md)) |
| Resultado en la demo | REQUEST_CHANGES (blocker por `@Autowired` en campo) | el mismo |

La salida "si no puedes delegar, detente" se comprobó en Antigravity: con el hook de prerrequisitos roto, la skill no pudo delegar, se detuvo y lo explicó, en lugar de revisar sin el agente.

Las demos paso a paso:
- [Demo en Claude Code](../../out-git/demo-pr-review/README.es.md)
- [Demo en Antigravity](../../out-git/demo-pr-review-agy/README.es.md)

### Segundo caso real: `/remediate-sarif-java`

Archivo: `ai-sdlc-backend-java/.apm/skills/remediate-sarif-java/SKILL.md`. Misma estructura de cuatro piezas (`context: fork` + `agent: backend-java-remediate`, `disable-model-invocation: true`, `<user_request>$ARGUMENTS</user_request>`, delegación en el texto con salida "si no puedes delegar, detente"), con dos diferencias:

- **Una skill forkeada no puede preguntar al usuario a mitad de la ejecución.** Por eso la entrada interactiva se parte en **pasos** (`/remediate-sarif-java <sarif…>` → `apply <run-id>` → `publish <run-id>`), con el estado en `run.json`, y el gate queda entre invocaciones ([0005](../1-blueprint/5-decisiones/3-control-y-calidad/0005-gate-antes-de-escribir.md), actualización 2026-11-03).
- **También hay entrada autónoma** (`mode=autonomous`, o headless con `claude -p` / `agy -p` accionando la misma skill), donde todo "preguntar" pasa a fallo con código.
- Fija el modelo con `model: sonnet` en su frontmatter (Antigravity lo ignora).

Detalle: [sarif-remediation-java-flow.md](sarif-remediation-java-flow.md).

### Historia

Antes, `ai-sdlc-backend-java` tenía dos piezas para la misma entrada: el prompt `.apm/prompts/review-pr-java.prompt.md` (que APM convertía en command de Claude) y la skill envoltorio `pr-review-java`.

Las dos se sustituyeron por la skill `review-pr-java` ([0020](../1-blueprint/5-decisiones/1-diseno-de-agentes-y-skills/0020-puntos-de-entrada-como-skills.md), que reemplaza a [0012](../1-blueprint/5-decisiones/4-estructura-del-repo/0012-mantener-commands-como-formato-separado.md)).

Para el usuario no cambia nada: sigue tecleando `/review-pr-java <PR> [foco]`.

---

## 4. Errores frecuentes

| Error | Qué pasa | Arreglo |
|---|---|---|
| Crear un command o un prompt | No llega a Antigravity, sin error | Convertirlo en skill de entrada |
| Delegar solo con `context: fork` + `agent:` | En Antigravity la skill corre en el agente principal, sin el agente | Pedir la delegación en el texto |
| Sin salida "si no puedes delegar, detente" | El proceso corre sin el agente y falla en silencio | Añadir la salida explícita |
| `description` genérica | En Antigravity el modelo puede activarla solo | "Úsalo solo cuando el usuario lo pida" |
| Fork sin `disable-model-invocation: true` | En Claude el modelo puede activarla solo | Añadir el campo |
| El mismo nombre en una skill y en un command | En Claude gana la skill; el command queda muerto | No crear commands |
| No pasar la petición literal al subagente | El subagente arranca vacío y no sabe qué revisar | `<user_request>$ARGUMENTS</user_request>` y "verbatim" |

---

## 5. Para seguir leyendo

- [Modelo de ejecución (agnóstico)](../1-blueprint/3-modelo-operativo/modelo-ejecucion.md):
  - reglas;
  - [entradas agnósticas](../1-blueprint/3-modelo-operativo/modelo-ejecucion.md#31-skill-de-entrada--agente);
  - [correspondencia entre runtimes](../1-blueprint/3-modelo-operativo/modelo-ejecucion.md#4-correspondencia-entre-runtimes).
- [Modelo de ejecución en Claude Code](../1-blueprint/3-modelo-operativo/modelo-ejecucion-claude-code.md): tipos de entrada, control de invocación y formato histórico.
- [Modelo de ejecución en Antigravity](../1-blueprint/3-modelo-operativo/modelo-ejecucion-antigravity.md): `invoke_subagent`, permisos y hooks.
- [Hooks portables entre runtimes](../1-blueprint/4-buenas-practicas/3-control-y-calidad/hooks-portables-entre-runtimes.md).
- [Skills vs. subagentes](skills-vs-subagentes.md): cuándo hace falta un contexto aparte.
- [Flujo de `/review-pr-java`](pr-review-java-flow.md): del punto de entrada al informe.
- [Flujo de `/remediate-sarif-java`](sarif-remediation-java-flow.md): del SARIF a la PR draft, con pasos y modo autónomo.
