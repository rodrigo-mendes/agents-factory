#!/usr/bin/env python3
"""
Markdown to Confluence Cloud Uploader

Sube contenido Markdown a Confluence Cloud usando REST API,
manteniendo la estructura jerárquica de carpetas.

Características:
    - Usa API REST v1/v2 oficial de Confluence Cloud
    - Convierte Markdown a HTML de almacenamiento de Confluence
    - Sube imágenes locales como attachments
    - Mantiene estructura de páginas y carpetas jerárquica
    - Gestiona bloques de código (convierte a macros Confluence)
    - Crea o actualiza páginas existentes
    - Reescribe enlaces relativos .md a URLs de Confluence en segunda pasada

Requisitos:
    - Python 3.9+
    - requests
    - markdown (pip install markdown)
    - beautifulsoup4 (pip install beautifulsoup4)
    - python-dotenv (pip install python-dotenv)

Configuración:
    Copia .env.template a .env y rellena los valores.
    Los argumentos de línea de comandos tienen prioridad sobre .env.

Uso:
    python markdown-2-confluence.py --url <URL> [--user <USER>] [--token <TOKEN>]
"""

import argparse
import requests
import os
import re
import time
import html as html_module
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote, unquote, urlparse, parse_qs
from typing import Dict, List, Optional, Tuple

try:
    import markdown as md_lib
    from bs4 import BeautifulSoup
    from dotenv import load_dotenv
except ImportError:
    print("Error: Faltan dependencias requeridas.")
    print("Por favor instala: pip install markdown beautifulsoup4 python-dotenv")
    exit(1)

# Valores por defecto (se sobreescriben desde .env, variables de entorno o CLI)
USER = ""
TOKEN = ""
BASE_URL = ""
SPACE = ""
ROOT_PAGE_ID = ""
INPUT_DIR = "input"

# Sesión HTTP global — se inicializa en main() tras resolver credenciales
session: requests.Session = requests.Session()

# MIME types para attachments
MIME_TYPES = {
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif":  "image/gif",
    ".svg":  "image/svg+xml",
    ".webp": "image/webp",
    ".pdf":  "application/pdf",
}


@dataclass
class RunContext:
    """Contexto de ejecución: métricas y datos para post-procesamiento de enlaces."""
    # {abs_md_path_str → {title, page_id, url_display}}
    pages_mapping: Dict[str, Dict] = field(default_factory=dict)
    # {page_id → confluence_html_con_links_sin_resolver}
    pending_html: Dict[str, str] = field(default_factory=dict)
    pages_created: int = 0
    pages_updated: int = 0
    images_uploaded: int = 0
    errors: int = 0


# ---------------------------------------------------------------------------
# Utilidades de nombre y título
# ---------------------------------------------------------------------------

def title_from_filename(filename: str) -> str:
    """Convierte nombre de archivo a título legible (inverso de clean_name)."""
    return Path(filename).stem.replace("_", " ")


def extract_title_from_markdown(content: str, fallback: str) -> Tuple[str, str]:
    """
    Extrae el título del primer heading # del Markdown.

    Returns:
        (title, content_sin_linea_de_titulo)
    """
    lines = content.split("\n")
    for i, line in enumerate(lines):
        if line.strip().startswith("# "):
            title = line.strip()[2:].strip()
            remaining = "\n".join(lines[:i] + lines[i + 1:]).lstrip("\n")
            return title, remaining
    return fallback, content


# ---------------------------------------------------------------------------
# Conversión Markdown → HTML de almacenamiento Confluence
# ---------------------------------------------------------------------------

def _convert_code_blocks(html: str) -> str:
    """
    Convierte <pre><code class="language-X">...</code></pre>
    a macros de código Confluence (<ac:structured-macro ac:name="code">).

    Usa placeholders <div class="__confluence_code__"> para sobrevivir al
    round-trip de BeautifulSoup sin que los namespaces ac:/ri: sean alterados.
    """
    soup = BeautifulSoup(html, "html.parser")

    for pre in soup.find_all("pre"):
        code_tag = pre.find("code")
        if not code_tag:
            continue

        language = ""
        for cls in code_tag.get("class", []):
            if cls.startswith("language-"):
                language = cls[9:]
                break

        # get_text() desescapa entidades HTML automáticamente
        code_text = code_tag.get_text()
        # Escapar ]]> dentro del código para no romper el CDATA
        code_text = code_text.replace("]]>", "]]]]><![CDATA[>")

        placeholder = (
            f'<div class="__confluence_code__"'
            f' data-language="{html_module.escape(language)}">'
            f"{html_module.escape(code_text)}"
            f"</div>"
        )
        pre.replace_with(BeautifulSoup(placeholder, "html.parser").find("div"))

    result = str(soup)

    def _build_macro(m: re.Match) -> str:
        language = html_module.unescape(m.group(1))
        code = html_module.unescape(m.group(2))
        lang_param = (
            f'<ac:parameter ac:name="language">{language}</ac:parameter>\n'
            if language
            else ""
        )
        return (
            f'<ac:structured-macro ac:name="code">\n'
            f"{lang_param}"
            f"<ac:plain-text-body><![CDATA[{code}]]></ac:plain-text-body>\n"
            f"</ac:structured-macro>"
        )

    return re.sub(
        r'<div class="__confluence_code__" data-language="([^"]*)">(.*?)</div>',
        _build_macro,
        result,
        flags=re.DOTALL,
    )


def _convert_images(html: str, image_map: Dict[str, str]) -> str:
    """
    Convierte <img src="..."> a macros <ac:image><ri:attachment> usando image_map.

    image_map: {src_en_markdown → attachment_filename_en_confluence}
    Las imágenes sin entrada en image_map se reemplazan por texto placeholder.
    Las imágenes externas (http/https) se dejan como están.
    """
    soup = BeautifulSoup(html, "html.parser")

    for img in soup.find_all("img"):
        src = img.get("src", "")
        if not src:
            continue

        if src.startswith("http://") or src.startswith("https://"):
            # Imagen externa — dejar en HTML estándar; Confluence lo renderiza
            continue

        attachment_filename = image_map.get(src)
        if not attachment_filename:
            img.replace_with(soup.new_string(f"[IMAGEN: {src}]"))
            continue

        height = img.get("height", "")
        width = img.get("width", "")
        attrs = f'data-filename="{html_module.escape(attachment_filename)}"'
        if height:
            attrs += f' data-height="{height}"'
        if width:
            attrs += f' data-width="{width}"'

        placeholder = f'<span class="__confluence_img__" {attrs}></span>'
        img.replace_with(BeautifulSoup(placeholder, "html.parser").find("span"))

    result = str(soup)

    def _build_img_macro(m: re.Match) -> str:
        snippet = m.group(0)
        filename_m = re.search(r'data-filename="([^"]*)"', snippet)
        height_m = re.search(r'data-height="([^"]*)"', snippet)
        width_m = re.search(r'data-width="([^"]*)"', snippet)
        filename = html_module.unescape(filename_m.group(1)) if filename_m else ""
        height_attr = f' ac:height="{height_m.group(1)}"' if height_m else ""
        width_attr = f' ac:width="{width_m.group(1)}"' if width_m else ""
        return (
            f'<ac:image{height_attr}{width_attr}>'
            f'<ri:attachment ri:filename="{filename}"/>'
            f"</ac:image>"
        )

    return re.sub(
        r'<span class="__confluence_img__"[^>]*></span>',
        _build_img_macro,
        result,
    )


def _convert_links(html: str) -> str:
    """
    Convierte <a href="relativo.md"> a esquema md-internal://ENCODED_PATH
    para su resolución en la segunda pasada (rewrite_internal_links).
    Las URLs absolutas y anclas se dejan sin cambios.
    """
    soup = BeautifulSoup(html, "html.parser")

    for a in soup.find_all("a"):
        href = a.get("href", "")
        if (
            not href
            or href.startswith("http://")
            or href.startswith("https://")
            or href.startswith("#")
            or href.startswith("mailto:")
        ):
            continue

        path_part = href.split("#")[0]
        if path_part.endswith(".md") or "/" in path_part:
            a["href"] = f'md-internal://{quote(href, safe="#")}'

    return str(soup)


def markdown_to_confluence_html(md_content: str, image_map: Dict[str, str]) -> str:
    """
    Convierte contenido Markdown a HTML de almacenamiento de Confluence.

    Pasos:
      1. Markdown → HTML estándar (markdown library)
      2. Bloques de código → macros <ac:structured-macro ac:name="code">
      3. Imágenes locales → macros <ac:image><ri:attachment>
      4. Enlaces relativos .md → esquema md-internal:// (para segunda pasada)

    Args:
        md_content: Markdown sin la primera línea de título (# Título)
        image_map: {src_en_md → attachment_filename_subido}

    Returns:
        HTML compatible con el formato storage de Confluence
    """
    extensions = ["fenced_code", "tables", "sane_lists", "attr_list"]
    html = md_lib.markdown(md_content, extensions=extensions)

    html = _convert_code_blocks(html)
    html = _convert_images(html, image_map)
    html = _convert_links(html)

    return html


# ---------------------------------------------------------------------------
# API de Confluence
# ---------------------------------------------------------------------------

def get_page_by_title(title: str, space_key: str) -> Optional[Dict]:
    """Busca una página por título exacto en el espacio dado."""
    try:
        url = f"{BASE_URL}/rest/api/content"
        params = {
            "title": title,
            "spaceKey": space_key,
            "type": "page",
            "expand": "version",
        }
        resp = session.get(url, params=params, timeout=30)
        if resp.status_code == 200:
            results = resp.json().get("results", [])
            if results:
                return results[0]
        return None
    except Exception as e:
        print(f"    ✗ Error buscando página '{title}': {e}")
        return None


def create_page(
    title: str, content: str, parent_id: str, space_key: str
) -> Optional[Dict]:
    """Crea una nueva página en Confluence como hija de parent_id."""
    try:
        url = f"{BASE_URL}/rest/api/content"
        payload = {
            "type": "page",
            "title": title,
            "space": {"key": space_key},
            "ancestors": [{"id": parent_id}],
            "body": {
                "storage": {"value": content, "representation": "storage"}
            },
        }
        resp = session.post(url, json=payload, timeout=30)
        if resp.status_code in (200, 201):
            return resp.json()
        print(f"    ✗ Error HTTP {resp.status_code} creando '{title}'")
        if resp.text:
            print(f"      {resp.text[:300]}")
        return None
    except Exception as e:
        print(f"    ✗ Error creando página '{title}': {e}")
        return None


def update_page(
    page_id: str, title: str, content: str, current_version: int
) -> Optional[Dict]:
    """Actualiza el contenido de una página existente incrementando su versión."""
    try:
        url = f"{BASE_URL}/rest/api/content/{page_id}"
        payload = {
            "type": "page",
            "title": title,
            "version": {"number": current_version + 1},
            "body": {
                "storage": {"value": content, "representation": "storage"}
            },
        }
        resp = session.put(url, json=payload, timeout=30)
        if resp.status_code == 200:
            return resp.json()
        print(f"    ✗ Error HTTP {resp.status_code} actualizando '{title}'")
        if resp.text:
            print(f"      {resp.text[:300]}")
        return None
    except Exception as e:
        print(f"    ✗ Error actualizando página '{title}': {e}")
        return None


def _get_page_version(page_id: str) -> int:
    """Obtiene el número de versión actual de una página."""
    try:
        url = f"{BASE_URL}/rest/api/content/{page_id}"
        resp = session.get(url, params={"expand": "version"}, timeout=30)
        if resp.status_code == 200:
            return resp.json().get("version", {}).get("number", 1)
    except Exception:
        pass
    return 1


def upload_attachment(
    page_id: str, file_path: Path, ctx: RunContext
) -> Optional[str]:
    """
    Sube un archivo como attachment a una página de Confluence.
    Si ya existe un attachment con ese nombre, lo actualiza.

    La subida usa multipart/form-data, por lo que se hace una request directa
    sin el header Content-Type: application/json de la sesión principal.

    Returns:
        Nombre del archivo subido, o None si falla.
    """
    filename = file_path.name
    mime_type = MIME_TYPES.get(file_path.suffix.lower(), "application/octet-stream")

    try:
        # Verificar si ya existe un attachment con ese nombre
        check_url = f"{BASE_URL}/rest/api/content/{page_id}/child/attachment"
        check_resp = session.get(
            check_url, params={"filename": filename}, timeout=30
        )
        existing_att_id = None
        if check_resp.status_code == 200:
            results = check_resp.json().get("results", [])
            if results:
                existing_att_id = results[0]["id"]

        # Headers para multipart — omitir Content-Type JSON de la sesión
        upload_headers = {
            k: v
            for k, v in session.headers.items()
            if k.lower() not in ("content-type", "accept")
        }
        upload_headers["X-Atlassian-Token"] = "no-check"
        upload_headers["Accept"] = "application/json"

        if existing_att_id:
            upload_url = (
                f"{BASE_URL}/rest/api/content/{page_id}"
                f"/child/attachment/{existing_att_id}/data"
            )
        else:
            upload_url = (
                f"{BASE_URL}/rest/api/content/{page_id}/child/attachment"
            )

        with open(file_path, "rb") as f:
            resp = requests.post(
                upload_url,
                auth=session.auth,
                files={"file": (filename, f, mime_type)},
                headers=upload_headers,
                timeout=60,
            )

        if resp.status_code in (200, 201):
            ctx.images_uploaded += 1
            print(f"      ✓ Imagen subida: {filename}")
            return filename

        print(f"      ✗ Error HTTP {resp.status_code} subiendo '{filename}'")
        if resp.text:
            print(f"        {resp.text[:200]}")
        return None

    except Exception as e:
        print(f"      ✗ Error subiendo imagen '{filename}': {e}")
        return None


# ---------------------------------------------------------------------------
# Procesamiento de archivos Markdown
# ---------------------------------------------------------------------------

def _collect_local_images(md_file: Path) -> Dict[str, Path]:
    """
    Detecta referencias a imágenes locales en el archivo Markdown.

    Returns:
        {src_en_markdown → ruta_absoluta_del_archivo_de_imagen}
    """
    try:
        content = md_file.read_text(encoding="utf-8")
    except Exception:
        return {}

    images: Dict[str, Path] = {}
    # Sintaxis Markdown: ![alt](ruta) o ![alt](ruta "título")
    for m in re.finditer(r"!\[[^\]]*\]\(([^)\"]+)", content):
        src = m.group(1).strip()
        if src.startswith("http://") or src.startswith("https://"):
            continue
        abs_path = (md_file.parent / src).resolve()
        if abs_path.exists():
            images[src] = abs_path

    return images


def process_markdown_file(
    md_path: Path,
    parent_id: str,
    space_key: str,
    ctx: RunContext,
) -> Optional[str]:
    """
    Sube un archivo .md a Confluence siguiendo estos pasos:
      1. Leer el archivo y extraer título.
      2. Crear la página (o localizarla si ya existe) para obtener su ID.
      3. Subir las imágenes referenciadas como attachments.
      4. Convertir el Markdown a HTML de Confluence.
      5. Actualizar la página con el contenido final.
      6. Registrar en ctx para la segunda pasada de enlaces.

    Returns:
        ID de la página creada/actualizada, o None si falla.
    """
    print(f"\n📄 Procesando: {md_path.name}")

    try:
        content = md_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"  ✗ Error leyendo archivo: {e}")
        ctx.errors += 1
        return None

    fallback = title_from_filename(md_path.name)
    title, body = extract_title_from_markdown(content, fallback)
    print(f"  📝 {title}")

    # Paso 1: Obtener o crear la página para disponer del page_id
    existing = get_page_by_title(title, space_key)

    if existing:
        page_id = existing["id"]
        current_version = existing.get("version", {}).get("number", 1)
        print(f"  🔄 Página existente (ID: {page_id}, v{current_version})")
    else:
        result = create_page(
            title, "<p>Subiendo contenido...</p>", parent_id, space_key
        )
        if not result:
            ctx.errors += 1
            return None
        page_id = result["id"]
        current_version = 1
        ctx.pages_created += 1
        print(f"  ✨ Página creada (ID: {page_id})")

    # Paso 2: Subir imágenes y construir mapa src → filename
    local_images = _collect_local_images(md_path)
    image_map: Dict[str, str] = {}

    for src, abs_path in local_images.items():
        print(f"    📷 Subiendo imagen: {abs_path.name}")
        uploaded = upload_attachment(page_id, abs_path, ctx)
        if uploaded:
            image_map[src] = uploaded

    # Paso 3: Convertir Markdown a HTML de Confluence
    confluence_html = markdown_to_confluence_html(body, image_map)

    # Paso 4: Actualizar página con contenido real
    # Para páginas recién creadas la versión es 1; update_page la incrementa a 2.
    result = update_page(page_id, title, confluence_html, current_version)

    if result:
        if existing:
            ctx.pages_updated += 1
        print(f"  ✓ Guardado: {title}")
    else:
        ctx.errors += 1

    # Registrar en mapeo para segunda pasada de enlaces
    url_display = (
        f"{BASE_URL}/spaces/{space_key}/pages/{page_id}/{quote(title)}"
    )
    ctx.pages_mapping[str(md_path.resolve())] = {
        "title": title,
        "page_id": page_id,
        "url_display": url_display,
    }
    # Guardar HTML con enlaces sin resolver para la segunda pasada
    if "md-internal://" in confluence_html:
        ctx.pending_html[page_id] = confluence_html

    return page_id


def process_directory(
    dir_path: Path,
    parent_id: str,
    space_key: str,
    ctx: RunContext,
    is_root: bool = False,
) -> Optional[str]:
    """
    Sube recursivamente un directorio de Markdown a Confluence.

    Estructura esperada (espejo del output del conversor inverso):
        Carpeta/
            Carpeta.md          →  página padre de la sección
            OtraPagina.md       →  página hija
            SubCarpeta/
                SubCarpeta.md
                Hija.md
            images/             →  ignorado (procesado junto a cada .md)

    Si no existe Carpeta.md se crea una página padre vacía con el nombre
    de la carpeta como título.

    Args:
        is_root: Si True, los archivos .md del directorio se cuelgan
                 directamente de parent_id sin crear página intermedia.

    Returns:
        ID de la página padre de esta sección.
    """
    print(f"\n📁 Procesando directorio: {dir_path.name}")

    folder_page_id = parent_id

    if not is_root:
        parent_md = dir_path / f"{dir_path.name}.md"

        if parent_md.exists():
            result_id = process_markdown_file(
                parent_md, parent_id, space_key, ctx
            )
            folder_page_id = result_id or parent_id
        else:
            # Crear página padre vacía con el nombre humanizado de la carpeta
            folder_title = dir_path.name.replace("_", " ")
            existing = get_page_by_title(folder_title, space_key)

            if existing:
                folder_page_id = existing["id"]
                print(
                    f"  🔄 Sección existente: {folder_title} "
                    f"(ID: {folder_page_id})"
                )
            else:
                result = create_page(
                    folder_title, "<p></p>", parent_id, space_key
                )
                if result:
                    folder_page_id = result["id"]
                    ctx.pages_created += 1
                    print(
                        f"  ✨ Sección creada: {folder_title} "
                        f"(ID: {folder_page_id})"
                    )

    # Procesar archivos .md del directorio (excepto el de la sección)
    skip_name = f"{dir_path.name}.md"
    for md_file in sorted(dir_path.glob("*.md")):
        if md_file.name == skip_name:
            continue
        process_markdown_file(md_file, folder_page_id, space_key, ctx)

    # Procesar subdirectorios recursivamente (omitir 'images')
    for subdir in sorted(
        d for d in dir_path.iterdir() if d.is_dir() and d.name != "images"
    ):
        process_directory(subdir, folder_page_id, space_key, ctx)

    return folder_page_id


# ---------------------------------------------------------------------------
# Segunda pasada: reescritura de enlaces internos
# ---------------------------------------------------------------------------

def rewrite_internal_links(input_dir: Path, ctx: RunContext) -> int:
    """
    Segunda pasada: sustituye en todas las páginas subidas los esquemas
    md-internal://ENCODED_PATH por las URLs reales de Confluence.

    Patrones resueltos:
      - md-internal://relativo/a/Pagina.md     →  URL display de la página
      - md-internal://relativo/a/Pagina.md%23anchor  →  URL + #anchor

    Returns:
        Número de páginas actualizadas en Confluence.
    """
    if not ctx.pending_html:
        return 0

    modified = 0

    for abs_md_path_str, entry in ctx.pages_mapping.items():
        page_id = entry["page_id"]
        html = ctx.pending_html.get(page_id)
        if not html:
            continue

        original = html

        def replace_md_link(m: re.Match, source: str = abs_md_path_str) -> str:
            raw = unquote(m.group(1))
            raw_path = raw.split("#")[0]
            anchor = "#" + raw.split("#")[1] if "#" in raw else ""

            # Resolver ruta relativa desde el archivo fuente
            source_dir = Path(source).parent
            try:
                target_abs = str((source_dir / raw_path).resolve())
            except Exception:
                return m.group(0)

            target = ctx.pages_mapping.get(target_abs)
            if target:
                return f'href="{target["url_display"]}{anchor}"'

            # Fallback: buscar por stem del archivo (sin extensión)
            target_stem = Path(raw_path).stem
            for path_str, ent in ctx.pages_mapping.items():
                if Path(path_str).stem == target_stem:
                    return f'href="{ent["url_display"]}{anchor}"'

            return m.group(0)

        html = re.sub(r'href="md-internal://([^"]+)"', replace_md_link, html)

        if html != original:
            version = _get_page_version(page_id)
            result = update_page(page_id, entry["title"], html, version)
            if result:
                modified += 1
                print(f"  🔗 Enlaces actualizados en: {entry['title']}")

    if modified:
        print(f"\n🔗 {modified} página(s) con enlaces internos reescritos")

    return modified


# ---------------------------------------------------------------------------
# Parseo de URL de Confluence
# ---------------------------------------------------------------------------

def _parse_confluence_url(url: str) -> Dict[str, str]:
    """
    Extrae BASE_URL, SPACE y ROOT_PAGE_ID de una URL de Confluence.

    Formatos soportados:
      https://empresa.atlassian.net/wiki/spaces/SPACE/pages/123456/Titulo
      https://empresa.atlassian.net/wiki/spaces/SPACE/overview
      https://empresa.atlassian.net/wiki/pages/viewpage.action?pageId=123456
    """
    url = re.sub(r"\\([?&=])", r"\1", url)
    clean_url = url.split("?")[0].replace("\\", "")
    parsed = urlparse(clean_url)
    path_parts = [p for p in parsed.path.split("/") if p]
    result: Dict[str, str] = {}

    try:
        wiki_idx = path_parts.index("wiki")
        base_path = "/" + "/".join(path_parts[: wiki_idx + 1])
        result["base_url"] = f"{parsed.scheme}://{parsed.netloc}{base_path}"
    except ValueError:
        result["base_url"] = f"{parsed.scheme}://{parsed.netloc}"

    if "spaces" in path_parts:
        idx = path_parts.index("spaces")
        if idx + 1 < len(path_parts):
            result["space"] = path_parts[idx + 1]

    for segment in ("pages", "folder", "overview"):
        if segment in path_parts:
            idx = path_parts.index(segment)
            candidate = path_parts[idx + 1] if idx + 1 < len(path_parts) else ""
            if candidate.isdigit():
                result["page_id"] = candidate
                break

    if "page_id" not in result:
        qs = parse_qs(urlparse(url).query)
        if "pageId" in qs:
            result["page_id"] = qs["pageId"][0]

    return result


# ---------------------------------------------------------------------------
# Punto de entrada
# ---------------------------------------------------------------------------

def main():
    global USER, TOKEN, BASE_URL, SPACE, ROOT_PAGE_ID, INPUT_DIR

    parser = argparse.ArgumentParser(
        description="Sube contenido Markdown a Confluence Cloud.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  # Usando URL de la página padre en Confluence:
  python markdown-2-confluence.py \\
      --url "https://empresa.atlassian.net/wiki/spaces/SPACE/pages/123456" \\
      --user tu@email.com --token TU_TOKEN

  # Usando parámetros individuales:
  python markdown-2-confluence.py \\
      --base-url https://empresa.atlassian.net/wiki \\
      --space SPACE --parent-id 123456 \\
      --user tu@email.com --token TU_TOKEN --input ./docs
""",
    )
    parser.add_argument(
        "--url",
        help="URL de la página padre en Confluence "
        "(extrae automáticamente base-url, space y parent-id)",
    )
    parser.add_argument(
        "--user",
        help="Email/usuario de Confluence (o CONFLUENCE_USER en .env/entorno)",
    )
    parser.add_argument(
        "--token",
        help="Token de API de Confluence (o CONFLUENCE_TOKEN en .env/entorno)",
    )
    parser.add_argument(
        "--base-url",
        dest="base_url",
        help="Base URL del wiki (o CONFLUENCE_BASE_URL en .env)",
    )
    parser.add_argument(
        "--space",
        help="Clave del espacio Confluence (o CONFLUENCE_SPACE en .env)",
    )
    parser.add_argument(
        "--parent-id",
        dest="parent_id",
        help="ID de la página padre (o CONFLUENCE_PAGE_ID en .env)",
    )
    parser.add_argument(
        "--input",
        help="Directorio de entrada con Markdown (o CONFLUENCE_INPUT_DIR en .env, default: input)",
    )
    parser.add_argument(
        "--env-file",
        dest="env_file",
        default=".env",
        help="Ruta al fichero .env (default: .env)",
    )

    args = parser.parse_args()

    # 0. Cargar .env ANTES de leer variables de entorno
    load_dotenv(args.env_file, override=False)

    # 1. Parsear URL si se proporciona
    if args.url:
        extracted = _parse_confluence_url(args.url)
        if "base_url" in extracted:
            BASE_URL = extracted["base_url"]
        if "space" in extracted:
            SPACE = extracted["space"]
        if "page_id" in extracted:
            ROOT_PAGE_ID = extracted["page_id"]

    # 2. Resolver valores: argumento CLI > .env / variable de entorno > default
    BASE_URL     = args.base_url  or os.environ.get("CONFLUENCE_BASE_URL",        BASE_URL)
    SPACE        = args.space     or os.environ.get("CONFLUENCE_SPACE",            SPACE)
    ROOT_PAGE_ID = args.parent_id or os.environ.get("CONFLUENCE_PAGE_ID",  ROOT_PAGE_ID)
    INPUT_DIR    = args.input     or os.environ.get("CONFLUENCE_INPUT_DIR",        INPUT_DIR)
    USER         = args.user      or os.environ.get("CONFLUENCE_USER",             USER)
    TOKEN        = args.token     or os.environ.get("CONFLUENCE_TOKEN",            TOKEN)

    # 3. Validar campos requeridos
    missing = [
        name
        for name, val in [
            ("CONFLUENCE_USER / --user",                         USER),
            ("CONFLUENCE_TOKEN / --token",                       TOKEN),
            ("CONFLUENCE_PAGE_ID / --parent-id o --url", ROOT_PAGE_ID),
            ("CONFLUENCE_SPACE / --space",                       SPACE),
        ]
        if not val
    ]
    if missing:
        print("\n✗ Faltan parámetros requeridos:")
        for m in missing:
            print(f"  - {m}")
        print("\nEspecifícalos en .env, como variable de entorno o por argumento CLI.")
        print("Consulta .env.template para ver el formato.")
        exit(1)

    # 4. Validar directorio de entrada
    input_path = Path(INPUT_DIR)
    if not input_path.exists():
        print(f"\n✗ Directorio de entrada no encontrado: {INPUT_DIR}")
        exit(1)

    # 5. Inicializar sesión HTTP con credenciales definitivas
    session.auth = (USER, TOKEN)
    session.headers.update(
        {"Accept": "application/json", "Content-Type": "application/json"}
    )

    print("=" * 70)
    print("Markdown to Confluence Cloud Uploader")
    print("=" * 70)
    print(f"🌐 Base URL:       {BASE_URL}")
    print(f"📦 Espacio:        {SPACE}")
    print(f"📄 Página padre ID: {ROOT_PAGE_ID}")
    print(f"📁 Dir. entrada:   {INPUT_DIR}\n")

    ctx = RunContext()
    start_time = time.time()

    try:
        # Procesar archivos .md en la raíz del directorio de entrada
        root_md_files = sorted(input_path.glob("*.md"))
        for md_file in root_md_files:
            process_markdown_file(md_file, ROOT_PAGE_ID, SPACE, ctx)

        # Procesar subdirectorios (ignorar 'images')
        root_subdirs = sorted(
            d for d in input_path.iterdir() if d.is_dir() and d.name != "images"
        )
        for subdir in root_subdirs:
            process_directory(subdir, ROOT_PAGE_ID, SPACE, ctx)

    except KeyboardInterrupt:
        print("\n\n⚠️ Proceso interrumpido por el usuario")
        ctx.errors += 1
    except Exception as e:
        print(f"\n✗ Error durante la subida: {e}")
        ctx.errors += 1

    # Segunda pasada: reescribir enlaces internos
    if ctx.pending_html:
        rewrite_internal_links(input_path, ctx)

    elapsed = time.time() - start_time

    print("\n" + "=" * 70)
    print("RESUMEN DE SUBIDA")
    print("=" * 70)
    print(f"✨ Páginas creadas:      {ctx.pages_created}")
    print(f"🔄 Páginas actualizadas: {ctx.pages_updated}")
    print(f"📷 Imágenes subidas:     {ctx.images_uploaded}")
    print(f"✗  Errores:              {ctx.errors}")
    print(f"⏱️  Tiempo total:         {elapsed:.1f} segundos")

    total = ctx.pages_created + ctx.pages_updated
    if ctx.errors == 0 and total > 0:
        print("\n✅ Subida completada exitosamente!")
    elif total > 0:
        print(f"\n⚠️ Subida completada con {ctx.errors} error(es)")
    else:
        print("\n✗ No se subió ninguna página")


if __name__ == "__main__":
    main()
