# Sincronizar contenido entre Confluence Cloud y Markdown

Dos scripts complementarios para sincronizar contenido entre **Confluence Cloud** y archivos **Markdown**:

| Script | Flujo | Descripción |
|---|---|---|
| `confluence-to-markdown.py` | Confluence → Markdown | Descarga páginas y las convierte a Markdown limpio en `output/` |
| `markdown-to-confluence.py` | Markdown → Confluence | Lee archivos Markdown de `input/` y los publica como páginas en Confluence |

---

## Instalación

### Opción A — Entorno virtual (recomendado)

```bash
python3 -m venv .venv
source .venv/bin/activate       # macOS / Linux
# .venv\Scripts\activate        # Windows

pip install -r requirements.txt
```

### Opción B — Instalación global

```bash
pip install -r requirements.txt
```

---

## Configuración

Ambos scripts comparten el mismo mecanismo de configuración. Copia la plantilla y rellena tus valores:

```bash
cp .env.template .env
```

> ⚠️ El fichero `.env` está en `.gitignore` y nunca se sube al repositorio.

### Credenciales comunes

```dotenv
CONFLUENCE_USER=tu-email@dominio.com
CONFLUENCE_TOKEN=tu-token-de-api
CONFLUENCE_BASE_URL=https://tu-dominio.atlassian.net/wiki
CONFLUENCE_SPACE=SPACE_KEY
```

#### Cómo obtener el Token de API

1. Ve a: https://id.atlassian.com/manage-profile/security/api-tokens
2. Clic en **"Create API token"**
3. Copia el token generado

### Variables específicas por script

**`confluence-to-markdown.py`**

```dotenv
CONFLUENCE_PAGE_ID=123456789        # ID de la página raíz a descargar
CONFLUENCE_OUTPUT_DIR=output        # Directorio de salida (default: output)
```

**`markdown-to-confluence.py`**

```dotenv
CONFLUENCE_PAGE_ID=123456789 # ID de la página padre donde se publicará
CONFLUENCE_INPUT_DIR=input          # Directorio de entrada (default: input)
```

#### Cómo obtener el Page ID

**Opción 1: Desde la URL**
```
https://dominio.atlassian.net/wiki/spaces/SPACE/pages/303207758/Titulo
                                                           ^^^^^^^^^
                                                           Page ID
```

**Opción 2: Desde el menú**
1. Abre la página en Confluence
2. Menú `...` → `Page Information`
3. Mira la URL: `pageId=303207758`

### Prioridad de configuración

```
.env  →  variable de entorno del sistema  →  argumento CLI
```

Los argumentos CLI tienen la máxima prioridad y sobreescriben cualquier valor previo.

---

## Script confluence-to-markdown.py

Descarga el árbol de páginas de Confluence Cloud a partir de una página raíz y convierte cada página a Markdown limpio, manteniendo la estructura de carpetas original.

### Características

✅ **API Oficial**: Usa REST API v2 de Confluence Cloud  
✅ **HTML a Markdown**: Conversión limpia sin etiquetas HTML  
✅ **Imágenes**: Descarga imágenes embebidas y las guarda en carpetas `images/` locales  
✅ **Estructura Jerárquica**: Replica la jerarquía de páginas como estructura de carpetas  
✅ **Bloques de código**: Transforma macros `<ac:structured-macro ac:name="code">` a bloques Markdown  
✅ **Reescritura de enlaces**: Convierte enlaces entre páginas Confluence a rutas relativas `.md`

### Uso

```bash
# Con configuración en .env
python confluence-to-markdown.py

# Pasando URL directamente
python confluence-to-markdown.py \
    --url "https://dominio.atlassian.net/wiki/spaces/SPACE/pages/123456" \
    --user tu@email.com --token TU_TOKEN

# Usando un .env alternativo
python confluence-to-markdown.py --env-file /ruta/a/otro.env
```

### Estructura de salida

```
output/
├── Pagina_Principal.md
├── Seccion_1/
│   ├── images/
│   │   ├── imagen1.png
│   │   └── imagen2.jpg
│   ├── Subseccion_1.md
│   └── Subseccion_2.md
└── Seccion_2/
    └── Contenido.md
```

### Proceso de conversión

1. **Descarga HTML**: Obtiene contenido con `/api/v2/pages/{id}?body-format=storage`
2. **Procesa macros de código**: Transforma macros `<ac:structured-macro ac:name="code">` a `<pre><code>`
3. **Procesa enlaces internos**: Convierte macros `<ac:link>` a etiquetas `<a href>` con esquema interno resoluble
4. **Procesa imágenes**: Descarga via API de attachments, guarda en `images/` y actualiza referencias a rutas relativas
5. **Convierte a Markdown**: Usa `markdownify` con estilo ATX, bullets con `-`, sin escape de `*` ni `_`
6. **Reescribe enlaces**: Segunda pasada sobre todos los `.md` generados; sustituye URLs de Confluence por rutas relativas
7. **Procesa recursivamente**: Repite para todas las páginas hijas

---

## Script markdown-to-confluence.py

Lee archivos Markdown desde el directorio `./input` y los publica en Confluence Cloud respetando la jerarquía de carpetas. Crea las páginas si no existen o las actualiza si ya están publicadas.

### Características

✅ **API Oficial**: Usa REST API v1/v2 de Confluence Cloud  
✅ **Markdown a HTML**: Conversión a formato storage de Confluence  
✅ **Imágenes locales**: Sube imágenes como attachments y genera macros `<ac:image>` automáticamente  
✅ **Estructura Jerárquica**: Replica la estructura de carpetas de `input/` como árbol de páginas  
✅ **Bloques de código**: Convierte bloques ` ``` ` a macros `<ac:structured-macro ac:name="code">`  
✅ **Crear o actualizar**: Detecta páginas existentes y las actualiza; si no existen, las crea  
✅ **Reescritura de enlaces**: Segunda pasada que convierte rutas relativas `.md` a URLs de Confluence

### Estructura de entrada

Coloca el contenido a subir dentro de `./input` en la raíz del proyecto. La estructura de carpetas se mapea directamente a la jerarquía de páginas en Confluence:

```
input/
├── Pagina_Principal.md
├── Seccion_1/
│   ├── Seccion_1.md          ← página padre de la sección
│   ├── images/
│   │   ├── imagen1.png
│   │   └── imagen2.jpg
│   ├── Subseccion_1.md
│   └── Subseccion_2.md
└── Seccion_2/
    ├── Seccion_2.md
    └── Contenido.md
```

> Si una carpeta no contiene un `.md` con el mismo nombre, se crea automáticamente una página padre vacía con el nombre humanizado de la carpeta.

### Uso

```bash
# Con configuración en .env
python markdown-to-confluence.py

# Pasando URL de la página padre directamente
python markdown-to-confluence.py \
    --url "https://dominio.atlassian.net/wiki/spaces/SPACE/pages/123456" \
    --user tu@email.com --token TU_TOKEN

# Especificando parámetros individuales
python markdown-to-confluence.py \
    --base-url https://dominio.atlassian.net/wiki \
    --space SPACE \
    --parent-id 123456 \
    --user tu@email.com \
    --token TU_TOKEN \
    --input ./input

# Usando un .env alternativo
python markdown-to-confluence.py --env-file /ruta/a/otro.env
```

### Opciones CLI

| Argumento | Variable `.env` | Descripción |
|---|---|---|
| `--url` | — | URL de la página padre (extrae `base-url`, `space` y `parent-id` automáticamente) |
| `--user` | `CONFLUENCE_USER` | Email o usuario de Confluence Cloud |
| `--token` | `CONFLUENCE_TOKEN` | Token de API de Confluence |
| `--base-url` | `CONFLUENCE_BASE_URL` | URL base del wiki |
| `--space` | `CONFLUENCE_SPACE` | Clave del espacio de Confluence |
| `--parent-id` | `CONFLUENCE_PAGE_ID` | ID de la página padre donde se publicarán las páginas |
| `--input` | `CONFLUENCE_INPUT_DIR` | Directorio de entrada con los archivos Markdown (default: `input`) |
| `--env-file` | — | Ruta a un fichero `.env` alternativo (default: `.env`) |

### Proceso de subida

1. **Lectura del árbol local**: Recorre recursivamente el directorio `input/`
2. **Extrae el título**: Lee el primer heading `# Título` del `.md`; si no existe, usa el nombre del archivo
3. **Crea o localiza la página**: Busca por título exacto en el espacio; si no existe, crea una página provisional
4. **Sube imágenes**: Detecta referencias `![alt](ruta)` y sube cada imagen como attachment
5. **Convierte a HTML de Confluence**:
   - Markdown → HTML con extensiones `fenced_code`, `tables`, `sane_lists`
   - Bloques de código → macros `<ac:structured-macro ac:name="code">`
   - Imágenes locales → macros `<ac:image><ri:attachment>`
   - Enlaces relativos `.md` → esquema `md-internal://` (para segunda pasada)
6. **Actualiza la página** con el HTML definitivo
7. **Procesa recursivamente**: Repite para subdirectorios, creando páginas padre por sección
8. **Segunda pasada de enlaces**: Sustituye `md-internal://` por las URLs reales de Confluence

---

## Manejo de Errores

Ambos scripts comparten el mismo comportamiento ante errores:

- Si falla una página, continúan con las siguientes
- Muestran un resumen con contadores al final del proceso
- Código de salida distinto de cero si hay errores


---

## Solución de Problemas

### Error: dependencias no encontradas

```bash
pip install -r requirements.txt
```

### Error 401: Unauthorized

- Verifica que el token de API sea correcto y no haya expirado
- Asegúrate de tener acceso (lectura o escritura según el script) al espacio de Confluence

### Error 404: Page not found

- **confluence-to-markdown**: Verifica `CONFLUENCE_PAGE_ID`; confirma que la página existe y tienes permisos de lectura
- **markdown-to-confluence**: Verifica `CONFLUENCE_PAGE_ID`; confirma que la página padre existe y tienes permisos de escritura

### Las imágenes no se procesan

- **confluence-to-markdown**: Verifica permisos en Confluence; algunas imágenes pueden ser de dominios externos
- **markdown-to-confluence**: Comprueba que los archivos de imagen existan en las rutas referenciadas (relativas al `.md`) y que tengas permisos para adjuntar archivos

---

## Referencias

- [Confluence REST API v2](https://developer.atlassian.com/cloud/confluence/rest/v2/)
- [Confluence REST API v1](https://developer.atlassian.com/cloud/confluence/rest/v1/)
- [markdownify Documentation](https://github.com/matthewwithanm/python-markdownify)
- [Python-Markdown Documentation](https://python-markdown.github.io/)
- [Beautiful Soup Docs](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)

---

## Licencia

Este proyecto es de uso interno en El Corte Inglés.
