#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Confluence Cloud to Markdown Converter

Descarga contenido de Confluence Cloud usando REST API v2 y lo convierte a Markdown limpio.

Características:
    - Usa API REST v2 oficial de Confluence Cloud
    - Convierte HTML a Markdown limpio (sin etiquetas HTML)
    - Descarga y externaliza imágenes
    - Mantiene estructura de páginas y carpetas jerárquica
    - Gestiona bloques de código de Confluence

Requisitos:
    - Python 3.9+
    - requests
    - markdownify (pip install markdownify)
    - beautifulsoup4 (pip install beautifulsoup4)
    - python-dotenv (pip install python-dotenv)

Configuración:
    Copia .env.template a .env y rellena los valores.
    Los argumentos de línea de comandos tienen prioridad sobre .env.

Uso:
    python confluence-to-markdown.py --url <URL> [--user <USER>] [--token <TOKEN>]
"""

import argparse
import requests
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote, unquote, urlparse, parse_qs, urljoin
from typing import List, Dict, Optional

try:
    from markdownify import markdownify as md
    from bs4 import BeautifulSoup
    import html as html_module
    from dotenv import load_dotenv
except ImportError:
    print("Error: Faltan dependencias requeridas.")
    print("Por favor instala: pip install markdownify beautifulsoup4 python-dotenv")
    exit(1)

# Valores por defecto (se sobreescriben desde .env, variables de entorno o CLI)
USER = ""
TOKEN = ""
BASE_URL = ""
SPACE = ""
ROOT_PAGE_ID = ""
OUTPUT_DIR = "output"

# Sesión HTTP global — se inicializa en main() tras resolver credenciales
session = requests.Session()


@dataclass
class RunContext:
    """Contexto de ejecución: acumula métricas y el mapeo de páginas descargadas."""
    pages_mapping: list = field(default_factory=list)
    pages_downloaded: int = 0
    images_downloaded: int = 0
    errors: int = 0


def clean_name(name: str) -> str:
    """Limpia caracteres ilegales del nombre de archivo, elimina espacios y caracteres ISO-LATIN."""
    # Reemplazar caracteres con tildes y ñ
    replacements = {
        'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u',
        'Á': 'A', 'É': 'E', 'Í': 'I', 'Ó': 'O', 'Ú': 'U',
        'ñ': 'n', 'Ñ': 'N',
        'ü': 'u', 'Ü': 'U',
        'à': 'a', 'è': 'e', 'ì': 'i', 'ò': 'o', 'ù': 'u',
        'À': 'A', 'È': 'E', 'Ì': 'I', 'Ò': 'O', 'Ù': 'U'
    }
    for old_char, new_char in replacements.items():
        name = name.replace(old_char, new_char)
    
    # Reemplazar caracteres ilegales
    name = re.sub(r'[\\/*?:"<>|]', "_", name).strip()
    # Quitar prefijos comunes si es necesario
    name = re.sub(r'^\s*Manual firefly-core 5\s*-\s*', '', name, flags=re.IGNORECASE)
    # Eliminar espacios (reemplazar por guiones bajos)
    name = name.replace(' ', '_')
    # Limpiar guiones bajos múltiples
    name = re.sub(r'_+', '_', name)
    return name.strip('_')


def get_page_content(page_id: str, silent: bool = False) -> Optional[Dict]:
    """
    Obtiene el contenido de una página usando REST API v2.
    
    Args:
        page_id: ID de la página en Confluence
        silent: Si True, suprime mensajes de error (útil para auto-detección de tipo)
        
    Returns:
        Dict con información de la página o None si falla
    """
    try:
        # API v2 endpoint
        url = f"{BASE_URL}/api/v2/pages/{page_id}"
        params = {
            "body-format": "storage"  # Formato HTML de almacenamiento
        }
        
        response = session.get(url, params=params, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            
            # Extraer información relevante
            page_info = {
                "id": data.get("id"),
                "title": data.get("title"),
                "html_content": data.get("body", {}).get("storage", {}).get("value", ""),
                "version": data.get("version", {}).get("number", 1)
            }
            
            return page_info
        else:
            if not silent:
                print(f"    ✗ Error HTTP {response.status_code} al obtener página {page_id}")
            return None
            
    except Exception as e:
        if not silent:
            print(f"    ✗ Error al obtener página {page_id}: {str(e)}")
        return None


def get_page_children(page_id: str) -> List[Dict]:
    """
    Obtiene las páginas hijas de una página usando REST API v2.
    
    Args:
        page_id: ID de la página padre
        
    Returns:
        Lista de diccionarios con información de páginas hijas
    """
    children = []
    cursor = None
    has_more = True
    
    try:
        while has_more:
            url = f"{BASE_URL}/api/v2/pages/{page_id}/children"
            params = {"limit": 250}
            
            if cursor:
                params["cursor"] = cursor
            
            response = session.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                children.extend(data.get("results", []))
                
                # Verificar si hay más páginas
                next_link = data.get("_links", {}).get("next")
                if next_link:
                    parsed = urlparse(next_link)
                    query_params = parse_qs(parsed.query)
                    cursor = query_params.get("cursor", [None])[0]
                    has_more = cursor is not None
                else:
                    has_more = False
            else:
                print(f"    ⚠️ No se pudieron obtener hijos de página {page_id}")
                has_more = False
                
    except Exception as e:
        print(f"    ⚠️ Error obteniendo hijos: {str(e)}")
    
    return children


def _save_image_bytes(content: bytes, filename: str, images_dir: Path, page_title: str, ctx: RunContext) -> str:
    """Guarda bytes de imagen en disco y devuelve el nombre único del archivo."""
    safe_filename = clean_name(filename)
    if not any(safe_filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp']):
        safe_filename += '.png'

    safe_title = clean_name(page_title)[:30]
    unique_filename = f"{safe_title}_{safe_filename}"

    images_dir.mkdir(parents=True, exist_ok=True)
    image_path = images_dir / unique_filename

    with open(image_path, 'wb') as f:
        f.write(content)

    ctx.images_downloaded += 1
    return unique_filename


def _is_valid_image_response(resp: requests.Response) -> bool:
    """Verifica que la respuesta contiene datos de imagen reales y no HTML de login."""
    content_type = resp.headers.get("Content-Type", "")
    # Si el Content-Type indica HTML/JSON, no es una imagen
    if "text/html" in content_type or "application/json" in content_type:
        return False
    # Verificar los primeros bytes: HTML siempre empieza con < o espacios + <
    first_bytes = resp.content[:20].lstrip()
    if first_bytes.startswith(b'<') or first_bytes.startswith(b'{'):
        return False
    return True


def _try_download(url: str, strategy_name: str, use_session: Optional[requests.Session] = None, **kwargs) -> Optional[requests.Response]:
    """
    Intenta descargar una URL con parámetros dados.
    Devuelve la Response si 200 y contiene imagen real, None en otro caso.
    """
    s = use_session or session
    try:
        resp = s.get(url, timeout=30, allow_redirects=True, **kwargs)
        if resp.status_code == 200:
            if _is_valid_image_response(resp):
                return resp
            print(f"      ↳ [{strategy_name}] HTTP 200 pero contenido no es imagen (HTML de login/error)")
            return None
        print(f"      ↳ [{strategy_name}] HTTP {resp.status_code}")
    except Exception as e:
        print(f"      ↳ [{strategy_name}] Error: {str(e)}")
    return None


def download_attachment_via_api(page_id: str, filename: str, images_dir: Path, page_title: str, ctx: RunContext) -> Optional[str]:
    """
    Descarga un attachment de Confluence Cloud usando la cadena de estrategias
    más fiable para tokens API (ATATT*).

    El servlet /download/attachments/ NO acepta API tokens en Confluence Cloud.
    En su lugar usamos:
      1. API v2 thumbnail/download → 302 a URL firmada del media service
      2. Media token + fileId → descarga directa del media service de Atlassian
      3. Fallback: download path con redirect detection (sin auth en la URL final)

    Args:
        page_id: ID de la página
        filename: Nombre original del adjunto
        images_dir: Directorio donde guardar
        page_title: Título de la página

    Returns:
        Nombre del archivo guardado o None
    """
    try:
        # =====================================================================
        # Paso 1: Obtener metadata del attachment vía API v2 (fiable con token)
        # =====================================================================
        att_v2 = None
        v2_url = f"{BASE_URL}/api/v2/pages/{page_id}/attachments"
        v2_params = {"filename": filename}
        v2_resp = session.get(v2_url, params=v2_params, timeout=30)

        if v2_resp.status_code == 200:
            v2_results = v2_resp.json().get("results", [])
            if v2_results:
                att_v2 = v2_results[0]

        # Fallback: obtener metadata vía API v1
        att_v1 = None
        if not att_v2:
            v1_url = f"{BASE_URL}/rest/api/content/{page_id}/child/attachment"
            v1_params = {"filename": filename, "expand": "version"}
            v1_resp = session.get(v1_url, params=v1_params, timeout=30)
            if v1_resp.status_code == 200:
                v1_results = v1_resp.json().get("results", [])
                if v1_results:
                    att_v1 = v1_results[0]

        att = att_v2 or att_v1
        if not att:
            print(f"      ⚠️ Attachment '{filename}' no encontrado vía API")
            return None

        att_id = att.get("id", "")
        file_id = att.get("fileId")  # Solo disponible en API v2
        download_link = att.get("downloadLink") or att.get("_links", {}).get("download", "")

        # Limpiar prefijo "att" del ID v1 si es necesario
        att_id_clean = att_id.replace("att", "") if isinstance(att_id, str) and att_id.startswith("att") else att_id

        print(f"      ↳ Attachment ID: {att_id}, fileId: {file_id or 'N/A'}")
        dl_response = None

        # =====================================================================
        # Estrategia 1: API v2 thumbnail/download → 302 a URL firmada
        # El endpoint devuelve 302 a una URL firmada del media service.
        # Esa URL funciona SIN auth headers (es autoautenticada).
        # =====================================================================
        if att_id_clean:
            try:
                thumb_url = f"{BASE_URL}/api/v2/attachments/{att_id_clean}/thumbnail/download"
                thumb_resp = session.get(thumb_url, timeout=30, allow_redirects=False)

                if thumb_resp.status_code in (302, 303, 307):
                    media_url = thumb_resp.headers.get("Location", "")
                    if media_url:
                        print(f"      ↳ [thumbnail-redirect] Redirect a media service obtenido")
                        # Descargar desde la URL firmada SIN auth headers
                        clean_sess = requests.Session()
                        dl_response = _try_download(media_url, "media-signed-url", use_session=clean_sess)
                else:
                    print(f"      ↳ [thumbnail-redirect] HTTP {thumb_resp.status_code} (esperado 302)")
            except Exception as e:
                print(f"      ↳ [thumbnail-redirect] Error: {str(e)}")

        # =====================================================================
        # Estrategia 2: Media token + fileId → descarga directa
        # Obtiene un JWT del media token endpoint de Confluence y descarga
        # directamente del media service de Atlassian.
        # =====================================================================
        if not dl_response and file_id:
            try:
                # Obtener media token
                token_url = f"{BASE_URL}/rest/api/media/token"
                token_resp = session.get(token_url, timeout=30)

                if token_resp.status_code == 200:
                    media_token = token_resp.json().get("token")
                    if media_token:
                        # Extraer el client ID (site ID) del token o de la URL base
                        parsed_base = urlparse(BASE_URL)
                        site_host = parsed_base.netloc  # e.g. elcorteingles.atlassian.net

                        # Descargar desde media service
                        media_download_url = (
                            f"https://api.media.atlassian.com/file/{file_id}/binary"
                            f"?token={media_token}&client={site_host}"
                        )
                        clean_sess = requests.Session()
                        dl_response = _try_download(media_download_url, "media-api-fileid", use_session=clean_sess)

                        # Intentar también con el token como Bearer header
                        if not dl_response:
                            media_sess = requests.Session()
                            media_sess.headers["Authorization"] = f"Bearer {media_token}"
                            media_sess.headers["Accept"] = "*/*"
                            media_base_url = f"https://api.media.atlassian.com/file/{file_id}/binary"
                            dl_response = _try_download(media_base_url, "media-api-bearer", use_session=media_sess)
                else:
                    print(f"      ↳ [media-token] HTTP {token_resp.status_code}")
            except Exception as e:
                print(f"      ↳ [media-token] Error: {str(e)}")

        # =====================================================================
        # Estrategia 3: Download path con redirect detection
        # Sigue el download link pero detecta 302 y sigue sin auth headers.
        # =====================================================================
        if not dl_response and download_link:
            try:
                parsed_base = urlparse(BASE_URL)
                origin = f"{parsed_base.scheme}://{parsed_base.netloc}"
                if download_link.startswith("/wiki/"):
                    full_url = f"{origin}{download_link}"
                elif download_link.startswith("/"):
                    full_url = f"{origin}/wiki{download_link}"
                else:
                    full_url = f"{BASE_URL.rstrip('/')}/{download_link}"

                # Intentar sin seguir redirects para detectar URL firmada
                redir_resp = session.get(full_url, timeout=30, allow_redirects=False,
                                         headers={"Accept": "*/*"})

                if redir_resp.status_code in (302, 303, 307):
                    redir_url = redir_resp.headers.get("Location", "")
                    if redir_url:
                        clean_sess = requests.Session()
                        dl_response = _try_download(redir_url, "download-redirect", use_session=clean_sess)
                elif redir_resp.status_code == 200 and _is_valid_image_response(redir_resp):
                    dl_response = redir_resp
                    print(f"      ↳ [download-direct] OK")
                else:
                    print(f"      ↳ [download-redirect] HTTP {redir_resp.status_code}")
            except Exception as e:
                print(f"      ↳ [download-redirect] Error: {str(e)}")

        # =====================================================================
        # Guardar si alguna estrategia funcionó
        # =====================================================================
        if dl_response and dl_response.status_code == 200 and _is_valid_image_response(dl_response):
            unique_filename = _save_image_bytes(dl_response.content, filename, images_dir, page_title, ctx)
            print(f"      ✓ Imagen descargada: {unique_filename}")
            return unique_filename
        else:
            print(f"      ✗ Todas las estrategias de descarga fallaron para '{filename}'")
            return None

    except Exception as e:
        print(f"      ⚠️ Error en download_attachment_via_api: {str(e)}")
        return None


def normalize_confluence_image_url(img_url: str) -> str:
    """
    Normaliza URLs de imágenes de Confluence Cloud.

    Corrige especialmente rutas absolutas que empiezan por
    /download/attachments/... para mantener el prefijo /wiki.
    """
    # Limpiar escapes residuales que puedan venir del HTML o shell
    img_url = img_url.replace('\\', '')

    if img_url.startswith("http://") or img_url.startswith("https://"):
        return img_url

    parsed_base = urlparse(BASE_URL)
    origin = f"{parsed_base.scheme}://{parsed_base.netloc}"

    if img_url.startswith("/download/attachments/"):
        return f"{origin}/wiki{img_url}"

    if img_url.startswith("/wiki/"):
        return f"{origin}{img_url}"

    # Para rutas relativas sin slash inicial, preservar /wiki del BASE_URL
    return urljoin(BASE_URL.rstrip('/') + '/', img_url.lstrip('/'))


def download_image(img_url: str, images_dir: Path, page_title: str, ctx: RunContext, original_filename: Optional[str] = None) -> Optional[str]:
    """
    Descarga una imagen y la guarda en el directorio especificado.
    
    Args:
        img_url: URL de la imagen (puede ser relativa)
        images_dir: Directorio donde guardar la imagen
        page_title: Título de la página (para nombrar archivos únicos)
        original_filename: Nombre original del archivo (para attachments de Confluence)
        
    Returns:
        Nombre del archivo de imagen guardado o None si falla
    """
    try:
        # Normalizar URL para preservar prefijos /wiki en attachments
        img_url = normalize_confluence_image_url(img_url)
        
        # Obtener imagen
        response = session.get(img_url, timeout=30, allow_redirects=True)

        # Detectar redirecciones a login (token inválido/sin permisos)
        final_url = response.url or img_url
        if "/login" in final_url or "atlassian.com/login" in final_url:
            print("      ⚠️ Redirección a login detectada al descargar imagen")
            print(f"      ↳ URL original: {img_url}")
            print(f"      ↳ URL final: {final_url}")
            print("      ↳ Revisa token/permisos para attachments")
            return None
        
        if response.status_code == 200:
            # Usar nombre original si se proporciona, sino extraer de URL
            if original_filename:
                filename = original_filename
            else:
                parsed_url = urlparse(final_url)
                filename = os.path.basename(parsed_url.path)

            unique_filename = _save_image_bytes(response.content, filename, images_dir, page_title, ctx)
            print(f"      ✓ Imagen descargada: {unique_filename}")
            return unique_filename
        else:
            print(f"      ⚠️ Error descargando imagen: HTTP {response.status_code}")
            print(f"      ↳ URL: {img_url}")
            if response.status_code == 401:
                print("      ↳ 401 Unauthorized: token inválido o sin permisos de attachment")
            return None
            
    except Exception as e:
        print(f"      ⚠️ Error descargando imagen: {str(e)}")
        return None


def extract_and_download_images(html_content: str, images_dir: Path, page_title: str, page_id: str, ctx: RunContext) -> str:
    """
    Extrae imágenes del HTML (incluyendo macros de Confluence), las descarga y actualiza las referencias.
    
    Args:
        html_content: Contenido HTML de la página
        images_dir: Directorio donde guardar las imágenes
        page_title: Título de la página
        page_id: ID de la página (para descargar attachments)
        
    Returns:
        HTML con referencias de imágenes actualizadas
    """
    # Parsear con lxml para manejar mejor los namespaces de Confluence
    soup = BeautifulSoup(html_content, 'lxml')
    
    # 1. Encontrar macros de Confluence <ac:image> con <ri:attachment>
    # Beautiful Soup maneja los namespaces convirtiendo ac:image en ac_image
    ac_images = soup.find_all(['ac:image', 'ac_image'])
    
    for ac_img in ac_images:
        # Buscar el attachment (puede ser ri:attachment o ri_attachment)
        ri_attachment = ac_img.find(['ri:attachment', 'ri_attachment'])
        
        if ri_attachment:
            # Obtener filename (puede ser ri:filename o ri_filename)
            filename_original = ri_attachment.get('ri:filename') or ri_attachment.get('ri_filename')
            
            if filename_original:
                print(f"    📷 Procesando imagen: {filename_original}")
                
                # Intentar descargar vía API REST (más fiable con tokens scoped)
                filename = download_attachment_via_api(page_id, filename_original, images_dir, page_title, ctx)

                # Fallback: URL directa de attachment si la API falla
                if not filename:
                    print(f"      ↳ Reintentando con URL directa...")
                    attachment_url = f"{BASE_URL.rstrip('/')}/download/attachments/{page_id}/{quote(filename_original)}"
                    filename = download_image(attachment_url, images_dir, page_title, ctx, filename_original)
                
                if filename:
                    # Reemplazar macro de Confluence por tag <img> simple
                    new_img = soup.new_tag('img', src=f"images/{filename}")
                    # Copiar atributos de altura/ancho si existen
                    height = ac_img.get('ac:height') or ac_img.get('ac_height')
                    width = ac_img.get('ac:width') or ac_img.get('ac_width')
                    if height:
                        new_img['height'] = height
                    if width:
                        new_img['width'] = width
                    ac_img.replace_with(new_img)
                else:
                    # Si falla la descarga, dejar un placeholder
                    placeholder_text = f"[IMAGEN NO DISPONIBLE: {filename_original}]"
                    ac_img.replace_with(soup.new_string(placeholder_text))
    
    # 2. Encontrar imágenes normales <img>
    images = soup.find_all('img')
    
    for img in images:
        src = img.get('src')
        if not src or src.startswith('images/') or src.startswith('[IMAGEN'):
            continue
        
        print(f"    📷 Procesando imagen estándar: {src[:80]}...")
        
        # Descargar imagen
        filename = download_image(src, images_dir, page_title, ctx)

        if filename:
            # Actualizar referencia en el HTML a ruta relativa
            img['src'] = f"images/{filename}"
    
    return str(soup)


def _preprocess_ac_links(html_content: str) -> str:
    """
    Convierte macros <ac:link> de Confluence a etiquetas <a href> estándar.

    Los enlaces a páginas internas se convierten al esquema especial
    'confluence-internal://title/ENCODED_TITLE' o
    'confluence-internal://id/PAGE_ID' para que rewrite_internal_links()
    los reemplace más tarde por rutas relativas .md reales.

    Formatos soportados:
      - <ac:link><ri:page ri:content-title="Título"/></ac:link>
      - <ac:link><ri:page ri:content-id="123456"/></ac:link>
      - <ac:link ac:url="..."> se ignora (enlace externo ya es HTML válido)
    """
    def replace_ac_link(m: re.Match) -> str:
        body = m.group(0)

        # Ignorar enlaces externos con ac:url (ya es un atributo HTML válido)
        if re.search(r'\bac:url\s*=', body):
            return body

        # Identificador: content-title tiene prioridad sobre content-id
        title_match = re.search(r'ri:content-title="([^"]+)"', body)
        id_match    = re.search(r'ri:content-id="(\d+)"', body)

        if not title_match and not id_match:
            return body  # No se puede resolver

        # Texto del enlace (plain-text-link-body > link-body > identificador)
        text_match = re.search(
            r'<ac:plain-text-link-body>\s*<!\[CDATA\[(.*?)\]\]>\s*</ac:plain-text-link-body>',
            body, re.DOTALL
        )
        if not text_match:
            text_match = re.search(r'<ac:link-body>(.*?)</ac:link-body>', body, re.DOTALL)

        if title_match:
            raw_id   = title_match.group(1)
            id_type  = 'title'
        else:
            raw_id   = id_match.group(1)
            id_type  = 'id'

        link_text = text_match.group(1).strip() if text_match else raw_id
        encoded   = quote(raw_id, safe='')
        return f'<a href="confluence-internal://{id_type}/{encoded}">{link_text}</a>'

    return re.sub(r'<ac:link[^>]*>.*?</ac:link>', replace_ac_link, html_content, flags=re.DOTALL)


def preprocess_confluence_code_macros(html_content: str) -> str:
    """
    Pre-procesa el HTML de Confluence para convertir macros de bloques de código
    a HTML estándar <pre><code> ANTES de pasar a BeautifulSoup/markdownify.
    También elimina macros de anclaje que Confluence inserta dentro de encabezados
    y que provocan títulos duplicados en el Markdown resultante.

    Confluencia usa macros con namespaces XML que los parsers HTML no entienden:
        <ac:structured-macro ac:name="code">
          <ac:parameter ac:name="language">swift</ac:parameter>
          <ac:plain-text-body><![CDATA[...código...]]></ac:plain-text-body>
        </ac:structured-macro>

    Args:
        html_content: HTML crudo en formato storage de Confluence

    Returns:
        HTML con macros de código convertidas a <pre><code>
    """
    # Convertir macros de enlace interno <ac:link> a <a href> antes de
    # que BeautifulSoup o markdownify las descarten silenciosamente
    html_content = _preprocess_ac_links(html_content)

    # Eliminar macros de anclaje (<ac:structured-macro ac:name="anchor">)
    # Estas macros aparecen dentro de encabezados y su texto se concatena al título real
    # provocando duplicados como "# _introducciónIntroducción"
    html_content = re.sub(
        r'<ac:structured-macro[^>]*\bac:name="anchor"[^>]*>.*?</ac:structured-macro>',
        '',
        html_content,
        flags=re.DOTALL
    )
    def replace_code_macro(match):
        macro_body = match.group(1)

        # Extraer lenguaje (opcional)
        lang_match = re.search(
            r'<ac:parameter\s+ac:name="language">\s*(.*?)\s*</ac:parameter>',
            macro_body, re.DOTALL
        )
        language = lang_match.group(1).strip() if lang_match else ""

        # Extraer código del CDATA
        code_match = re.search(
            r'<ac:plain-text-body>\s*<!\[CDATA\[(.*?)\]\]>\s*</ac:plain-text-body>',
            macro_body, re.DOTALL
        )
        if code_match:
            code = code_match.group(1)
        else:
            # Fallback: intentar sin CDATA
            code_match_no_cdata = re.search(
                r'<ac:plain-text-body>(.*?)</ac:plain-text-body>',
                macro_body, re.DOTALL
            )
            code = code_match_no_cdata.group(1) if code_match_no_cdata else ""

        # Primero deshacer cualquier entidad HTML pre-existente en el CDATA
        # (Confluence a veces guarda &gt; &lt; &amp; dentro del CDATA)
        code = html_module.unescape(code)

        # Escapar HTML dentro del código para que no se interprete como tags
        code = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        lang_attr = f' class="language-{language}"' if language else ""
        return f'<pre{lang_attr}><code>{code}</code></pre>'

    # Patrón para capturar macros de código (code y code-block)
    pattern = re.compile(
        r'<ac:structured-macro[^>]*ac:name="(?:code|code-block)"[^>]*>(.*?)</ac:structured-macro>',
        re.DOTALL
    )
    return pattern.sub(replace_code_macro, html_content)


def _save_page_as_markdown(
    page_id: str,
    original_title: str,
    title: str,
    html_content: str,
    dir_path: str,
    url_display: str,
    url_viewpage: str,
    ctx: RunContext,
):
    """
    Convierte el HTML de una página a Markdown y lo guarda en disco.

    Registra la entrada en pages_mapping y actualiza stats.

    Args:
        page_id: ID de la página en Confluence
        original_title: Título original (sin limpiar) de la página
        title: Título limpio (usado como nombre de archivo/carpeta)
        html_content: HTML crudo en formato storage de Confluence
        dir_path: Directorio local donde se guardará el archivo .md
        url_display: URL moderna de Confluence para el mapeo
        url_viewpage: URL clásica viewpage.action para el mapeo
    """
    images_dir = Path(dir_path) / "images"

    # Pre-procesar macros de código ANTES de que BeautifulSoup las destruya
    html_content = preprocess_confluence_code_macros(html_content)

    # Extraer y descargar imágenes
    html_with_images = extract_and_download_images(html_content, images_dir, title, page_id, ctx)

    # Convertir a Markdown
    markdown_content = html_to_markdown(html_with_images)

    # Agregar título original al inicio
    markdown_with_title = f"# {original_title}\n\n{markdown_content}"

    # Guardar archivo Markdown
    md_path = os.path.join(dir_path, f"{title}.md")
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(markdown_with_title)

    # Registrar en mapeo
    relative_path = os.path.relpath(md_path, OUTPUT_DIR)
    ctx.pages_mapping.append({
        "title": original_title,
        "page_id": page_id,
        "url_display": url_display,
        "url_viewpage": url_viewpage,
        "md_path": relative_path
    })

    ctx.pages_downloaded += 1
    print(f"  ✓ Guardado: {relative_path}")


def html_to_markdown(html_content: str) -> str:
    """
    Convierte HTML a Markdown limpio.
    
    Args:
        html_content: Contenido HTML
        
    Returns:
        Contenido en formato Markdown
    """
    # Configurar opciones de conversión
    markdown = md(
        html_content,
        heading_style="ATX",  # Usar # para headers
        bullets="-",  # Usar - para listas
        strip=['script', 'style'],  # Eliminar scripts y estilos
        escape_asterisks=False,
        escape_underscores=False,
        code_language_callback=lambda el: el.get("class", [""])[0].replace("language-", "") if el.get("class") else None,
    )
    
    # Limpiar residuos de CDATA que puedan haber sobrevivido al pre-procesamiento
    markdown = re.sub(r'<!--\[CDATA\[', '', markdown)
    markdown = re.sub(r'\]\]-->', '', markdown)
    
    # Limpiar Markdown
    # Eliminar líneas vacías excesivas
    markdown = re.sub(r'\n{3,}', '\n\n', markdown)
    
    # Eliminar espacios al final de líneas
    markdown = re.sub(r' +\n', '\n', markdown)
    
    return markdown.strip()


def download_page_tree(page_id: str, path: str, ctx: RunContext, is_root: bool = False):
    """
    Descarga recursivamente una página y sus hijas, convirtiéndolas a Markdown.

    Args:
        page_id: ID de la página a descargar
        path: Ruta donde guardar el contenido
        ctx: Contexto de ejecución (métricas y mapeo)
        is_root: Si es la página raíz
    """
    # Obtener contenido de la página
    print(f"\n📄 Procesando página ID: {page_id}")
    page_data = get_page_content(page_id)
    
    if not page_data:
        ctx.errors += 1
        return
    
    title = clean_name(page_data["title"])
    original_title = page_data["title"]
    html_content = page_data["html_content"]
    
    print(f"  📝 {original_title}")
    
    # Obtener páginas hijas
    children = get_page_children(page_id)
    
    # Construir URLs de Confluence
    url_display = f"{BASE_URL}/spaces/{SPACE}/pages/{page_id}/{quote(original_title)}"
    url_viewpage = f"{BASE_URL}/pages/viewpage.action?pageId={page_id}"
    
    # Si tiene hijos → crear carpeta
    if children:
        dir_path = OUTPUT_DIR if is_root else os.path.join(path, title)
        os.makedirs(dir_path, exist_ok=True)
        
        # Guardar contenido del padre si no es root
        if not is_root and html_content:
            _save_page_as_markdown(
                page_id, original_title, title, html_content,
                dir_path, url_display, url_viewpage, ctx,
            )

        # Procesar hijos recursivamente
        for child in children:
            download_page_tree(child["id"], dir_path, ctx)
    else:
        # Página hoja → guardar directamente
        os.makedirs(path, exist_ok=True)

        if html_content:
            _save_page_as_markdown(
                page_id, original_title, title, html_content,
                path, url_display, url_viewpage, ctx,
            )


def rewrite_internal_links(output_dir: str, ctx: RunContext) -> int:
    """
    Segunda pasada (post-processing): sustituye en todos los .md generados
    cualquier URL de Confluence por la ruta relativa al fichero .md
    correspondiente.

    Patrones reemplazados:
      - confluence-internal://title/ENCODED_TITLE  (inyectado por _preprocess_ac_links)
      - confluence-internal://id/PAGE_ID
      - URL url_display  (https://.../spaces/SPACE/pages/ID/Titulo)
      - URL url_viewpage (https://.../pages/viewpage.action?pageId=ID)

    Returns:
        Número de ficheros modificados.
    """
    if not ctx.pages_mapping:
        return 0

    title_to_mdpath: Dict[str, str] = {e['title']: e['md_path'] for e in ctx.pages_mapping}
    id_to_mdpath:    Dict[str, str] = {e['page_id']: e['md_path'] for e in ctx.pages_mapping}

    def _rel(from_md: str, to_md: str) -> str:
        """Ruta relativa de from_md a to_md, siempre con forward slashes."""
        return os.path.relpath(to_md, os.path.dirname(from_md)).replace('\\', '/')

    modified = 0

    for entry in ctx.pages_mapping:
        md_file = os.path.join(output_dir, entry['md_path'])
        if not os.path.exists(md_file):
            continue

        with open(md_file, 'r', encoding='utf-8') as f:
            content = f.read()

        original = content

        # 1. confluence-internal://title/ENCODED_TITLE
        def replace_internal_title(m: re.Match) -> str:
            target = title_to_mdpath.get(unquote(m.group(1)))
            return f']({_rel(entry["md_path"], target)})' if target else m.group(0)

        content = re.sub(
            r'\]\(confluence-internal://title/([^)]+)\)',
            replace_internal_title, content
        )

        # 2. confluence-internal://id/PAGE_ID
        def replace_internal_id(m: re.Match) -> str:
            target = id_to_mdpath.get(unquote(m.group(1)))
            return f']({_rel(entry["md_path"], target)})' if target else m.group(0)

        content = re.sub(
            r'\]\(confluence-internal://id/([^)]+)\)',
            replace_internal_id, content
        )

        # 3. URLs completas de Confluence (url_display y url_viewpage)
        for page in ctx.pages_mapping:
            rel = _rel(entry['md_path'], page['md_path'])
            content = content.replace(page['url_display'],  rel)
            content = content.replace(page['url_viewpage'], rel)

        # 4. Patrón genérico viewpage.action?pageId=ID (para casos residuales)
        def replace_viewpage(m: re.Match) -> str:
            target = id_to_mdpath.get(m.group(1))
            return _rel(entry['md_path'], target) if target else m.group(0)

        content = re.sub(
            rf'{re.escape(BASE_URL)}/pages/viewpage\.action\?pageId=(\d+)',
            replace_viewpage, content
        )

        if content != original:
            with open(md_file, 'w', encoding='utf-8') as f:
                f.write(content)
            modified += 1

    if modified:
        print(f"\n\U0001f517 {modified} fichero(s) con enlaces internos reescritos a rutas relativas .md")
    return modified


def get_folder_info(folder_id: str) -> Optional[Dict]:
    """Obtiene los metadatos de una carpeta via REST API v2."""
    try:
        url = f"{BASE_URL}/api/v2/folders/{folder_id}"
        response = session.get(url, timeout=30)
        if response.status_code == 200:
            data = response.json()
            return {"id": data.get("id"), "title": data.get("title", f"Carpeta_{folder_id}")}
        return None
    except Exception as e:
        print(f"    ✗ Error al obtener carpeta {folder_id}: {str(e)}")
        return None


def get_children_of_folder(folder_id: str):
    """
    Obtiene las páginas y subcarpetas directas de una carpeta.

    - Páginas: via CQL 'parent={id}' (API v1) — único método fiable para carpetas.
    - Subcarpetas: via /api/v2/folders?parentId={id} — las carpetas no aparecen en CQL.

    Returns:
        Tuple (pages, subfolders)
    """
    pages = []
    subfolders = []

    # 1. Páginas hijas via CQL
    start = 0
    limit = 50
    while True:
        try:
            url = f"{BASE_URL}/rest/api/content/search"
            params = {"cql": f"parent={folder_id}", "limit": limit, "start": start}
            response = session.get(url, params=params, timeout=30)
            if response.status_code == 200:
                data = response.json()
                results = data.get("results", [])
                for item in results:
                    if item.get("type") == "page":
                        pages.append({"id": item["id"], "title": item.get("title", f"page_{item['id']}")})
                if len(results) < limit:
                    break
                start += limit
            else:
                print(f"    ⚠️ Error HTTP {response.status_code} al buscar páginas en carpeta {folder_id}")
                break
        except Exception as e:
            print(f"    ⚠️ Error obteniendo páginas de carpeta {folder_id}: {str(e)}")
            break

    # 2. Subcarpetas via API v2
    cursor = None
    has_more = True
    while has_more:
        try:
            url = f"{BASE_URL}/api/v2/folders"
            params = {"parentId": folder_id, "limit": 250}
            if cursor:
                params["cursor"] = cursor
            response = session.get(url, params=params, timeout=30)
            if response.status_code == 200:
                data = response.json()
                for item in data.get("results", []):
                    subfolders.append({"id": item["id"], "title": item.get("title", f"folder_{item['id']}")})
                next_link = data.get("_links", {}).get("next")
                if next_link:
                    parsed_next = urlparse(next_link)
                    cursor = parse_qs(parsed_next.query).get("cursor", [None])[0]
                    has_more = cursor is not None
                else:
                    has_more = False
            else:
                # El endpoint de carpetas puede no estar disponible en todas las instancias
                has_more = False
        except Exception as e:
            print(f"    ⚠️ Error obteniendo subcarpetas de carpeta {folder_id}: {str(e)}")
            has_more = False

    return pages, subfolders


def download_folder_tree(folder_id: str, path: str, ctx: RunContext, is_root: bool = False):
    """
    Descarga recursivamente todas las páginas bajo una carpeta de Confluence.

    Args:
        folder_id: ID de la carpeta
        path: Ruta local donde guardar el contenido
        ctx: Contexto de ejecución (métricas y mapeo)
        is_root: Si True, no crea subdirectorio propio para la carpeta raíz
    """
    print(f"\n📁 Procesando carpeta ID: {folder_id}")
    folder_data = get_folder_info(folder_id)

    if not folder_data:
        ctx.errors += 1
        return

    folder_title = clean_name(folder_data["title"])
    print(f"  📂 {folder_data['title']}")

    dir_path = os.path.join(path, folder_title)
    os.makedirs(dir_path, exist_ok=True)

    child_pages, child_folders = get_children_of_folder(folder_id)

    for page in child_pages:
        download_page_tree(page["id"], dir_path, ctx)

    for subfolder in child_folders:
        download_folder_tree(subfolder["id"], dir_path, ctx)


def _parse_confluence_url(url: str) -> Dict[str, str]:
    """
    Extrae BASE_URL, SPACE y ROOT_PAGE_ID de una URL de Confluence.

    Formatos soportados:
      https://empresa.atlassian.net/wiki/spaces/SPACE/pages/123456/Titulo
      https://empresa.atlassian.net/wiki/spaces/SPACE/folder/123456
      https://empresa.atlassian.net/wiki/pages/viewpage.action?pageId=123456
    """
    # Normalizar caracteres escapados por el shell (\? \= \&) y eliminar query string
    url = re.sub(r'\\([?&=])', r'\1', url)
    clean_url = url.split('?')[0]
    # Eliminar también posibles barras invertidas residuales al final de segmentos
    clean_url = clean_url.replace('\\', '')
    parsed = urlparse(clean_url)
    path_parts = [p for p in parsed.path.split('/') if p]
    result = {}

    # Determinar base del wiki
    try:
        wiki_idx = path_parts.index('wiki')
        base_path = '/' + '/'.join(path_parts[:wiki_idx + 1])
        result['base_url'] = f"{parsed.scheme}://{parsed.netloc}{base_path}"
    except ValueError:
        result['base_url'] = f"{parsed.scheme}://{parsed.netloc}"

    # Extraer space (segmento tras 'spaces')
    if 'spaces' in path_parts:
        space_idx = path_parts.index('spaces')
        if space_idx + 1 < len(path_parts):
            result['space'] = path_parts[space_idx + 1]

    # Extraer page ID: buscar en 'pages', 'folder' o 'overview'
    PAGE_SEGMENTS = ('pages', 'folder', 'overview')
    for segment in PAGE_SEGMENTS:
        if segment in path_parts:
            seg_idx = path_parts.index(segment)
            candidate = path_parts[seg_idx + 1] if seg_idx + 1 < len(path_parts) else ''
            if candidate.isdigit():
                result['page_id'] = candidate
                result['entity_type'] = 'folder' if segment == 'folder' else 'page'
                break

    # Fallback: viewpage.action?pageId=
    if 'page_id' not in result:
        qs = parse_qs(urlparse(url).query)
        if 'pageId' in qs:
            result['page_id'] = qs['pageId'][0]

    return result


def main():
    """Punto de entrada principal."""
    global USER, TOKEN, BASE_URL, SPACE, ROOT_PAGE_ID, OUTPUT_DIR

    parser = argparse.ArgumentParser(
        description="Descarga contenido de Confluence Cloud y lo convierte a Markdown.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  # Usando URL directa de la página:
  python Descarga-HTML-a-Markdown.py \\
      --url "https://empresa.atlassian.net/wiki/spaces/SPACE/pages/123456" \\
      --user tu@email.com --token TU_TOKEN

  # Usando parámetros individuales:
  python Descarga-HTML-a-Markdown.py \\
      --base-url https://empresa.atlassian.net/wiki \\
      --space SPACE --page-id 123456 \\
      --user tu@email.com --token TU_TOKEN --output ./salida
"""
    )
    parser.add_argument(
        "--url",
        help="URL completa de la página de Confluence raíz "
             "(extrae automáticamente base-url, space y page-id)"
    )
    parser.add_argument("--user",     help="Email/usuario de Confluence (o CONFLUENCE_USER en .env/entorno)")
    parser.add_argument("--token",    help="Token de API de Confluence (o CONFLUENCE_TOKEN en .env/entorno)")
    parser.add_argument("--base-url", dest="base_url", help="Base URL del wiki (o CONFLUENCE_BASE_URL en .env/entorno)")
    parser.add_argument("--space",    help="Clave del espacio de Confluence (o CONFLUENCE_SPACE en .env/entorno)")
    parser.add_argument("--page-id",  dest="page_id",  help="ID de la página raíz (o CONFLUENCE_PAGE_ID en .env/entorno)")
    parser.add_argument("--output",   help="Directorio de salida (o CONFLUENCE_OUTPUT_DIR en .env/entorno, default: output)")
    parser.add_argument("--env-file", dest="env_file", default=".env", help="Ruta al fichero .env (default: .env)")

    args = parser.parse_args()

    # 0. Cargar .env (si existe) ANTES de leer variables de entorno
    load_dotenv(args.env_file, override=False)

    # 1. Parsear URL si se proporciona
    entity_type = 'page'  # por defecto; se sobreescribe si la URL contiene /folder/
    if args.url:
        extracted = _parse_confluence_url(args.url)
        if 'base_url' in extracted:
            BASE_URL = extracted['base_url']
        if 'space' in extracted:
            SPACE = extracted['space']
        if 'page_id' in extracted:
            ROOT_PAGE_ID = extracted['page_id']
        entity_type = extracted.get('entity_type', 'page')

    # 2. Resolver valores: argumento CLI > .env / variable de entorno > default vacío
    BASE_URL   = args.base_url or os.environ.get('CONFLUENCE_BASE_URL',   BASE_URL)
    SPACE      = args.space    or os.environ.get('CONFLUENCE_SPACE',      SPACE)
    ROOT_PAGE_ID = args.page_id or os.environ.get('CONFLUENCE_PAGE_ID',   ROOT_PAGE_ID)
    OUTPUT_DIR = args.output   or os.environ.get('CONFLUENCE_OUTPUT_DIR', OUTPUT_DIR)
    USER       = args.user     or os.environ.get('CONFLUENCE_USER',       USER)
    TOKEN      = args.token    or os.environ.get('CONFLUENCE_TOKEN',      TOKEN)

    # 3. Validar campos requeridos
    missing = [name for name, val in [
        ('CONFLUENCE_USER / --user',   USER),
        ('CONFLUENCE_TOKEN / --token', TOKEN),
        ('CONFLUENCE_PAGE_ID / --page-id o --url', ROOT_PAGE_ID),
    ] if not val]
    if missing:
        print("\n✗ Faltan parámetros requeridos:")
        for m in missing:
            print(f"  - {m}")
        print("\nEspecifícalos en .env, como variable de entorno o por argumento CLI.")
        print("Consulta .env.template para ver el formato.")
        exit(1)

    # 4. Inicializar sesión HTTP con credenciales definitivas
    session.auth = (USER, TOKEN)
    session.headers.update({
        "Accept": "application/json",
        "Content-Type": "application/json",
    })

    print("=" * 70)
    print("Confluence Cloud to Markdown Converter")
    print("=" * 70)
    print(f"🌐 Base URL: {BASE_URL}")
    print(f"📦 Espacio: {SPACE}")
    print(f"📄 Página raíz ID: {ROOT_PAGE_ID}")
    print(f"📁 Directorio salida: {OUTPUT_DIR}\n")
    
    # Crear directorio de salida
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    ctx = RunContext()

    # Descargar árbol de páginas
    start_time = time.time()

    try:
        if entity_type == 'folder':
            print(f"🗂️ Modo: carpeta\n")
            download_folder_tree(ROOT_PAGE_ID, OUTPUT_DIR, ctx, is_root=True)
        else:
            # Auto-detección: intentar como página; si falla, intentar como carpeta
            page_test = get_page_content(ROOT_PAGE_ID, silent=True)
            if page_test is not None:
                print(f"📄 Modo: página\n")
                download_page_tree(ROOT_PAGE_ID, OUTPUT_DIR, ctx, is_root=True)
            else:
                print(f"  ℹ️ ID {ROOT_PAGE_ID} no responde como página, intentando como carpeta...\n")
                download_folder_tree(ROOT_PAGE_ID, OUTPUT_DIR, ctx, is_root=True)
    except KeyboardInterrupt:
        print("\n\n⚠️ Proceso interrumpido por el usuario")
        ctx.errors += 1
    except Exception as e:
        print(f"\n✗ Error durante la descarga: {str(e)}")
        ctx.errors += 1

    elapsed_time = time.time() - start_time

    # Reescribir enlaces internos en todos los .md generados
    if ctx.pages_mapping:
        rewrite_internal_links(OUTPUT_DIR, ctx)

    # Mostrar estadísticas finales
    print("\n" + "=" * 70)
    print("RESUMEN DE DESCARGA")
    print("=" * 70)
    print(f"✓ Páginas descargadas: {ctx.pages_downloaded}")
    print(f"📷 Imágenes descargadas: {ctx.images_downloaded}")
    print(f"✗ Errores: {ctx.errors}")
    print(f"⏱️ Tiempo total: {elapsed_time:.1f} segundos")
    print(f"\n📁 Archivos Markdown en: {os.path.abspath(OUTPUT_DIR)}")

    if ctx.errors == 0 and ctx.pages_downloaded > 0:
        print("\n✅ Descarga completada exitosamente!")
    elif ctx.pages_downloaded > 0:
        print(f"\n⚠️ Descarga completada con {ctx.errors} error(es)")
    else:
        print("\n✗ No se descargó ninguna página")


if __name__ == "__main__":
    main()
